#Signals
test_that("set portfolio weights work for Custom Weights (signals)", {

  #Load
  load(paste(test_path(),"/testdata/","toy_preprocessed_signal_selection_obj.RData", sep =""))
  load(paste(test_path(),"/testdata/","toy_preprocessed_signal_selection_results.RData", sep =""))

  current_date <- "2023-03-15"

  #Select and correct signals
  signal_universe_m_df <- results@signal_universe_m_df@data
  most_recent_signal_universe_m_d_ref <- signal_universe_m_df %>% dplyr::filter(dates == "2023-03-15")
  current_eligible_signals <- most_recent_signal_universe_m_d_ref$tickers
  signals_positions <- ifelse(stringr::str_detect(current_eligible_signals, "low_"), "short", "long")
  chosen_signals_and_positions <- signals_positions
  names(chosen_signals_and_positions) <- stringr::str_remove(current_eligible_signals, "low_")

  select_and_correct_signals_backtest_list <- select_and_correct_signals(signals_m_df = signals_m_df@data,
                                                                         chosen_signals_and_positions = chosen_signals_and_positions,
                                                                         backtest_returns_m_xts = mocked_backtest_returns_m_xts)

  selected_signals_corrected_positions_m_df <- select_and_correct_signals_backtest_list$selected_signals_corrected_positions_m_df
  selected_backtest_returns_corrected_positions_m_xts <- select_and_correct_signals_backtest_list$selected_backtest_returns_corrected_positions_m_xts

  expect_equal(colnames(selected_signals_corrected_positions_m_df)[-c(1:3)], current_eligible_signals)
  expect_equal(selected_signals_corrected_positions_m_df$low_vol_36m, signals_m_df@data$vol_36m*-1)


  #ts_splits
  features_m_refit <- signals_m_df@data %>% dplyr::filter(dates <= "2023-03-15") #this is to mimick ts_split behavior with a target_fwd of 3


  #Create custom weights according to theme_sb
  most_recent_signal_universe_m_d_ref$weights <- most_recent_signal_universe_m_d_ref$theme_sb_bench_weights

  theme_sb_bench_weights_m_df <- most_recent_signal_universe_m_d_ref %>% dplyr::select(id, tickers, dates, theme_sb_bench_weights) %>% dplyr::rename(weights = theme_sb_bench_weights)

  results <- set_portfolio_weights(port_construction_method = "custom_weights",
                                   universe_m_d_ref = most_recent_signal_universe_m_d_ref %>% dplyr::select(-weights),
                                   custom_weights_m_d_ref = theme_sb_bench_weights_m_df
  )

  expect_equal(most_recent_signal_universe_m_d_ref %>% dplyr::arrange(id), results@universe_m_d_ref@data)
  expect_equal(results@eligible_assets, most_recent_signal_universe_m_d_ref %>% dplyr::filter(theme_sb_bench_weights > 0) %>% dplyr::pull(tickers))
  expect_equal(results@weights, most_recent_signal_universe_m_d_ref %>% dplyr::filter(theme_sb_bench_weights > 0) %>% dplyr::pull(weights))
  expect_true(all(is.na(results@port_stats[,c("exp_ret", "risk", "sharpe", "diversification_ratio",
                                              "wavg_pairwise_corr", "hhi_rrc", "n_eff_rrc", "rrc_dist_to_erc")]))
  )

  #Create custom weights according to theme_ss
  most_recent_signal_universe_m_d_ref$weights <- most_recent_signal_universe_m_d_ref$theme_ss_bench_weights

  theme_ss_bench_weights_m_df <- most_recent_signal_universe_m_d_ref %>% dplyr::select(id, tickers, dates, theme_ss_bench_weights) %>% dplyr::rename(weights = theme_ss_bench_weights)

  results <- set_portfolio_weights(port_construction_method = "custom_weights",
                                   universe_m_d_ref = most_recent_signal_universe_m_d_ref %>% dplyr::select(-weights),
                                   custom_weights_m_d_ref = theme_ss_bench_weights_m_df
  )

  expect_equal(most_recent_signal_universe_m_d_ref %>% dplyr::arrange(id), results@universe_m_d_ref@data)
  expect_equal(results@eligible_assets, most_recent_signal_universe_m_d_ref %>% dplyr::filter(theme_ss_bench_weights > 0) %>% dplyr::pull(tickers))
  expect_equal(results@weights, most_recent_signal_universe_m_d_ref %>% dplyr::filter(theme_ss_bench_weights > 0) %>% dplyr::pull(weights))
  expect_true(all(is.na(results@port_stats[,c("exp_ret", "risk", "sharpe", "diversification_ratio",
                                              "wavg_pairwise_corr", "hhi_rrc", "n_eff_rrc", "rrc_dist_to_erc")]))
  )


})

test_that("set portfolio weights work for EW (signals)", {

  #Load
  load(paste(test_path(),"/testdata/","toy_preprocessed_signal_selection_obj.RData", sep =""))
  load(paste(test_path(),"/testdata/","toy_preprocessed_signal_selection_results.RData", sep =""))

  current_date <- "2023-06-15"

  #Select and correct signals
  signal_universe_m_df <- results@signal_universe_m_df@data
  most_recent_signal_universe_m_d_ref <- signal_universe_m_df %>% dplyr::filter(dates == "2023-06-15")
  current_eligible_signals <- most_recent_signal_universe_m_d_ref$tickers
  signals_positions <- ifelse(stringr::str_detect(current_eligible_signals, "low_"), "short", "long")
  chosen_signals_and_positions <- signals_positions
  names(chosen_signals_and_positions) <- stringr::str_remove(current_eligible_signals, "low_")

  select_and_correct_signals_backtest_list <- select_and_correct_signals(signals_m_df = signals_m_df@data,
                                                                         chosen_signals_and_positions = chosen_signals_and_positions,
                                                                         backtest_returns_m_xts = mocked_backtest_returns_m_xts)

  selected_signals_corrected_positions_m_df <- select_and_correct_signals_backtest_list$selected_signals_corrected_positions_m_df
  selected_backtest_returns_corrected_positions_m_xts <- select_and_correct_signals_backtest_list$selected_backtest_returns_corrected_positions_m_xts

  expect_equal(colnames(selected_signals_corrected_positions_m_df)[-c(1:3)], current_eligible_signals)
  expect_equal(selected_signals_corrected_positions_m_df$low_vol_36m, signals_m_df@data$vol_36m*-1)


  #ts_splits
  features_m_refit <- signals_m_df@data %>% dplyr::filter(dates <= "2023-03-15") #this is to mimick ts_split behavior with a target_fwd of 3

  most_recent_signal_universe_m_d_ref$weights <- rep(0.20, 5)

  most_recent_signal_universe_m_d_ref <- most_recent_signal_universe_m_d_ref

  cov_matrix <- cov(selected_backtest_returns_corrected_positions_m_xts[1:9,])

  #RRC
  rrc <- relative_risk_contribution(most_recent_signal_universe_m_d_ref$weights, cov_matrix)
  most_recent_signal_universe_m_d_ref$rel_risk_contr <- rrc$rel_risk_contr
  most_recent_signal_universe_m_d_ref <- most_recent_signal_universe_m_d_ref %>% dplyr::relocate(rel_risk_contr, .before = weights)

  results <- set_portfolio_weights(port_construction_method = "ew",
                                   universe_m_d_ref = most_recent_signal_universe_m_d_ref %>% dplyr::select(-weights, -rel_risk_contr),
                                   eligible_returns_m_xts_upd_ref = mocked_backtest_returns_m_xts[1:9,])

  expect_equal(most_recent_signal_universe_m_d_ref %>% dplyr::arrange(id), results@universe_m_d_ref@data)
  expect_equal(results@groups, NULL)
  expect_equal(results@eligible_assets, most_recent_signal_universe_m_d_ref %>% dplyr::filter(is_eligible == 1) %>% dplyr::pull(tickers))
  expect_equal(results@groups, NULL)
  expect_equal(results@exp_ret_score, NULL)
  expect_equal(results@eligible_assets, most_recent_signal_universe_m_d_ref %>% dplyr::filter(is_eligible == 1) %>% dplyr::pull(tickers))
  expect_equal(results@covariance_matrix, cov_matrix)
  expect_equal(results@rel_risk_contr, rrc$rel_risk_contr)
  expect_equal(results@port_stats$hhi_weights,
               1/(results@universe_m_d_ref@data %>% dplyr::filter(is_eligible == 1L) %>% nrow()))
  expect_equal(sum(rrc$rel_risk_contr^2), results@port_stats$hhi_rrc)
  div_ratio <- sum(sqrt(diag(results@covariance_matrix)) * results@weights)/results@port_stats$risk
  expect_equal(div_ratio, results@port_stats$diversification_ratio)

})

test_that("set portfolio weights work for SW (signals) ", {

  #Load
  load(paste(test_path(),"/testdata/","toy_preprocessed_signal_selection_obj.RData", sep =""))
  load(paste(test_path(),"/testdata/","toy_preprocessed_signal_selection_results.RData", sep =""))

  current_date <- "2023-06-15"

  #Select and correct signals
  signal_universe_m_df <- results@signal_universe_m_df@data
  most_recent_signal_universe_m_d_ref <- signal_universe_m_df %>% dplyr::filter(dates == "2023-06-15")
  current_eligible_signals <- most_recent_signal_universe_m_d_ref$tickers
  signals_positions <- ifelse(stringr::str_detect(current_eligible_signals, "low_"), "short", "long")
  chosen_signals_and_positions <- signals_positions
  names(chosen_signals_and_positions) <- stringr::str_remove(current_eligible_signals, "low_")

  selected_signals_corrected_positions_m_df <- select_and_correct_signals(signals_m_df = signals_m_df@data,
                                                                          chosen_signals_and_positions = chosen_signals_and_positions)$selected_signals_corrected_positions_m_df

  expect_equal(colnames(selected_signals_corrected_positions_m_df)[-c(1:3)], current_eligible_signals)
  expect_equal(selected_signals_corrected_positions_m_df$low_vol_36m, signals_m_df@data$vol_36m*-1)


  #ts_splits
  features_m_refit <- signals_m_df@data %>% dplyr::filter(dates <= "2023-03-15") #this is to mimick ts_split behavior with a target_fwd of 3

  #custom_obj
  custom_objective <- "max_info_ratio"
  weights <- signal_transform(most_recent_signal_universe_m_d_ref$info_ratio, upper_quantile_winsorization = 0.95, lower_quantile_winsorization = 0.05)/sum(signal_transform(most_recent_signal_universe_m_d_ref$info_ratio, upper_quantile_winsorization = 0.95, lower_quantile_winsorization =  0.05))

  most_recent_signal_universe_m_d_ref[, "exp_ret_score"] <- signal_transform(most_recent_signal_universe_m_d_ref$info_ratio ,
                                                                             upper_quantile_winsorization = 0.95,
                                                                             lower_quantile_winsorization =  0.05)
  most_recent_signal_universe_m_d_ref$weights <- weights

  results <- set_portfolio_weights(port_construction_method = "sw", ,
                                   universe_m_d_ref = most_recent_signal_universe_m_d_ref %>% dplyr::select(-weights))


  expect_equal(most_recent_signal_universe_m_d_ref %>% dplyr::arrange(id), results@universe_m_d_ref@data)

  expect_equal(results@groups, NULL)
  expect_equal(results@eligible_assets, most_recent_signal_universe_m_d_ref %>% dplyr::filter(is_eligible == 1) %>% dplyr::pull(tickers))
  expect_equal(results@groups, NULL)
  expect_equal(results@exp_ret_score, most_recent_signal_universe_m_d_ref %>% dplyr::filter(is_eligible == 1) %>% dplyr::pull(exp_ret_score))
  expect_equal(results@eligible_assets, most_recent_signal_universe_m_d_ref %>% dplyr::filter(is_eligible == 1) %>% dplyr::pull(tickers))
  expect_equal(results@covariance_matrix, NULL)
  expect_equal(results@rel_risk_contr, NULL)
  expect_equal(results@port_stats$exp_ret,
               sum(results@universe_m_d_ref@data$weights * results@universe_m_d_ref@data$exp_ret_score)
  )



  #custom_obj
  custom_objective <- "min_track_err"
  weights <- signal_transform(most_recent_signal_universe_m_d_ref$track_err*-1 , upper_quantile_winsorization = 0.95, lower_quantile_winsorization = 0.05)/sum(signal_transform(most_recent_signal_universe_m_d_ref$track_err*-1 , upper_quantile_winsorization = 0.95, lower_quantile_winsorization =  0.05))

  most_recent_signal_universe_m_d_ref[, "exp_ret_score"] <- signal_transform(most_recent_signal_universe_m_d_ref$track_err*-1 , upper_quantile_winsorization = 0.95,  lower_quantile_winsorization = 0.05)
  most_recent_signal_universe_m_d_ref$weights <- weights

  results <- set_portfolio_weights(port_construction_method = "sw", universe_m_d_ref = most_recent_signal_universe_m_d_ref %>% dplyr::select(-weights))

  expect_equal(most_recent_signal_universe_m_d_ref %>% dplyr::arrange(id),results@universe_m_d_ref@data)
  expect_equal(results@groups, NULL)
  expect_equal(results@eligible_assets, most_recent_signal_universe_m_d_ref %>% dplyr::filter(is_eligible == 1) %>% dplyr::pull(tickers))
  expect_equal(results@groups, NULL)
  expect_equal(results@exp_ret_score, most_recent_signal_universe_m_d_ref %>% dplyr::filter(is_eligible == 1) %>% dplyr::pull(exp_ret_score))
  expect_equal(results@eligible_assets, most_recent_signal_universe_m_d_ref %>% dplyr::filter(is_eligible == 1) %>% dplyr::pull(tickers))
  expect_equal(results@covariance_matrix, NULL)
  expect_equal(results@rel_risk_contr, NULL)
  expect_equal(results@port_stats$exp_ret,
               sum(results@universe_m_d_ref@data$weights * results@universe_m_d_ref@data$exp_ret_score)
  )

})

test_that("set portfolio weights work for RP (signals) ", {

  #Load
  load(paste(test_path(),"/testdata/","toy_preprocessed_signal_selection_obj.RData", sep =""))
  load(paste(test_path(),"/testdata/","toy_preprocessed_signal_selection_results.RData", sep =""))

  current_date <- "2023-06-15"

  #Select and correct signals
  signal_universe_m_df <- results@signal_universe_m_df@data
  most_recent_signal_universe_m_d_ref <- signal_universe_m_df %>% dplyr::filter(dates == "2023-06-15")
  current_eligible_signals <- most_recent_signal_universe_m_d_ref$tickers
  signals_positions <- ifelse(stringr::str_detect(current_eligible_signals, "low_"), "short", "long")
  chosen_signals_and_positions <- signals_positions
  names(chosen_signals_and_positions) <- stringr::str_remove(current_eligible_signals, "low_")

  selected_signals_and_backtest_list <- select_and_correct_signals(
    signals_m_df = signals_m_df@data, chosen_signals_and_positions = chosen_signals_and_positions,
    backtest_returns_m_xts = mocked_backtest_returns_m_xts)

  selected_signals_corrected_positions_m_df <- selected_signals_and_backtest_list$selected_signals_corrected_positions_m_df
  selected_backtest_returns_corrected_positions_m_xts <- selected_signals_and_backtest_list$selected_backtest_returns_corrected_positions_m_xts
  selected_cov_matrix_benchmark_m_xts <- benchmark_returns_m_xts[, "IBOV"]

  expect_equal(colnames(selected_signals_corrected_positions_m_df)[-c(1:3)], current_eligible_signals)
  expect_equal(selected_signals_corrected_positions_m_df$low_vol_36m, signals_m_df@data$vol_36m*-1)

  selected_backtest_returns_corrected_positions_m_xts_upd_ref <- selected_backtest_returns_corrected_positions_m_xts[c(1:9),]
  selected_cov_matrix_benchmark_m_xts_upd_ref <- selected_cov_matrix_benchmark_m_xts[c(1:9), ]

  #ts_splits
  features_m_refit <- signals_m_df@data %>% dplyr::filter(dates <= "2023-03-15") #this is to mimick ts_split behavior with a target_fwd of 3

  #custom_obj
  custom_objective <- "max_info_ratio"


  #Calculate a sample cov active matrix
  selected_backtest_returns_corrected_positions_m_xts_upd_ref_active <-
    apply(selected_backtest_returns_corrected_positions_m_xts_upd_ref, 2, function(x){
      ((1+x/100)/(1+as.numeric(selected_cov_matrix_benchmark_m_xts_upd_ref)/100) - 1)*100
    })
  bench_assets_returns_m_xts_upd_ref <- selected_backtest_returns_corrected_positions_m_xts_upd_ref

  rp <- riskParityPortfolio::riskParityPortfolio(Sigma = cov(selected_backtest_returns_corrected_positions_m_xts_upd_ref_active))


  weights <- rp$w
  rrc <- relative_risk_contribution(rp$w, cov(selected_backtest_returns_corrected_positions_m_xts_upd_ref_active))
  expect_equal(rrc$rel_risk_contr, as.numeric(rp$relative_risk_contribution))
  expect_equal(rrc$tickers, names(rp$relative_risk_contribution))

  most_recent_signal_universe_m_d_ref$weights <- weights
  most_recent_signal_universe_m_d_ref <- dplyr::left_join(most_recent_signal_universe_m_d_ref, rrc, by = "tickers") %>%
    dplyr::relocate(rel_risk_contr, .before = weights)

  results <- set_portfolio_weights(port_construction_method = "rp",
                                   universe_m_d_ref = most_recent_signal_universe_m_d_ref %>%
                                     dplyr::select(-rel_risk_contr, -weights),
                                   cov_matrix_sample_size = 9, cov_estimation_method = "sample",
                                   groups_m_d_ref = NULL, active_returns = TRUE,
                                   eligible_returns_m_xts_upd_ref = selected_backtest_returns_corrected_positions_m_xts_upd_ref,
                                   bench_assets_returns_m_xts_upd_ref = bench_assets_returns_m_xts_upd_ref,
                                   selected_benchmark_m_xts_upd_ref = selected_cov_matrix_benchmark_m_xts_upd_ref,
                                   selected_benchmark = "theme_sb"
  )

  expect_equal(results@groups, NULL)
  expect_equal(results@eligible_assets, most_recent_signal_universe_m_d_ref %>% dplyr::filter(is_eligible == 1) %>% dplyr::pull(tickers))
  expect_equal(results@groups, NULL)
  expect_equal(results@exp_ret_score, NULL)
  expect_equal(results@eligible_assets, most_recent_signal_universe_m_d_ref %>% dplyr::filter(is_eligible == 1) %>% dplyr::pull(tickers))
  expect_equal(results@covariance_matrix, cov(selected_backtest_returns_corrected_positions_m_xts_upd_ref_active))
  expect_equal(results@rel_risk_contr, rrc$rel_risk_contr)

  act_w <- most_recent_signal_universe_m_d_ref$weights - most_recent_signal_universe_m_d_ref$theme_sb_bench_weights
  cov_matrix <- estimate_covariance_matrix(tickers = results@eligible_assets,
                                           returns_m_xts_upd_ref =
                                             selected_backtest_returns_corrected_positions_m_xts_upd_ref,
                                           cov_estimation_method = "sample",
                                           cov_matrix_sample_size = 9,
                                           active_returns = FALSE)
  expect_equal(results@port_stats$act_risk,
               as.numeric(sqrt(t(act_w) %*% cov_matrix %*% act_w)))
  expect_equal(results@port_stats$act_diversification_ratio,
               sum(sqrt(diag(cov_matrix)) * abs(act_w))/ results@port_stats$act_risk
               )

  # Now for benchmark
  expect_equal(
    results@selected_benchmark_port@port_stats$risk,
    as.numeric(sqrt(t(most_recent_signal_universe_m_d_ref$theme_sb_bench_weights) %*% cov_matrix %*% most_recent_signal_universe_m_d_ref$theme_sb_bench_weights))
  )
  expect_equal(
    results@selected_benchmark_port@port_stats$hhi_weights,
    sum(most_recent_signal_universe_m_d_ref$theme_sb_bench_weights^2)
  )
  expect_equal(
    results@selected_benchmark_port@port_stats$hhi_rrc,
    sum((relative_risk_contribution(most_recent_signal_universe_m_d_ref$theme_sb_bench_weights, cov_matrix)$rel_risk_contr)^2)
  )

  most_recent_signal_universe_m_d_ref <- most_recent_signal_universe_m_d_ref %>%
    dplyr::mutate(
      act_rel_risk_contr = relative_risk_contribution(act_w, cov_matrix)$rel_risk_contr,
      act_weights = act_w
    )

  expect_equal(most_recent_signal_universe_m_d_ref %>% dplyr::arrange(id), results@universe_m_d_ref@data)



})

test_that("set portfolio weights work for RP + exp_ret_score_tilt ('inner') (signals)", {

  #Load
  load(paste(test_path(),"/testdata/","toy_preprocessed_signal_selection_obj.RData", sep =""))
  load(paste(test_path(),"/testdata/","toy_preprocessed_signal_selection_results.RData", sep =""))

  current_date <- "2023-06-15"

  #Select and correct signals
  signal_universe_m_df <- results@signal_universe_m_df@data
  most_recent_signal_universe_m_d_ref <- signal_universe_m_df %>% dplyr::filter(dates == "2023-06-15")
  current_eligible_signals <- most_recent_signal_universe_m_d_ref$tickers
  signals_positions <- ifelse(stringr::str_detect(current_eligible_signals, "low_"), "short", "long")
  chosen_signals_and_positions <- signals_positions
  names(chosen_signals_and_positions) <- stringr::str_remove(current_eligible_signals, "low_")

  selected_signals_and_backtest_list <- select_and_correct_signals(
    signals_m_df = signals_m_df@data, chosen_signals_and_positions = chosen_signals_and_positions,
    backtest_returns_m_xts = mocked_backtest_returns_m_xts)

  selected_signals_corrected_positions_m_df <- selected_signals_and_backtest_list$selected_signals_corrected_positions_m_df
  selected_backtest_returns_corrected_positions_m_xts <- selected_signals_and_backtest_list$selected_backtest_returns_corrected_positions_m_xts
  selected_cov_matrix_benchmark_m_xts <- benchmark_returns_m_xts[, "IBOV"]

  expect_equal(colnames(selected_signals_corrected_positions_m_df)[-c(1:3)], current_eligible_signals)
  expect_equal(selected_signals_corrected_positions_m_df$low_vol_36m, signals_m_df@data$vol_36m*-1)

  selected_backtest_returns_corrected_positions_m_xts_upd_ref <- selected_backtest_returns_corrected_positions_m_xts[c(1:9),]
  selected_cov_matrix_benchmark_m_xts_upd_ref <- selected_cov_matrix_benchmark_m_xts[c(1:9), ]

  #ts_splits
  features_m_refit <- signals_m_df@data %>% dplyr::filter(dates <= "2023-03-15") #this is to mimick ts_split behavior with a target_fwd of 3

  #custom_obj
  custom_objective <- "max_info_ratio"

  #Calculate a sample cov active matrix
  selected_backtest_returns_corrected_positions_m_xts_upd_ref_active <-
    apply(selected_backtest_returns_corrected_positions_m_xts_upd_ref, 2, function(x){
      ((1+x/100)/(1+as.numeric(selected_cov_matrix_benchmark_m_xts_upd_ref)/100) - 1)*100
    })

  #exp ret score
  most_recent_signal_universe_m_d_ref[, "exp_ret_score"] <- signal_transform(most_recent_signal_universe_m_d_ref$info_ratio ,
                                                                             upper_quantile_winsorization = 0.95,
                                                                             lower_quantile_winsorization =  0.05)

  #RP
  exp_ret_score <- most_recent_signal_universe_m_d_ref$exp_ret_score
  exp_ret_score_tilt_eta <- 0.5
  exp_ret_score_tilt <- "inner"

  cov_matrix <- cov(selected_backtest_returns_corrected_positions_m_xts_upd_ref_active)
  rp <- riskParityPortfolio::riskParityPortfolio(Sigma = cov_matrix,
                                                 lmd_mu = exp_ret_score_tilt_eta,
                                                 mu = exp_ret_score)

  #Relative Risk Contribution and Weights from rp
  most_recent_signal_universe_m_d_ref$rel_risk_contr <- rp$relative_risk_contribution
  most_recent_signal_universe_m_d_ref$weights <- rp$w

  exp_ret_score <- most_recent_signal_universe_m_d_ref$exp_ret_score

  #Set portfolio weights
  results <- set_portfolio_weights(port_construction_method = "rp",
                                   universe_m_d_ref = most_recent_signal_universe_m_d_ref %>%
                                     dplyr::select(-weights, -rel_risk_contr),
                                   cov_matrix_sample_size = 9, cov_estimation_method = "sample", groups_m_d_ref = NULL, active_returns = TRUE,
                                   exp_ret_score_tilt = exp_ret_score_tilt, exp_ret_score_tilt_eta,
                                   eligible_returns_m_xts_upd_ref = selected_backtest_returns_corrected_positions_m_xts_upd_ref,
                                   selected_benchmark_m_xts_upd_ref = selected_cov_matrix_benchmark_m_xts_upd_ref,
                                   exp_ret_score_tilt_eta = exp_ret_score_tilt_eta,
                                   exp_ret_score = exp_ret_score,
                                   selected_benchmark = "theme_sb"
  )

  expect_equal(most_recent_signal_universe_m_d_ref %>% dplyr::arrange(id),
               results@universe_m_d_ref@data %>% dplyr::select(-act_weights, -act_rel_risk_contr)
               )

  #Rel Risk Contribution is not the same across rows
  expect_true(all(
    (most_recent_signal_universe_m_d_ref$rel_risk_contr != most_recent_signal_universe_m_d_ref$rel_risk_contr[1])[-1] #First is obviously TRUE
    ))

  #Test that in relation to vanilla rp, there is a bias towards high exp_ret_score
  rp_vanilla <- riskParityPortfolio::riskParityPortfolio(Sigma = cov_matrix)
  weights_vanilla <- rp_vanilla$w
  weight_diff <- results@weights - weights_vanilla

  #Check that weight_diff is higher for signals with exp_ret_score above median
  exp_ret_score_median <- median(most_recent_signal_universe_m_d_ref$exp_ret_score)
  weight_diff_above_median <- weight_diff[which(most_recent_signal_universe_m_d_ref$exp_ret_score > exp_ret_score_median)]
  weight_diff_below_median <- weight_diff[which(most_recent_signal_universe_m_d_ref$exp_ret_score <= exp_ret_score_median)]
  expect_true(mean(weight_diff_above_median) > mean(weight_diff_below_median))

})

test_that("set portfolio weights work for HRP (signals)", {

  #Load
  load(paste(test_path(),"/testdata/","toy_preprocessed_signal_selection_obj.RData", sep =""))
  load(paste(test_path(),"/testdata/","toy_preprocessed_signal_selection_results.RData", sep =""))

  current_date <- "2023-06-15"

  #Select and correct signals
  signal_universe_m_df <- results@signal_universe_m_df@data
  most_recent_signal_universe_m_d_ref <- signal_universe_m_df %>% dplyr::filter(dates == "2023-06-15")
  current_eligible_signals <- most_recent_signal_universe_m_d_ref$tickers
  signals_positions <- ifelse(stringr::str_detect(current_eligible_signals, "low_"), "short", "long")
  chosen_signals_and_positions <- signals_positions
  names(chosen_signals_and_positions) <- stringr::str_remove(current_eligible_signals, "low_")

  selected_signals_and_backtest_list <- select_and_correct_signals(
    signals_m_df = signals_m_df@data, chosen_signals_and_positions = chosen_signals_and_positions,
    backtest_returns_m_xts = mocked_backtest_returns_m_xts)

  selected_signals_corrected_positions_m_df <- selected_signals_and_backtest_list$selected_signals_corrected_positions_m_df
  selected_backtest_returns_corrected_positions_m_xts <- selected_signals_and_backtest_list$selected_backtest_returns_corrected_positions_m_xts
  selected_cov_matrix_benchmark_m_xts <- benchmark_returns_m_xts[, "IBOV"]

  expect_equal(colnames(selected_signals_corrected_positions_m_df)[-c(1:3)], current_eligible_signals)
  expect_equal(selected_signals_corrected_positions_m_df$low_vol_36m, signals_m_df@data$vol_36m*-1)

  selected_backtest_returns_corrected_positions_m_xts_upd_ref <- selected_backtest_returns_corrected_positions_m_xts[c(1:9),]
  selected_cov_matrix_benchmark_m_xts_upd_ref <- selected_cov_matrix_benchmark_m_xts[c(1:9), ]

  #ts_splits
  features_m_refit <- signals_m_df@data %>% dplyr::filter(dates <= "2023-03-15") #this is to mimick ts_split behavior with a target_fwd of 3

  #custom_obj
  custom_objective <- "max_info_ratio"


  #Calculate a sample cov active matrix
  selected_backtest_returns_corrected_positions_m_xts_upd_ref_active <-
    apply(selected_backtest_returns_corrected_positions_m_xts_upd_ref, 2, function(x){
      ((1+x/100)/(1+as.numeric(selected_cov_matrix_benchmark_m_xts_upd_ref)/100) - 1)*100
    })

  covariance_matrix <- cov(selected_backtest_returns_corrected_positions_m_xts_upd_ref_active)
  correlation_matrix <- stats::cov2cor(covariance_matrix)

  distance <- sqrt(0.5 * (1 - correlation_matrix))
  euclidean_distance <- stats::dist(distance, method = "euclidean", diag = TRUE, upper = TRUE, p = 2)
  hc <- stats::hclust(euclidean_distance, method = "single", member = NULL)
  hc_order <- hc$order
  Sigma_ord <- covariance_matrix[hc_order, hc_order]

  # Bisection algorithm
  w <- rep(1, ncol(covariance_matrix))

  #Start at top level
  index_L <- c(1,2)
  index_R <- c(3,4,5)
  cov_L <- Sigma_ord[index_L, index_L, drop = FALSE]
  cov_R <- Sigma_ord[index_R, index_R, drop = FALSE]
  w_L <- 1/diag(cov_L)/sum(1/diag(cov_L))
  w_R <- 1/diag(cov_R)/sum(1/diag(cov_R))
  var_L <- as.numeric(t(w_L) %*% cov_L %*% w_L)
  var_R <- as.numeric(t(w_R) %*% cov_R %*% w_R)
  alpha <- 1 - (var_L/(var_L + var_R))
  w[index_L] <- w[index_L] * alpha
  w[index_R] <- w[index_R] * (1 - alpha)

  #1
  index_L1 <- c(1)
  index_R1 <- c(2)
  cov_L1 <- Sigma_ord[index_L1, index_L1, drop = FALSE]
  cov_R1 <- Sigma_ord[index_R1, index_R1, drop = FALSE]
  var_L1 <- as.numeric(cov_L1)
  var_R1 <- as.numeric(cov_R1)
  alpha1 <- 1 - (var_L1/(var_L1 + var_R1))
  w[index_L1] <- w[index_L1] * alpha1
  w[index_R1] <- w[index_R1] * (1 - alpha1)

  #2
  index_L2 <- c(3)
  index_R2 <- c(4,5)
  cov_L2 <- Sigma_ord[index_L2, index_L2, drop = FALSE]
  cov_R2 <- Sigma_ord[index_R2, index_R2, drop = FALSE]
  w_R2 <- 1/diag(cov_R2)/sum(1/diag(cov_R2))
  var_L2 <- as.numeric(cov_L2)
  var_R2 <- as.numeric(t(w_R2) %*% cov_R2 %*% w_R2)
  alpha2 <- 1 - (var_L2/(var_L2 + var_R2))
  w[index_L2] <- w[index_L2] * alpha2
  w[index_R2] <- w[index_R2] * (1 - alpha2)

  #3
  index_L3 <- c(4)
  index_R3 <- c(5)
  cov_L3 <- Sigma_ord[index_L3, index_L3, drop = FALSE]
  cov_R3 <- Sigma_ord[index_R3, index_R3, drop = FALSE]
  var_L3 <- as.numeric(cov_L3)
  var_R3 <- as.numeric(cov_R3)
  alpha3 <- 1 - (var_L3/(var_L3 + var_R3))
  w[index_L3] <- w[index_L3] * alpha3
  w[index_R3] <- w[index_R3] * (1 - alpha3)
  names(w) <- colnames(covariance_matrix)[hc_order]

  #Add rel risk contr
  rel_risk_contr <- relative_risk_contribution(w[colnames(covariance_matrix)], covariance_matrix)
  most_recent_signal_universe_m_d_ref$rel_risk_contr <- rel_risk_contr$rel_risk_contr
  most_recent_signal_universe_m_d_ref$weights <- w[colnames(covariance_matrix)]

  results <- set_portfolio_weights(port_construction_method = "hrp",
                                   universe_m_d_ref = most_recent_signal_universe_m_d_ref %>%
                                     dplyr::select(-rel_risk_contr, -weights),
                                   cov_matrix_sample_size = 9, cov_estimation_method = "sample", groups_m_d_ref = NULL, active_returns = TRUE,
                                   eligible_returns_m_xts_upd_ref = selected_backtest_returns_corrected_positions_m_xts_upd_ref,
                                   bench_assets_returns_m_xts_upd_ref = selected_backtest_returns_corrected_positions_m_xts_upd_ref,
                                   selected_benchmark_m_xts_upd_ref = selected_cov_matrix_benchmark_m_xts_upd_ref
  )

  expect_equal(most_recent_signal_universe_m_d_ref %>% dplyr::arrange(id), results@universe_m_d_ref@data)
  expect_equal(results@groups, NULL)
  expect_equal(results@eligible_assets,
               most_recent_signal_universe_m_d_ref %>% dplyr::filter(is_eligible == 1) %>% dplyr::pull(tickers))
  expect_equal(results@groups, NULL)
  expect_equal(results@exp_ret_score, NULL)
  expect_equal(results@covariance_matrix, cov(selected_backtest_returns_corrected_positions_m_xts_upd_ref_active))
  expect_equal(results@rel_risk_contr, rel_risk_contr$rel_risk_contr)
  expect_equal(results@clusters$order, hc$order)
  expect_equal(results@clusters$height, hc$height)
  expect_equal(results@clusters$merge, hc$merge)
  expect_equal(results@clusters$labels, hc$labels)


})

test_that("set portfolio weights work for HRP + exp_ret_score_tilt ('inner') (signals)", {

  #Load
  load(paste(test_path(),"/testdata/","toy_preprocessed_signal_selection_obj.RData", sep =""))
  load(paste(test_path(),"/testdata/","toy_preprocessed_signal_selection_results.RData", sep =""))

  current_date <- "2023-06-15"

  #Select and correct signals
  signal_universe_m_df <- results@signal_universe_m_df@data
  most_recent_signal_universe_m_d_ref <- signal_universe_m_df %>% dplyr::filter(dates == "2023-06-15")
  current_eligible_signals <- most_recent_signal_universe_m_d_ref$tickers
  signals_positions <- ifelse(stringr::str_detect(current_eligible_signals, "low_"), "short", "long")
  chosen_signals_and_positions <- signals_positions
  names(chosen_signals_and_positions) <- stringr::str_remove(current_eligible_signals, "low_")

  selected_signals_and_backtest_list <- select_and_correct_signals(
    signals_m_df = signals_m_df@data, chosen_signals_and_positions = chosen_signals_and_positions,
    backtest_returns_m_xts = mocked_backtest_returns_m_xts)

  selected_signals_corrected_positions_m_df <- selected_signals_and_backtest_list$selected_signals_corrected_positions_m_df
  selected_backtest_returns_corrected_positions_m_xts <- selected_signals_and_backtest_list$selected_backtest_returns_corrected_positions_m_xts
  selected_cov_matrix_benchmark_m_xts <- benchmark_returns_m_xts[, "IBOV"]

  expect_equal(colnames(selected_signals_corrected_positions_m_df)[-c(1:3)], current_eligible_signals)
  expect_equal(selected_signals_corrected_positions_m_df$low_vol_36m, signals_m_df@data$vol_36m*-1)

  selected_backtest_returns_corrected_positions_m_xts_upd_ref <- selected_backtest_returns_corrected_positions_m_xts[c(1:9),]
  selected_cov_matrix_benchmark_m_xts_upd_ref <- selected_cov_matrix_benchmark_m_xts[c(1:9), ]

  #ts_splits
  features_m_refit <- signals_m_df@data %>% dplyr::filter(dates <= "2023-03-15") #this is to mimick ts_split behavior with a target_fwd of 3

  #custom_obj
  custom_objective <- "min_act_dd_dev"


  #Calculate an ewma cov active matrix
  selected_backtest_returns_corrected_positions_m_xts_upd_ref_active <-
    apply(selected_backtest_returns_corrected_positions_m_xts_upd_ref, 2, function(x){
      ((1+x/100)/(1+as.numeric(selected_cov_matrix_benchmark_m_xts_upd_ref)/100) - 1)*100
    })

  covariance_matrix <- PerformanceAnalytics::M2.ewma(selected_backtest_returns_corrected_positions_m_xts_upd_ref_active)

  #exp_ret_score
  exp_ret_score <- most_recent_signal_universe_m_d_ref$act_dd_dev*-1
  exp_ret_score <- exp_ret_score %>% signal_transform(0.05, 0.95)
  exp_ret_score_tilt_eta <- 0.5
  exp_ret_score_tilt <- "inner"
  most_recent_signal_universe_m_d_ref$exp_ret_score <- exp_ret_score

  correlation_matrix <- stats::cov2cor(covariance_matrix)

  distance <- sqrt(0.5 * (1 - correlation_matrix))
  euclidean_distance <- stats::dist(distance, method = "euclidean", diag = TRUE, upper = TRUE, p = 2)
  hc <- stats::hclust(euclidean_distance, method = "single", member = NULL)
  hc_order <- hc$order
  Sigma_ord <- covariance_matrix[hc_order, hc_order]

  # Bisection algorithm
  w <- rep(1, ncol(covariance_matrix))
  exp_ret_score <- most_recent_signal_universe_m_d_ref$exp_ret_score[hc_order]
  names(exp_ret_score) <- colnames(covariance_matrix)[hc_order]

  #Start at top level
  index_L <- c(1,2)
  index_R <- c(3,4,5)
  cov_L <- Sigma_ord[index_L, index_L, drop = FALSE]
  cov_R <- Sigma_ord[index_R, index_R, drop = FALSE]
  w_L <- 1/diag(cov_L)/sum(1/diag(cov_L))
  w_R <- 1/diag(cov_R)/sum(1/diag(cov_R))
  var_L <- as.numeric(t(w_L) %*% cov_L %*% w_L)
  var_R <- as.numeric(t(w_R) %*% cov_R %*% w_R)
  mu_L <- sum(w_L * exp_ret_score[index_L])
  mu_R <- sum(w_R * exp_ret_score[index_R])
  rank <- c(mu_L, mu_R) %>% rank(ties.method = "average")
  gL <- rank[1]/2
  gR <- rank[2]/2
  A_L <- (1/var_L)*(gL^exp_ret_score_tilt_eta)
  A_R <- (1/var_R)*(gR^exp_ret_score_tilt_eta)
  alpha <- (A_L/(A_L + A_R))
  w[index_L] <- w[index_L] * alpha
  w[index_R] <- w[index_R] * (1 - alpha)

  #1
  index_L1 <- c(1)
  index_R1 <- c(2)
  cov_L1 <- Sigma_ord[index_L1, index_L1, drop = FALSE]
  cov_R1 <- Sigma_ord[index_R1, index_R1, drop = FALSE]
  var_L1 <- as.numeric(cov_L1)
  var_R1 <- as.numeric(cov_R1)
  mu_L1 <- exp_ret_score[index_L1]
  mu_R1 <- exp_ret_score[index_R1]
  rank1 <- c(mu_L1, mu_R1) %>% rank(ties.method = "average")
  gL1 <- rank1[1]/2
  gR1 <- rank1[2]/2
  A_L1 <- (1/var_L1)*(gL1^exp_ret_score_tilt_eta)
  A_R1 <- (1/var_R1)*(gR1^exp_ret_score_tilt_eta)
  alpha1 <- (A_L1/(A_L1 + A_R1))
  w[index_L1] <- w[index_L1] * alpha1
  w[index_R1] <- w[index_R1] * (1 - alpha1)

  #2
  index_L2 <- c(3)
  index_R2 <- c(4,5)
  cov_L2 <- Sigma_ord[index_L2, index_L2, drop = FALSE]
  cov_R2 <- Sigma_ord[index_R2, index_R2, drop = FALSE]
  w_R2 <- 1/diag(cov_R2)/sum(1/diag(cov_R2))
  var_L2 <- as.numeric(cov_L2)
  var_R2 <- as.numeric(t(w_R2) %*% cov_R2 %*% w_R2)
  mu_L2 <- exp_ret_score[index_L2]
  mu_R2 <- sum(w_R2 * exp_ret_score[index_R2])
  rank2 <- c(mu_L2, mu_R2) %>% rank(ties.method = "average")
  gL2 <- rank2[1]/2
  gR2 <- rank2[2]/2
  A_L2 <- (1/var_L2)*(gL2^exp_ret_score_tilt_eta)
  A_R2 <- (1/var_R2)*(gR2^exp_ret_score_tilt_eta)
  alpha2 <- (A_L2/(A_L2 + A_R2))
  w[index_L2] <- w[index_L2] * alpha2
  w[index_R2] <- w[index_R2] * (1 - alpha2)

  #3
  index_L3 <- c(4)
  index_R3 <- c(5)
  cov_L3 <- Sigma_ord[index_L3, index_L3, drop = FALSE]
  cov_R3 <- Sigma_ord[index_R3, index_R3, drop = FALSE]
  var_L3 <- as.numeric(cov_L3)
  var_R3 <- as.numeric(cov_R3)
  mu_L3 <- exp_ret_score[index_L3]
  mu_R3 <- exp_ret_score[index_R3]
  rank3 <- c(mu_L3, mu_R3) %>% rank(ties.method = "average")
  gL3 <- rank3[1]/2
  gR3 <- rank3[2]/2
  A_L3 <- (1/var_L3)*(gL3^exp_ret_score_tilt_eta)
  A_R3 <- (1/var_R3)*(gR3^exp_ret_score_tilt_eta)
  alpha3 <- (A_L3/(A_L3 + A_R3))
  w[index_L3] <- w[index_L3] * alpha3
  w[index_R3] <- w[index_R3] * (1 - alpha3)

  names(w) <- colnames(covariance_matrix)[hc_order]

  #Add rel risk contr
  rel_risk_contr <- relative_risk_contribution(w[colnames(covariance_matrix)], covariance_matrix)
  most_recent_signal_universe_m_d_ref$rel_risk_contr <- rel_risk_contr$rel_risk_contr
  most_recent_signal_universe_m_d_ref$weights <- w[colnames(covariance_matrix)]

  results <- set_portfolio_weights(port_construction_method = "hrp",
                                   universe_m_d_ref = most_recent_signal_universe_m_d_ref %>%
                                     dplyr::select(-rel_risk_contr, -weights),
                                   exp_ret_score_tilt = exp_ret_score_tilt, exp_ret_score_tilt_eta = exp_ret_score_tilt_eta,
                                   cov_matrix_sample_size = 9, cov_estimation_method = "ewma", groups_m_d_ref = NULL, active_returns = TRUE,
                                   eligible_returns_m_xts_upd_ref = selected_backtest_returns_corrected_positions_m_xts_upd_ref,
                                   selected_benchmark_m_xts_upd_ref = selected_cov_matrix_benchmark_m_xts_upd_ref
  )

  expect_equal(most_recent_signal_universe_m_d_ref %>% dplyr::arrange(id), results@universe_m_d_ref@data)
  expect_equal(results@groups, NULL)
  expect_equal(results@eligible_assets, most_recent_signal_universe_m_d_ref %>% dplyr::filter(is_eligible == 1) %>% dplyr::pull(tickers))
  expect_equal(results@groups, NULL)
  expect_equal(results@exp_ret_score, most_recent_signal_universe_m_d_ref$exp_ret_score)
  expect_equal(results@eligible_assets, most_recent_signal_universe_m_d_ref %>% dplyr::filter(is_eligible == 1) %>% dplyr::pull(tickers))
  expect_equal(results@covariance_matrix, covariance_matrix)
  expect_equal(results@rel_risk_contr, rel_risk_contr$rel_risk_contr)
  expect_equal(results@clusters$order, hc$order)
  expect_equal(results@clusters$height, hc$height)
  expect_equal(results@clusters$merge, hc$merge)
  expect_equal(results@clusters$labels, hc$labels)


  #Test that results have a bias towards assets with high exp_ret_score
  results_alt <- set_portfolio_weights(port_construction_method = "hrp",
                                   universe_m_d_ref = most_recent_signal_universe_m_d_ref %>%
                                     dplyr::select(-rel_risk_contr, -weights),
                                   exp_ret_score_tilt = NULL, exp_ret_score_tilt_eta = NULL,
                                   cov_matrix_sample_size = 9, cov_estimation_method = "ewma", groups_m_d_ref = NULL, active_returns = TRUE,
                                   eligible_returns_m_xts_upd_ref = selected_backtest_returns_corrected_positions_m_xts_upd_ref,
                                   selected_benchmark_m_xts_upd_ref = selected_cov_matrix_benchmark_m_xts_upd_ref
  )

  ## Compare weight difference between results and results_alt and see if results has higher weights for assets with higher exp_ret_score
  weight_diff <- results@universe_m_d_ref@data$weights - results_alt@universe_m_d_ref@data$weights
  exp_ret_score <- most_recent_signal_universe_m_d_ref$exp_ret_score

  # See if difference is positive for assets with above median exp_ret_score and negative for those below median
  median_exp_ret_score <- median(exp_ret_score)
  above_median <- exp_ret_score > median_exp_ret_score
  below_median <- exp_ret_score <= median_exp_ret_score
  expect_true(sum(weight_diff[above_median]) >= 0)  # Weights should be higher for above median exp_ret_score

})

test_that("set portfolio weights work for MVO (signals) - unconstrained", {

  #Load
  load(paste(test_path(),"/testdata/","toy_preprocessed_signal_selection_obj.RData", sep =""))
  load(paste(test_path(),"/testdata/","toy_preprocessed_signal_selection_results.RData", sep =""))

  current_date <- "2023-06-15"

  #Select and correct signals
  signal_universe_m_df <- results@signal_universe_m_df@data
  most_recent_signal_universe_m_d_ref <- signal_universe_m_df %>% dplyr::filter(dates == "2023-06-15")
  current_eligible_signals <- most_recent_signal_universe_m_d_ref$tickers
  signals_positions <- ifelse(stringr::str_detect(current_eligible_signals, "low_"), "short", "long")
  chosen_signals_and_positions <- signals_positions
  names(chosen_signals_and_positions) <- stringr::str_remove(current_eligible_signals, "low_")

  selected_signals_and_backtest_list <- select_and_correct_signals(
    signals_m_df = signals_m_df@data, chosen_signals_and_positions = chosen_signals_and_positions,
    backtest_returns_m_xts = mocked_backtest_returns_m_xts)

  selected_signals_corrected_positions_m_df <- selected_signals_and_backtest_list$selected_signals_corrected_positions_m_df
  selected_backtest_returns_corrected_positions_m_xts <- selected_signals_and_backtest_list$selected_backtest_returns_corrected_positions_m_xts
  selected_cov_matrix_benchmark_m_xts <- benchmark_returns_m_xts[, "IBOV"]

  expect_equal(colnames(selected_signals_corrected_positions_m_df)[-c(1:3)], current_eligible_signals)
  expect_equal(selected_signals_corrected_positions_m_df$low_vol_36m, signals_m_df@data$vol_36m*-1)

  selected_backtest_returns_corrected_positions_m_xts_upd_ref <- selected_backtest_returns_corrected_positions_m_xts[c(1:9),]
  selected_cov_matrix_benchmark_m_xts_upd_ref <- selected_cov_matrix_benchmark_m_xts[c(1:9), ]

  #ts_splits
  features_m_refit <- signals_m_df@data %>% dplyr::filter(dates <= "2023-03-15") #this is to mimick ts_split behavior with a target_fwd of 3

  #custom_obj
  custom_objective <- "min_act_dd_dev"


  #Calculate an ewma cov active matrix
  selected_backtest_returns_corrected_positions_m_xts_upd_ref_active <-
    apply(selected_backtest_returns_corrected_positions_m_xts_upd_ref, 2, function(x){
      ((1+x/100)/(1+as.numeric(selected_cov_matrix_benchmark_m_xts_upd_ref)/100) - 1)*100
    })

  ewma_cov <- PerformanceAnalytics::M2.ewma(selected_backtest_returns_corrected_positions_m_xts_upd_ref_active)

  #exp_ret_score
  exp_ret_score <- most_recent_signal_universe_m_d_ref$act_dd_dev*-1
  exp_ret_score <- exp_ret_score %>% signal_transform(0.05, 0.95)
  most_recent_signal_universe_m_d_ref$exp_ret_score <- exp_ret_score

  #Port Spec
  port_spec <- PortfolioAnalytics::portfolio.spec(assets = most_recent_signal_universe_m_d_ref$tickers)
  port_spec <- PortfolioAnalytics::add.constraint(port_spec, type = "full_investment")
  port_spec <- PortfolioAnalytics::add.constraint(port_spec, type = "box")

  set.seed(123)
  random_weights <- PortfolioAnalytics::random_portfolios(
    portfolio = port_spec,
    permutations = 2000,
    "sample"
  )



  #Expected returns
  returns <- random_weights %>% apply(1, function(row){
    sum(row * exp_ret_score)
  })

  #Expected risk
  risk <- random_weights %>% apply(1, function(row){
    sqrt(t(as.matrix(row)) %*% ewma_cov %*% as.matrix(row))
  })

  #sharpe
  sharpe = returns/risk
  opt_w <- random_weights[which.max(sharpe),]
  rrc <- relative_risk_contribution(opt_w, ewma_cov)
  most_recent_signal_universe_m_d_ref$rel_risk_contr <- rrc$rel_risk_contr
  most_recent_signal_universe_m_d_ref$weights <- opt_w


  set.seed(123)
  results <- set_portfolio_weights(port_construction_method = "mvo", universe_m_d_ref = most_recent_signal_universe_m_d_ref %>%
                                     dplyr::select(-rel_risk_contr, -weights),
                                   cov_matrix_sample_size = 9, cov_estimation_method = "ewma", groups_m_d_ref = NULL, active_returns = TRUE,
                                   eligible_returns_m_xts_upd_ref = selected_backtest_returns_corrected_positions_m_xts_upd_ref,
                                   selected_benchmark_m_xts_upd_ref = selected_cov_matrix_benchmark_m_xts_upd_ref)

  expect_equal(most_recent_signal_universe_m_d_ref %>% dplyr::arrange(id), results@universe_m_d_ref@data)
  expect_equal(results@groups, NULL)
  expect_equal(results@eligible_assets, most_recent_signal_universe_m_d_ref %>% dplyr::filter(is_eligible == 1) %>% dplyr::pull(tickers))
  expect_equal(results@groups, NULL)
  expect_equal(results@exp_ret_score, most_recent_signal_universe_m_d_ref %>% dplyr::filter(is_eligible == 1) %>% dplyr::pull(exp_ret_score))
  expect_equal(results@eligible_assets, most_recent_signal_universe_m_d_ref %>% dplyr::filter(is_eligible == 1) %>% dplyr::pull(tickers))
  expect_equal(results@covariance_matrix, ewma_cov)
  expect_equal(results@rel_risk_contr, rrc$rel_risk_contr)

})

test_that("set portfolio weights work for MVO (signals) - constrained (individual)", {

  #Load
  load(paste(test_path(),"/testdata/","toy_preprocessed_signal_selection_obj.RData", sep =""))
  load(paste(test_path(),"/testdata/","toy_preprocessed_signal_selection_results.RData", sep =""))

  current_date <- "2023-06-15"

  #Select and correct signals
  signal_universe_m_df <- results@signal_universe_m_df@data
  most_recent_signal_universe_m_d_ref <- signal_universe_m_df %>% dplyr::filter(dates == "2023-06-15")
  current_eligible_signals <- most_recent_signal_universe_m_d_ref$tickers
  signals_positions <- ifelse(stringr::str_detect(current_eligible_signals, "low_"), "short", "long")
  chosen_signals_and_positions <- signals_positions
  names(chosen_signals_and_positions) <- stringr::str_remove(current_eligible_signals, "low_")

  selected_signals_and_backtest_list <- select_and_correct_signals(
    signals_m_df = signals_m_df@data, chosen_signals_and_positions = chosen_signals_and_positions,
    backtest_returns_m_xts = mocked_backtest_returns_m_xts,
    signal_themes_m_df = signal_themes_m_df@data
  )

  selected_signals_corrected_positions_m_df <- selected_signals_and_backtest_list$selected_signals_corrected_positions_m_df
  selected_backtest_returns_corrected_positions_m_xts <- selected_signals_and_backtest_list$selected_backtest_returns_corrected_positions_m_xts
  selected_signal_themes_m_df <- selected_signals_and_backtest_list$selected_signal_themes_m_df
  selected_cov_matrix_benchmark_m_xts <- benchmark_returns_m_xts[, "IBOV"]

  expect_equal(colnames(selected_signals_corrected_positions_m_df)[-c(1:3)], current_eligible_signals)
  expect_equal(selected_signals_corrected_positions_m_df$low_vol_36m, signals_m_df@data$vol_36m*-1)

  selected_backtest_returns_corrected_positions_m_xts_upd_ref <- selected_backtest_returns_corrected_positions_m_xts[c(1:9),]
  selected_cov_matrix_benchmark_m_xts_upd_ref <- selected_cov_matrix_benchmark_m_xts[c(1:9), ]
  selected_signal_themes_m_d_ref <- selected_signal_themes_m_df %>% dplyr::filter(dates == current_date)

  #ts_splits
  features_m_refit <- signals_m_df@data %>% dplyr::filter(dates <= "2023-03-15") #this is to mimick ts_split behavior with a target_fwd of 3

  #custom_obj
  custom_objective <- "min_act_dd_dev"


  #Calculate an ewma cov active matrix
  selected_backtest_returns_corrected_positions_m_xts_upd_ref_active <-
    apply(selected_backtest_returns_corrected_positions_m_xts_upd_ref, 2, function(x){
      ((1+x/100)/(1+as.numeric(selected_cov_matrix_benchmark_m_xts_upd_ref)/100) - 1)*100
    })

  pca2_cov <- PortfolioAnalytics::statistical.factor.model(
    selected_backtest_returns_corrected_positions_m_xts_upd_ref_active, round(log(5))) %>% PortfolioAnalytics::extractCovariance()

  #exp_ret_score
  exp_ret_score <- most_recent_signal_universe_m_d_ref$act_dd_dev*-1
  exp_ret_score <- exp_ret_score %>% signal_transform(0.05, 0.95)
  most_recent_signal_universe_m_d_ref$exp_ret_score <- exp_ret_score

  #Port Spec
  port_spec <- PortfolioAnalytics::portfolio.spec(assets = most_recent_signal_universe_m_d_ref$tickers)
  port_spec <- PortfolioAnalytics::add.constraint(port_spec, type = "full_investment")
  port_spec <- PortfolioAnalytics::add.constraint(port_spec, type = "box",
                                                  min = pmax(most_recent_signal_universe_m_d_ref$theme_sb_bench_weights - 0.2,
                                                             0),
                                                  max = most_recent_signal_universe_m_d_ref$theme_sb_bench_weights + 0.2)


  most_recent_signal_universe_m_d_ref$max_weight <- most_recent_signal_universe_m_d_ref$theme_sb_bench_weights + 0.2
  most_recent_signal_universe_m_d_ref$min_weight <- pmax(most_recent_signal_universe_m_d_ref$theme_sb_bench_weights - 0.2,
                                                         0)

  set.seed(123)
  random_weights <- PortfolioAnalytics::random_portfolios(
    portfolio = port_spec,
    permutations = 2000,
    "sample"
  )

  #Expected returns
  returns <- random_weights %>% apply(1, function(row){
    sum(row * exp_ret_score)
  })

  #Expected risk
  risk <- random_weights %>% apply(1, function(row){
    sqrt(t(as.matrix(row)) %*% pca2_cov %*% as.matrix(row))
  })

  #sharpe
  sharpe = returns/risk
  opt_w <- random_weights[which.max(returns),]
  rrc <- relative_risk_contribution(opt_w, pca2_cov)

  most_recent_signal_universe_m_d_ref$rel_risk_contr <- rrc$rel_risk_contr
  most_recent_signal_universe_m_d_ref$weights <- opt_w


  #get optimal port
  concentration_constraint_policy <- list(
    benchmark = "theme_sb",
    max_abs_active_individual_weight = 0.2,
    max_abs_active_group_weight = NULL
  )

  set.seed(123)
  results <- set_portfolio_weights(port_construction_method = "mvo",
                                   universe_m_d_ref = most_recent_signal_universe_m_d_ref %>%
                                     dplyr::select(-max_weight, -min_weight, -weights, -rel_risk_contr),
                                   cov_matrix_sample_size = 9, cov_estimation_method = "pca2",
                                   opt_objective = "return",
                                   groups_m_d_ref = selected_signal_themes_m_d_ref, active_returns = TRUE,
                                   eligible_returns_m_xts_upd_ref = selected_backtest_returns_corrected_positions_m_xts_upd_ref,
                                   selected_benchmark_m_xts_upd_ref = selected_cov_matrix_benchmark_m_xts_upd_ref,
                                   concentration_constraint_policy = concentration_constraint_policy,
                                   lower_quantile_winsorization = 0.05, upper_quantile_winsorization = 0.95,
                                   selected_benchmark = concentration_constraint_policy$benchmark
  )

  cov_matrix <- PortfolioAnalytics::statistical.factor.model(
    selected_backtest_returns_corrected_positions_m_xts_upd_ref, round(log(5))) %>%
    PortfolioAnalytics::extractCovariance()

  w_active <- most_recent_signal_universe_m_d_ref$weights - most_recent_signal_universe_m_d_ref$theme_sb_bench_weights

  expect_equal(results@port_stats$act_exp_ret,
               as.numeric(w_active %*% most_recent_signal_universe_m_d_ref$exp_ret_score))
  expect_equal(results@port_stats$act_risk,
               as.numeric(t(w_active) %*% cov_matrix %*% w_active)^0.5)
  expect_equal(results@port_stats$info_ratio,
               results@port_stats$act_exp_ret / results@port_stats$act_risk)
  act_rel_risk_contr <- relative_risk_contribution(w_active, cov_matrix)
  expect_equal(results@port_stats$act_hhi_rrc,
               sum(act_rel_risk_contr$rel_risk_contr^2))

  expect_equal(most_recent_signal_universe_m_d_ref %>%
                 dplyr::mutate(
                   act_rel_risk_contr = act_rel_risk_contr$rel_risk_contr,
                   act_weights = w_active,
                 ) %>%
                 dplyr::arrange(id),
               results@universe_m_d_ref@data
               )



})

test_that("set portfolio weights work for MVO (signals) - constrained (individual + group)", {

  #Load
  load(paste(test_path(),"/testdata/","toy_preprocessed_signal_selection_obj.RData", sep =""))
  load(paste(test_path(),"/testdata/","toy_preprocessed_signal_selection_results.RData", sep =""))

  current_date <- "2023-03-15"

  #Select and correct signals
  signal_universe_m_df <- results@signal_universe_m_df@data
  most_recent_signal_universe_m_d_ref <- signal_universe_m_df %>% dplyr::filter(dates == "2023-03-15")
  current_eligible_signals <- most_recent_signal_universe_m_d_ref %>% dplyr::filter(is_eligible == 1) %>% dplyr::pull(tickers)
  signals_positions <- ifelse(stringr::str_detect(current_eligible_signals, "low_"), "short", "long")
  chosen_signals_and_positions <- signals_positions
  names(chosen_signals_and_positions) <- stringr::str_remove(current_eligible_signals, "low_")

  selected_signals_and_backtest_list <- select_and_correct_signals(
    signals_m_df = signals_m_df@data, chosen_signals_and_positions = chosen_signals_and_positions,
    backtest_returns_m_xts = mocked_backtest_returns_m_xts
  )

  selected_signals_corrected_positions_m_df <- selected_signals_and_backtest_list$selected_signals_corrected_positions_m_df
  selected_backtest_returns_corrected_positions_m_xts <- selected_signals_and_backtest_list$selected_backtest_returns_corrected_positions_m_xts
  selected_cov_matrix_benchmark_m_xts <- benchmark_returns_m_xts[, "IBOV"]

  expect_equal(colnames(selected_signals_corrected_positions_m_df)[-c(1:3)], current_eligible_signals)
  expect_equal(selected_signals_corrected_positions_m_df$low_vol_36m, signals_m_df@data$vol_36m*-1)

  selected_backtest_returns_corrected_positions_m_xts_upd_ref <- selected_backtest_returns_corrected_positions_m_xts[c(1:6),]
  selected_cov_matrix_benchmark_m_xts_upd_ref <- selected_cov_matrix_benchmark_m_xts[c(1:6), ]
  signal_themes_m_d_ref <- signal_themes_m_df@data %>% dplyr::filter(dates == "2023-03-15")

  #custom_obj
  custom_objective <- "min_act_dd_dev"


  #Calculate an ewma cov active matrix
  selected_backtest_returns_corrected_positions_m_xts_upd_ref_active <-
    apply(selected_backtest_returns_corrected_positions_m_xts_upd_ref, 2, function(x){
      ((1+x/100)/(1+as.numeric(selected_cov_matrix_benchmark_m_xts_upd_ref)/100) - 1)*100
    })

  pca2_cov <- PortfolioAnalytics::statistical.factor.model(
    selected_backtest_returns_corrected_positions_m_xts_upd_ref_active, round(log(4))) %>% PortfolioAnalytics::extractCovariance()
  colnames(pca2_cov) <- colnames(selected_backtest_returns_corrected_positions_m_xts_upd_ref_active)
  rownames(pca2_cov) <- colnames(selected_backtest_returns_corrected_positions_m_xts_upd_ref_active)

  #exp_ret_score
  exp_ret_score <- most_recent_signal_universe_m_d_ref$act_dd_dev*-1
  exp_ret_score <- exp_ret_score %>% signal_transform(0.05, 0.95)
  most_recent_signal_universe_m_d_ref$exp_ret_score <- exp_ret_score
  exp_ret_score <- exp_ret_score[-2] #eliminate eps_yield (not eligible)

  #Port Spec theme ss
  portfolio_spec <- PortfolioAnalytics::portfolio.spec(assets = current_eligible_signals)
  portfolio_spec <- PortfolioAnalytics::add.constraint(portfolio_spec, type = "full_investment")
  portfolio_spec <- PortfolioAnalytics::add.constraint(portfolio_spec, type = "box",
                                                       min = pmax(most_recent_signal_universe_m_d_ref$theme_ss_bench_weights[-2] - 0.2,
                                                                  0),
                                                       max = most_recent_signal_universe_m_d_ref$theme_ss_bench_weights[-2] + 0.2) #eliminate eps

  portfolio_spec <- PortfolioAnalytics::add.constraint(portfolio_spec, type = "group",
                                                       groups = list(
                                                         theme.defensive = c(2,4),
                                                         theme.momentum = 3,
                                                         theme.value = c(1)
                                                       ),
                                                       group_min = c(0.133, 0.133, 0.133),
                                                       group_max = c(0.533, 0.533, 0.533))

  most_recent_signal_universe_m_d_ref$max_weight <- most_recent_signal_universe_m_d_ref$theme_ss_bench_weights + 0.2
  most_recent_signal_universe_m_d_ref$min_weight <- pmax(most_recent_signal_universe_m_d_ref$theme_ss_bench_weights - 0.2,
                                                         0)
  most_recent_signal_universe_m_d_ref$max_weight[2] <- 0
  most_recent_signal_universe_m_d_ref$min_weight[2] <- 0

  set.seed(123)
  random_weights <- PortfolioAnalytics::random_portfolios(
    portfolio = portfolio_spec,
    permutations = 2000,
    "sample"
  )

  #Expected returns
  returns <- random_weights %>% apply(1, function(row){
    sum(row * exp_ret_score)
  })

  #Expected risk
  risk <- random_weights %>% apply(1, function(row){
    sqrt(t(as.matrix(row)) %*% pca2_cov %*% as.matrix(row))
  })

  #sharpe
  sharpe = returns/risk
  opt_w <- random_weights[which.max(returns),] %>% as.data.frame() %>% tibble::rownames_to_column()
  colnames(opt_w) <- c("tickers", "weights")
  rrc <- relative_risk_contribution(opt_w$weights, pca2_cov)
  most_recent_signal_universe_m_d_ref <- dplyr::left_join(most_recent_signal_universe_m_d_ref, rrc, by = "tickers")
  most_recent_signal_universe_m_d_ref$rel_risk_contr[2] <- 0
  most_recent_signal_universe_m_d_ref <- dplyr::left_join(most_recent_signal_universe_m_d_ref, opt_w, by = "tickers")
  most_recent_signal_universe_m_d_ref$weights[2] <- 0

  #get optimal port
  concentration_constraint_policy <- list(
    benchmark = "theme_ss",
    max_abs_active_individual_weight = 0.2,
    max_abs_active_group_weight = c(theme = 0.2)
  )

  bench_assets_returns_m_xts_upd_ref <- select_and_correct_signals(
    signals_m_df = signals_m_df@data,
    chosen_signals_and_positions = c(book_yield = "long", eps_yield = "long",
                                     roe_3m = "long", sharpe_6m = "long", vol_36m = "short"),
    backtest_returns_m_xts = mocked_backtest_returns_m_xts
  )$selected_backtest_returns_corrected_positions_m_xts[c(1:6),]


  set.seed(123)
  results <- set_portfolio_weights(port_construction_method = "mvo",
                                   universe_m_d_ref = most_recent_signal_universe_m_d_ref %>%
                                     dplyr::select(-max_weight, -min_weight, -weights, -rel_risk_contr),
                                   cov_matrix_sample_size = 6, cov_estimation_method = "pca2",
                                   opt_objective = "return",
                                   groups_m_d_ref = signal_themes_m_d_ref, active_returns = TRUE,
                                   eligible_returns_m_xts_upd_ref =
                                     selected_backtest_returns_corrected_positions_m_xts_upd_ref,
                                   bench_assets_returns_m_xts_upd_ref = bench_assets_returns_m_xts_upd_ref,
                                   selected_benchmark_m_xts_upd_ref = selected_cov_matrix_benchmark_m_xts_upd_ref,
                                   concentration_constraint_policy = concentration_constraint_policy,
                                   lower_quantile_winsorization = 0.05, upper_quantile_winsorization = 0.95,
                                   selected_benchmark = concentration_constraint_policy$benchmark
  )

  #Selected benchmark
  ### Create a custom_weights_m_d_ref
  bench_weights_m_d_ref <- most_recent_signal_universe_m_d_ref %>%
    dplyr::select(id, tickers, dates, theme_ss_bench_weights) %>%
    dplyr::rename(weights = theme_ss_bench_weights)

  ### Create simple bench_universe_m_d_ref
  bench_universe_m_d_ref <- most_recent_signal_universe_m_d_ref %>%
    dplyr::select(-dplyr::any_of(c("min_weight", "max_weight", "weights", "rel_risk_contr"))) %>%
    dplyr::left_join(bench_weights_m_d_ref %>% dplyr::select(id, weights),
                     by = "id") %>%
    dplyr::mutate(is_eligible = ifelse(weights > 0, 1, 0)) %>%
    dplyr::select(-weights)

  selected_benchmark_obj <- set_portfolio_weights(port_construction_method = "custom_weights",
                                                  universe_m_d_ref = bench_universe_m_d_ref,
                                                  custom_weights_m_d_ref = bench_weights_m_d_ref,
                                                  cov_matrix_sample_size = 6, cov_estimation_method = "pca2",
                                                  groups_m_d_ref = signal_themes_m_d_ref, active_returns = FALSE,
                                                  eligible_returns_m_xts_upd_ref =
                                                    bench_assets_returns_m_xts_upd_ref,
                                                  selected_benchmark = NULL,
                                                  level = "benchmark"
                                                  )

  #Macro
  ### Compute macro objects
  macro_objects_list <- compute_agg_macro_objects(
    universe_m_d_ref = most_recent_signal_universe_m_d_ref,
    covariance_matrix = pca2_cov,
    group_col = "theme",
    liquidity_m_d_ref = NULL,
    micro_universe_m_d_ref_list = NULL
  )

  ### Create a custom_weights_m_d_ref
  group_weights_m_d_ref <- macro_objects_list$group_universe_m_d_ref %>%
    dplyr::select(id, tickers, dates, weights)

  ### Create benchmark port object
  macro_port_obj <- set_portfolio_weights(
    universe_m_d_ref = macro_objects_list$group_universe_m_d_ref %>%
      dplyr::select(-weights), #Universe
    port_construction_method = "custom_weights",
    custom_weights_m_d_ref = group_weights_m_d_ref,
    covariance_matrix = macro_objects_list$group_covariance_matrix,
    groups_m_d_ref = NULL,
    selected_benchmark = NULL, #Avoid infinite recursion
    level = "group"
  )

  port_stats <- calculate_port_stats(
    universe_m_d_ref = most_recent_signal_universe_m_d_ref,
    group_universe_m_d_ref = macro_objects_list$group_universe_m_d_ref,
    group_cov_matrix = macro_objects_list$group_covariance_matrix,
    selected_benchmark = "theme_ss",
    bench_universe_m_d_ref = selected_benchmark_obj@universe_m_d_ref@data,
    all_returns_m_xts_upd_ref = bench_assets_returns_m_xts_upd_ref,
    cov_matrix_sample_size = 6,
    cov_estimation_method = "pca2",
    groups_m_d_ref = signal_themes_m_d_ref
  )

  expect_equal(results@port_stats, port_stats$port_stats)


  #Add act_rel_risk_contr and act_weights
  most_recent_signal_universe_m_d_ref_final <- most_recent_signal_universe_m_d_ref %>%
    dplyr::left_join(
      port_stats$assets_stats %>%
        dplyr::rename(
          act_rel_risk_contr = rel_risk_contr,
          act_weights = weights
        ), by = "tickers"
    ) %>%
    dplyr::relocate(act_rel_risk_contr, .after = weights)

  most_recent_signal_universe_m_d_ref_final$act_weights[which(is.na(most_recent_signal_universe_m_d_ref_final$act_weights))] <- 0
  most_recent_signal_universe_m_d_ref_final$act_rel_risk_contr[which(is.na(most_recent_signal_universe_m_d_ref_final$act_rel_risk_contr))] <- 0


  expect_equal(most_recent_signal_universe_m_d_ref_final %>% dplyr::arrange(id), results@universe_m_d_ref@data)

  #Port Spec theme SB
  most_recent_signal_universe_m_d_ref <- most_recent_signal_universe_m_d_ref %>% dplyr::select(-max_weight, -min_weight,
                                                                                               -weights, -rel_risk_contr)

  portfolio_spec <- PortfolioAnalytics::portfolio.spec(assets = current_eligible_signals)
  portfolio_spec <- PortfolioAnalytics::add.constraint(portfolio_spec, type = "full_investment")
  portfolio_spec <- PortfolioAnalytics::add.constraint(portfolio_spec, type = "box",
                                                       min = pmax(most_recent_signal_universe_m_d_ref$theme_sb_bench_weights[-2] - 0.1,
                                                                  0),
                                                       max = most_recent_signal_universe_m_d_ref$theme_sb_bench_weights[-2] + 0.1) #eliminate eps

  portfolio_spec <- PortfolioAnalytics::add.constraint(portfolio_spec, type = "group",
                                                       groups = list(
                                                         theme.defensive = c(2,4),
                                                         theme.momentum = 3,
                                                         theme.value = c(1)
                                                       ),
                                                       group_min = c(0.3, 0, 0.3),
                                                       group_max = c(0.7, 0.2, 0.7))

  most_recent_signal_universe_m_d_ref$max_weight <- most_recent_signal_universe_m_d_ref$theme_sb_bench_weights + 0.1
  most_recent_signal_universe_m_d_ref$min_weight <- pmax(most_recent_signal_universe_m_d_ref$theme_sb_bench_weights - 0.1,
                                                         0)
  most_recent_signal_universe_m_d_ref$max_weight[2] <- 0
  most_recent_signal_universe_m_d_ref$min_weight[2] <- 0

  set.seed(123)
  random_weights <- PortfolioAnalytics::random_portfolios(
    portfolio = portfolio_spec,
    permutations = 2000,
    "sample"
  )

  #Expected returns
  returns <- random_weights %>% apply(1, function(row){
    sum(row * exp_ret_score)
  })

  #Expected risk
  risk <- random_weights %>% apply(1, function(row){
    sqrt(t(as.matrix(row)) %*% pca2_cov %*% as.matrix(row))
  })

  #sharpe
  sharpe = returns/risk
  opt_w <- random_weights[which.min(risk),] %>% as.data.frame() %>% tibble::rownames_to_column()
  colnames(opt_w) <- c("tickers", "weights")
  rrc <- relative_risk_contribution(opt_w$weights, pca2_cov)
  most_recent_signal_universe_m_d_ref <- dplyr::left_join(most_recent_signal_universe_m_d_ref, rrc, by = "tickers")
  most_recent_signal_universe_m_d_ref$rel_risk_contr[2] <- 0

  most_recent_signal_universe_m_d_ref <- dplyr::left_join(most_recent_signal_universe_m_d_ref, opt_w, by = "tickers")
  most_recent_signal_universe_m_d_ref$weights[2] <- 0

  #get optimal port
  concentration_constraint_policy <- list(
    benchmark = "theme_sb",
    max_abs_active_individual_weight = 0.1,
    max_abs_active_group_weight = c(theme = 0.2)
  )

  set.seed(123)
    results <-  set_portfolio_weights(port_construction_method = "mvo",
                                      universe_m_d_ref = most_recent_signal_universe_m_d_ref %>%
                                        dplyr::select(-max_weight, -min_weight, -weights, -rel_risk_contr),
                                      cov_matrix_sample_size = 6, cov_estimation_method = "pca2",
                                      opt_objective = "risk",
                                      groups_m_d_ref = signal_themes_m_d_ref, active_returns = TRUE,
                                      eligible_returns_m_xts_upd_ref = selected_backtest_returns_corrected_positions_m_xts_upd_ref,
                                      bench_assets_returns_m_xts_upd_ref = bench_assets_returns_m_xts_upd_ref,
                                      selected_benchmark_m_xts_upd_ref = selected_cov_matrix_benchmark_m_xts_upd_ref,
                                      concentration_constraint_policy = concentration_constraint_policy,
                                      lower_quantile_winsorization = 0.05, upper_quantile_winsorization = 0.95,
                                      selected_benchmark = concentration_constraint_policy$benchmark
    )



  #Selected benchmark
  ### Create a custom_weights_m_d_ref
  bench_weights_m_d_ref <- most_recent_signal_universe_m_d_ref %>%
    dplyr::select(id, tickers, dates, theme_sb_bench_weights) %>%
    dplyr::rename(weights = theme_sb_bench_weights)

  ### Create simple bench_universe_m_d_ref
  bench_universe_m_d_ref <- most_recent_signal_universe_m_d_ref %>%
    dplyr::select(-dplyr::any_of(c("min_weight", "max_weight", "weights", "rel_risk_contr"))) %>%
    dplyr::left_join(bench_weights_m_d_ref %>% dplyr::select(id, weights),
                     by = "id") %>%
    dplyr::mutate(is_eligible = ifelse(weights > 0, 1, 0)) %>%
    dplyr::select(-weights)


  selected_benchmark_obj <-
    set_portfolio_weights(port_construction_method = "custom_weights",
                          universe_m_d_ref = bench_universe_m_d_ref,
                          custom_weights_m_d_ref = bench_weights_m_d_ref,
                          cov_matrix_sample_size = 6, cov_estimation_method = "pca2",
                          groups_m_d_ref = signal_themes_m_d_ref, active_returns = FALSE,
                          eligible_returns_m_xts_upd_ref =
                            bench_assets_returns_m_xts_upd_ref,
                          selected_benchmark = NULL,
                          level = "benchmark"
    )


  #Macro
  ### Compute macro objects
  macro_objects_list <- compute_agg_macro_objects(
    universe_m_d_ref = most_recent_signal_universe_m_d_ref,
    covariance_matrix = pca2_cov,
    group_col = "theme",
    liquidity_m_d_ref = NULL,
    micro_universe_m_d_ref_list = NULL
  )

  ### Create a custom_weights_m_d_ref
  group_weights_m_d_ref <- macro_objects_list$group_universe_m_d_ref %>%
    dplyr::select(id, tickers, dates, weights)

  ### Create benchmark port object
  macro_port_obj <- set_portfolio_weights(
    universe_m_d_ref = macro_objects_list$group_universe_m_d_ref %>%
      dplyr::select(-weights), #Universe
    port_construction_method = "custom_weights",
    custom_weights_m_d_ref = group_weights_m_d_ref,
    covariance_matrix = macro_objects_list$group_covariance_matrix,
    groups_m_d_ref = NULL,
    selected_benchmark = NULL, #Avoid infinite recursion
    level = "group"
  )

  port_stats <- calculate_port_stats(
    universe_m_d_ref = most_recent_signal_universe_m_d_ref,
    group_universe_m_d_ref = macro_objects_list$group_universe_m_d_ref,
    group_cov_matrix = macro_objects_list$group_covariance_matrix,
    selected_benchmark = "theme_sb",
    bench_universe_m_d_ref = selected_benchmark_obj@universe_m_d_ref@data,
    all_returns_m_xts_upd_ref = bench_assets_returns_m_xts_upd_ref,
    cov_matrix_sample_size = 6,
    cov_estimation_method = "pca2",
    groups_m_d_ref = signal_themes_m_d_ref
  )

  expect_equal(results@port_stats, port_stats$port_stats)


  #Add act_rel_risk_contr and act_weights
  most_recent_signal_universe_m_d_ref_final <- most_recent_signal_universe_m_d_ref %>%
    dplyr::left_join(
      port_stats$assets_stats %>%
        dplyr::rename(
          act_rel_risk_contr = rel_risk_contr,
          act_weights = weights
        ), by = "tickers"
    ) %>%
    dplyr::relocate(act_rel_risk_contr, .after = weights)

  # Replace NAs with 0
  most_recent_signal_universe_m_d_ref_final$act_weights[which(is.na(most_recent_signal_universe_m_d_ref_final$act_weights))] <- 0
  most_recent_signal_universe_m_d_ref_final$act_rel_risk_contr[which(is.na(most_recent_signal_universe_m_d_ref_final$act_rel_risk_contr))] <- 0


  expect_equal(most_recent_signal_universe_m_d_ref_final %>% dplyr::arrange(id), results@universe_m_d_ref@data)


})

test_that("set portfolio weights work for MVO (signals) - constrained (individual + group) + Ridge Penalty", {

  #Load
  load(paste(test_path(),"/testdata/","toy_preprocessed_signal_selection_obj.RData", sep =""))
  load(paste(test_path(),"/testdata/","toy_preprocessed_signal_selection_results.RData", sep =""))

  current_date <- "2023-03-15"

  #Select and correct signals
  signal_universe_m_df <- results@signal_universe_m_df@data
  most_recent_signal_universe_m_d_ref <- signal_universe_m_df %>% dplyr::filter(dates == "2023-03-15")
  current_eligible_signals <- most_recent_signal_universe_m_d_ref %>% dplyr::filter(is_eligible == 1) %>% dplyr::pull(tickers)
  signals_positions <- ifelse(stringr::str_detect(current_eligible_signals, "low_"), "short", "long")
  chosen_signals_and_positions <- signals_positions
  names(chosen_signals_and_positions) <- stringr::str_remove(current_eligible_signals, "low_")

  selected_signals_and_backtest_list <- select_and_correct_signals(
    signals_m_df = signals_m_df@data, chosen_signals_and_positions = chosen_signals_and_positions,
    backtest_returns_m_xts = mocked_backtest_returns_m_xts
  )

  selected_signals_corrected_positions_m_df <- selected_signals_and_backtest_list$selected_signals_corrected_positions_m_df
  selected_backtest_returns_corrected_positions_m_xts <- selected_signals_and_backtest_list$selected_backtest_returns_corrected_positions_m_xts
  selected_cov_matrix_benchmark_m_xts <- benchmark_returns_m_xts[, "IBOV"]

  expect_equal(colnames(selected_signals_corrected_positions_m_df)[-c(1:3)], current_eligible_signals)
  expect_equal(selected_signals_corrected_positions_m_df$low_vol_36m, signals_m_df@data$vol_36m*-1)

  selected_backtest_returns_corrected_positions_m_xts_upd_ref <- selected_backtest_returns_corrected_positions_m_xts[c(1:6),]
  selected_cov_matrix_benchmark_m_xts_upd_ref <- selected_cov_matrix_benchmark_m_xts[c(1:6), ]
  signal_themes_m_d_ref <- signal_themes_m_df@data %>% dplyr::filter(dates == "2023-03-15")

  bench_assets_returns_m_xts_upd_ref <- select_and_correct_signals(
    signals_m_df = signals_m_df@data,
    chosen_signals_and_positions = c(book_yield = "long", eps_yield = "long",
                                     roe_3m = "long", sharpe_6m = "long", vol_36m = "short"),
    backtest_returns_m_xts = mocked_backtest_returns_m_xts
  )$selected_backtest_returns_corrected_positions_m_xts[c(1:6),]


  #custom_obj
  custom_objective <- "min_act_dd_dev"


  #Calculate an ewma cov active matrix
  selected_backtest_returns_corrected_positions_m_xts_upd_ref_active <-
    apply(selected_backtest_returns_corrected_positions_m_xts_upd_ref, 2, function(x){
      ((1+x/100)/(1+as.numeric(selected_cov_matrix_benchmark_m_xts_upd_ref)/100) - 1)*100
    })

  pca2_cov <- PortfolioAnalytics::statistical.factor.model(
    selected_backtest_returns_corrected_positions_m_xts_upd_ref_active, round(log(4))) %>% PortfolioAnalytics::extractCovariance()
  colnames(pca2_cov) <- colnames(selected_backtest_returns_corrected_positions_m_xts_upd_ref_active)
  rownames(pca2_cov) <- colnames(selected_backtest_returns_corrected_positions_m_xts_upd_ref_active)


  #exp_ret_score
  exp_ret_score <- most_recent_signal_universe_m_d_ref$act_dd_dev*-1
  exp_ret_score <- exp_ret_score %>% signal_transform(0.05, 0.95)
  most_recent_signal_universe_m_d_ref$exp_ret_score <- exp_ret_score
  exp_ret_score <- exp_ret_score[-2] #eliminate eps_yield (not eligible)

  #Port Spec theme ss
  portfolio_spec <- PortfolioAnalytics::portfolio.spec(assets = current_eligible_signals)
  portfolio_spec <- PortfolioAnalytics::add.constraint(portfolio_spec, type = "full_investment")
  portfolio_spec <- PortfolioAnalytics::add.constraint(portfolio_spec, type = "box",
                                                       min = pmax(most_recent_signal_universe_m_d_ref$theme_ss_bench_weights[-2] - 0.2,
                                                                  0),
                                                       max = most_recent_signal_universe_m_d_ref$theme_ss_bench_weights[-2] + 0.2) #eliminate eps

  portfolio_spec <- PortfolioAnalytics::add.constraint(portfolio_spec, type = "group",
                                                       groups = list(
                                                         theme.defensive = c(2,4),
                                                         theme.momentum = 3,
                                                         theme.value = c(1)
                                                       ),
                                                       group_min = c(0.133, 0.133, 0.133),
                                                       group_max = c(0.533, 0.533, 0.533))

  most_recent_signal_universe_m_d_ref$max_weight <- most_recent_signal_universe_m_d_ref$theme_ss_bench_weights + 0.2
  most_recent_signal_universe_m_d_ref$min_weight <- pmax(most_recent_signal_universe_m_d_ref$theme_ss_bench_weights - 0.2,
                                                         0)
  most_recent_signal_universe_m_d_ref$max_weight[2] <- 0
  most_recent_signal_universe_m_d_ref$min_weight[2] <- 0

  set.seed(123)
  random_weights <- PortfolioAnalytics::random_portfolios(
    portfolio = portfolio_spec,
    permutations = 2000,
    "sample"
  )

  #Expected returns
  returns <- random_weights %>% apply(1, function(row){
    sum(row * exp_ret_score)
  })

  #Expected risk
  risk <- random_weights %>% apply(1, function(row){
    sqrt(t(as.matrix(row)) %*% pca2_cov %*% as.matrix(row))
  })

  #sharpe
  sharpe = returns/risk

  #Regularize with Ridge
  most_recent_signal_universe_m_d_ref <- most_recent_signal_universe_m_d_ref %>%
    dplyr::mutate(target_weights = theme_sb_bench_weights, .before = theme)

   ##Calculate difference of weights in relation to target
   diffs <- as.data.frame(t(random_weights)) %>%
     dplyr::mutate(tickers = rownames(.), .before = dplyr::everything()) %>%
     dplyr::left_join(most_recent_signal_universe_m_d_ref %>% dplyr::select(tickers, target_weights),
                      by = "tickers")

   ##Calculate squared difference between all cols in diffs and target_weights col
   diffs_vec <- vector(length = ncol(diffs) - 2)
   names(diffs_vec) <- colnames(diffs)[-c(1, ncol(diffs))]
   for(col in colnames(diffs)){

     #Skip if col is either 'tickers' or 'target_weights'
     if(col %in% c("tickers", "target_weights")) next

     diffs_vec[col] <- sum((diffs[[col]] - diffs$target_weights)^2)


   }

   ridge_pen <- 10

   #Choose the portfolio that maximizes sharpe_ratio - ridge_pen*diff
   best_port <- which.max(sharpe - ridge_pen*diffs_vec)
   weights_best_port <- random_weights[best_port, ,drop = FALSE]
   weights_best_port_df <- data.frame(tickers = colnames(weights_best_port),
                                      weights = as.numeric(weights_best_port[1,]))

  ## Add it to signal_universe_m_d_ref
  most_recent_signal_universe_m_d_ref <- most_recent_signal_universe_m_d_ref %>%
    dplyr::left_join(weights_best_port_df, by = "tickers")
  most_recent_signal_universe_m_d_ref$weights[2] <- 0

  ## Calculate rel risk contr
  rrc <- relative_risk_contribution(
    as.numeric(weights_best_port),
    pca2_cov
  )
  most_recent_signal_universe_m_d_ref <- most_recent_signal_universe_m_d_ref %>%
    dplyr::left_join(rrc, by = "tickers")
  most_recent_signal_universe_m_d_ref$rel_risk_contr[2] <- 0

  ## Relocate to before weights
  most_recent_signal_universe_m_d_ref <- most_recent_signal_universe_m_d_ref %>%
    dplyr::relocate(rel_risk_contr, .before = weights)


  #get optimal port
  concentration_constraint_policy <- list(
    benchmark = "theme_ss",
    max_abs_active_individual_weight = 0.2,
    max_abs_active_group_weight = c(theme = 0.2)
  )

  set.seed(123)
  results <- set_portfolio_weights(port_construction_method = "mvo",
                                   universe_m_d_ref = most_recent_signal_universe_m_d_ref %>%
                                     dplyr::select(-max_weight, -min_weight, -weights, -rel_risk_contr) %>%
                                     dplyr::mutate(target_weights = theme_sb_bench_weights,
                                                   .before = theme),
                                   cov_matrix_sample_size = 6, cov_estimation_method = "pca2",
                                   opt_objective = "sharpe",
                                   ridge_pen = ridge_pen,
                                   groups_m_d_ref = signal_themes_m_d_ref, active_returns = TRUE,
                                   eligible_returns_m_xts_upd_ref = selected_backtest_returns_corrected_positions_m_xts_upd_ref,
                                   bench_assets_returns_m_xts_upd_ref = bench_assets_returns_m_xts_upd_ref,
                                   selected_benchmark_m_xts_upd_ref = selected_cov_matrix_benchmark_m_xts_upd_ref,
                                   concentration_constraint_policy = concentration_constraint_policy,
                                   lower_quantile_winsorization = 0.05, upper_quantile_winsorization = 0.95,
                                   selected_benchmark = "theme_ss"
  )

  #Selected benchmark
  ### Create a custom_weights_m_d_ref
  bench_weights_m_d_ref <- most_recent_signal_universe_m_d_ref %>%
    dplyr::select(id, tickers, dates, theme_ss_bench_weights) %>%
    dplyr::rename(weights = theme_ss_bench_weights)

  ### Create simple bench_universe_m_d_ref
  bench_universe_m_d_ref <- most_recent_signal_universe_m_d_ref %>%
    dplyr::select(-dplyr::any_of(c("min_weight", "max_weight", "weights", "rel_risk_contr"))) %>%
    dplyr::left_join(bench_weights_m_d_ref %>% dplyr::select(id, weights),
                     by = "id") %>%
    dplyr::mutate(is_eligible = ifelse(weights > 0, 1, 0)) %>%
    dplyr::select(-weights)

  selected_benchmark_obj <- set_portfolio_weights(port_construction_method = "custom_weights",
                                                  universe_m_d_ref = bench_universe_m_d_ref,
                                                  custom_weights_m_d_ref = bench_weights_m_d_ref,
                                                  cov_matrix_sample_size = 6, cov_estimation_method = "pca2",
                                                  groups_m_d_ref = signal_themes_m_d_ref, active_returns = FALSE,
                                                  eligible_returns_m_xts_upd_ref =
                                                    bench_assets_returns_m_xts_upd_ref,
                                                  selected_benchmark = NULL,
                                                  level = "benchmark"
  )

  #Macro
  ### Compute macro objects
  macro_objects_list <- compute_agg_macro_objects(
    universe_m_d_ref = most_recent_signal_universe_m_d_ref,
    covariance_matrix = pca2_cov,
    group_col = "theme",
    liquidity_m_d_ref = NULL,
    micro_universe_m_d_ref_list = NULL
  )

  ### Create a custom_weights_m_d_ref
  group_weights_m_d_ref <- macro_objects_list$group_universe_m_d_ref %>%
    dplyr::select(id, tickers, dates, weights)

  ### Create benchmark port object
  macro_port_obj <- set_portfolio_weights(
    universe_m_d_ref = macro_objects_list$group_universe_m_d_ref %>%
      dplyr::select(-weights), #Universe
    port_construction_method = "custom_weights",
    custom_weights_m_d_ref = group_weights_m_d_ref,
    covariance_matrix = macro_objects_list$group_covariance_matrix,
    groups_m_d_ref = NULL,
    selected_benchmark = NULL, #Avoid infinite recursion
    level = "group"
  )

  port_stats <- calculate_port_stats(
    universe_m_d_ref = most_recent_signal_universe_m_d_ref,
    group_universe_m_d_ref = macro_objects_list$group_universe_m_d_ref,
    group_cov_matrix = macro_objects_list$group_covariance_matrix,
    selected_benchmark = "theme_ss",
    bench_universe_m_d_ref = selected_benchmark_obj@universe_m_d_ref@data,
    all_returns_m_xts_upd_ref = bench_assets_returns_m_xts_upd_ref,
    cov_matrix_sample_size = 6,
    cov_estimation_method = "pca2",
    groups_m_d_ref = signal_themes_m_d_ref
  )

  expect_equal(results@port_stats, port_stats$port_stats)


  #Add act_rel_risk_contr and act_weights
  most_recent_signal_universe_m_d_ref_final <- most_recent_signal_universe_m_d_ref %>%
    dplyr::left_join(
      port_stats$assets_stats %>%
        dplyr::rename(
          act_rel_risk_contr = rel_risk_contr,
          act_weights = weights
        ), by = "tickers"
    ) %>%
    dplyr::relocate(act_rel_risk_contr, .after = weights)

  most_recent_signal_universe_m_d_ref_final$act_weights[which(is.na(most_recent_signal_universe_m_d_ref_final$act_weights))] <- 0
  most_recent_signal_universe_m_d_ref_final$act_rel_risk_contr[which(is.na(most_recent_signal_universe_m_d_ref_final$act_rel_risk_contr))] <- 0



  expect_equal(most_recent_signal_universe_m_d_ref_final %>% dplyr::arrange(id), results@universe_m_d_ref@data)


  #Test that chosen portfolio is not the one that maximizes sharpe ratio
  expect_false(unname(best_port) == which.max(sharpe))

  #Test that chosen portfolio is closer to the target weights than the one that maximizes sharpe ratio
  expect_true(as.numeric(diffs_vec[best_port]) < as.numeric(diffs_vec[which.max(sharpe)]))

  #Run again with lower ridge pen and test that new port is further from target weights and has higher sharpe
  ridge_pen <- 0.05
  set.seed(123)
  results_2 <- set_portfolio_weights(port_construction_method = "mvo",
                                   universe_m_d_ref = most_recent_signal_universe_m_d_ref %>%
                                     dplyr::select(-max_weight, -min_weight, -weights, -rel_risk_contr) %>%
                                     dplyr::mutate(target_weights = theme_sb_bench_weights,
                                                   .before = theme),
                                   cov_matrix_sample_size = 6, cov_estimation_method = "pca2",
                                   opt_objective = "sharpe",
                                   ridge_pen = ridge_pen,
                                   groups_m_d_ref = signal_themes_m_d_ref, active_returns = TRUE,
                                   eligible_returns_m_xts_upd_ref = selected_backtest_returns_corrected_positions_m_xts_upd_ref,
                                   selected_benchmark_m_xts_upd_ref = selected_cov_matrix_benchmark_m_xts_upd_ref,
                                   concentration_constraint_policy = concentration_constraint_policy,
                                   lower_quantile_winsorization = 0.05, upper_quantile_winsorization = 0.95
  )

  new_weights <- results_2@universe_m_d_ref@data$weights
  old_weights <- results@universe_m_d_ref@data$weights

  new_diffs <- sum((new_weights - most_recent_signal_universe_m_d_ref$theme_sb_bench_weights)^2)
  old_diffs <- sum((old_weights - most_recent_signal_universe_m_d_ref$theme_sb_bench_weights)^2)

  expect_true(new_diffs > old_diffs)

  new_sharpe <- sum(new_weights[-2] * exp_ret_score)/sqrt(t(as.matrix(new_weights[-2])) %*% pca2_cov %*% as.matrix(new_weights[-2]))
  old_sharpe <- sum(old_weights[-2] * exp_ret_score)/sqrt(t(as.matrix(old_weights[-2])) %*% pca2_cov %*% as.matrix(old_weights[-2]))
  expect_true(as.numeric(new_sharpe) > as.numeric(old_sharpe))

})

test_that("set portfolio weights work for MMAF (signals) - top_down - proxy = RP, micro_port = RP + tilts, macro_port = MVO constrained ", {

  #Load
  load(paste(test_path(),"/testdata/","toy_preprocessed_signal_selection_obj.RData", sep =""))
  load(paste(test_path(),"/testdata/","toy_preprocessed_signal_selection_results.RData", sep =""))

  current_date <- "2023-06-15"

  #Select and correct signals
  signal_universe_m_df <- results@signal_universe_m_df@data
  most_recent_signal_universe_m_d_ref <- signal_universe_m_df %>% dplyr::filter(dates == "2023-06-15")
  #Force ineligibility
  most_recent_signal_universe_m_d_ref$is_eligible[1] <- 0
  current_eligible_signals <- most_recent_signal_universe_m_d_ref %>% dplyr::filter(is_eligible == 1) %>% dplyr::pull(tickers)
  signals_positions <- ifelse(stringr::str_detect(current_eligible_signals, "low_"), "short", "long")
  chosen_signals_and_positions <- signals_positions
  names(chosen_signals_and_positions) <- stringr::str_remove(current_eligible_signals, "low_")

  selected_signals_and_backtest_list <- select_and_correct_signals(
    signals_m_df = signals_m_df@data, chosen_signals_and_positions = chosen_signals_and_positions,
    backtest_returns_m_xts = mocked_backtest_returns_m_xts)

  selected_signals_corrected_positions_m_df <- selected_signals_and_backtest_list$selected_signals_corrected_positions_m_df
  selected_backtest_returns_corrected_positions_m_xts <- selected_signals_and_backtest_list$selected_backtest_returns_corrected_positions_m_xts
  selected_cov_matrix_benchmark_m_xts <- benchmark_returns_m_xts[, "IBOV"]

  expect_equal(colnames(selected_signals_corrected_positions_m_df)[-c(1:3)], current_eligible_signals)
  expect_equal(selected_signals_corrected_positions_m_df$low_vol_36m, signals_m_df@data$vol_36m*-1)

  selected_backtest_returns_corrected_positions_m_xts_upd_ref <- selected_backtest_returns_corrected_positions_m_xts[c(1:9),]
  selected_cov_matrix_benchmark_m_xts_upd_ref <- selected_cov_matrix_benchmark_m_xts[c(1:9), ]
  bench_assets_returns_m_xts_upd_ref <- mocked_backtest_returns_m_xts[c(1:9), most_recent_signal_universe_m_d_ref$tickers]


  #ts_splits
  features_m_refit <- signals_m_df@data %>% dplyr::filter(dates <= "2023-03-15") #this is to mimick ts_split behavior with a target_fwd of 3

  #custom_obj
  custom_objective <- "min_act_dd_dev"


  #exp_ret_score
  exp_ret_score <- most_recent_signal_universe_m_d_ref$act_dd_dev*-1
  exp_ret_score <- exp_ret_score %>% signal_transform(0.05, 0.95)
  most_recent_signal_universe_m_d_ref$exp_ret_score <- exp_ret_score

  #Fit fit proxies
  themes <- most_recent_signal_universe_m_d_ref %>% dplyr::pull(theme) %>% unique() %>% sort()
  eligible_universe_m_d_ref <- most_recent_signal_universe_m_d_ref %>% dplyr::filter(is_eligible == 1)
  signal_themes_m_d_ref <- signal_themes_m_df@data %>% dplyr::filter(dates == current_date)

  themes_members <- purrr::map(themes, function(x) {
    signal_themes_m_d_ref %>% dplyr::filter(theme == x) %>% dplyr::pull(tickers)
  })
  names(themes_members) <- themes

  theme_port_list <- process_micro_portfolios(
    parallel = TRUE,
    universe_m_d_ref = most_recent_signal_universe_m_d_ref,
    selected_benchmark = NULL,
    bench_assets_returns_m_xts_upd_ref = NULL,
    eligible_returns_m_xts_upd_ref = selected_backtest_returns_corrected_positions_m_xts_upd_ref,
    selected_benchmark_m_xts_upd_ref = selected_cov_matrix_benchmark_m_xts_upd_ref,
    active_returns = TRUE,
    cov_estimation_method = "ewma",
    groups = themes,
    group_members = themes_members,
    group_weights = NULL,
    groups_m_d_ref = signal_themes_m_d_ref,
    micro_port_construction_method = "rp"
  )

  #Estimate cov matrix
  covariance_matrix <- estimate_covariance_matrix(
    tickers = eligible_universe_m_d_ref$tickers,
    returns_m_xts = selected_backtest_returns_corrected_positions_m_xts_upd_ref,
    cov_estimation_method = "ewma",
    active_returns = TRUE,
    selected_benchmark_m_xts_upd_ref = selected_cov_matrix_benchmark_m_xts_upd_ref,
    cov_matrix_sample_size = nrow(selected_backtest_returns_corrected_positions_m_xts_upd_ref)
  )

  #Generate macro portfolios
  groups_exp_ret_score <- purrr::map_vec(theme_port_list, function(x) {
    sum(dplyr::pull(x@universe_m_d_ref@data %>% dplyr::filter(is_eligible == 1), exp_ret_score) *
          dplyr::pull(x@universe_m_d_ref@data %>% dplyr::filter(is_eligible == 1), weights))
  })

  groups_theme_ss_bench_weights <- most_recent_signal_universe_m_d_ref %>%
    dplyr::group_by(theme) %>%
    dplyr::summarise(theme_ss_bench_weights = sum(theme_ss_bench_weights))

  groups_theme_sb_bench_weights <- most_recent_signal_universe_m_d_ref %>%
    dplyr::group_by(theme) %>%
    dplyr::summarise(theme_sb_bench_weights = sum(theme_sb_bench_weights))

  group_universe_m_d_ref <- data.frame(
    id = paste0(themes, "-", current_date),
    tickers = themes,
    dates = as.Date(current_date),
    exp_ret_score = groups_exp_ret_score,
    is_eligible = 1
  )
  row.names(group_universe_m_d_ref) <- NULL

  g1_w <- theme_port_list[[1]]@universe_m_d_ref@data %>% dplyr::filter(is_eligible == 1) %>% dplyr::pull(weights)
  g1_tickers <- theme_port_list[[1]]@universe_m_d_ref@data %>% dplyr::filter(is_eligible == 1) %>% dplyr::pull(tickers)
  g2_w <- theme_port_list[[2]]@universe_m_d_ref@data %>% dplyr::filter(is_eligible == 1) %>% dplyr::pull(weights)
  g2_tickers <- theme_port_list[[2]]@universe_m_d_ref@data %>% dplyr::filter(is_eligible == 1) %>% dplyr::pull(tickers)
  g3_w <- theme_port_list[[3]]@universe_m_d_ref@data %>% dplyr::filter(is_eligible == 1) %>% dplyr::pull(weights)
  g3_tickers <- theme_port_list[[3]]@universe_m_d_ref@data %>% dplyr::filter(is_eligible == 1) %>% dplyr::pull(tickers)

  ### Calculate each cov matrix element
  groups <- list(
    list(w = g1_w, tickers = g1_tickers),
    list(w = g2_w, tickers = g2_tickers),
    list(w = g3_w, tickers = g3_tickers)
  )
  n_groups <- length(groups)
  group_cov <- matrix(NA, n_groups, n_groups)

  for (i in 1:n_groups) {
    for (j in 1:n_groups) {
      wi <- groups[[i]]$w
      wj <- groups[[j]]$w
      ti <- groups[[i]]$tickers
      tj <- groups[[j]]$tickers

      subcov <- covariance_matrix[ti, tj, drop = FALSE]
      group_cov[i, j] <- as.numeric(t(wi) %*% subcov %*% wj)
    }
  }

  rownames(group_cov) <- colnames(group_cov) <- themes
  ##Arranje according to order in group_universe
  group_cov <- group_cov[match(group_universe_m_d_ref$tickers, rownames(group_cov)),
                         match(group_universe_m_d_ref$tickers, colnames(group_cov))]

  macro_concentration_constraint_policy <- list(
    benchmark = "theme_ss",
    max_abs_active_individual_weight = 0.50
  )

  set.seed(123)
  group_port <- set_portfolio_weights(
    universe_m_d_ref = group_universe_m_d_ref %>%
      dplyr::left_join(groups_theme_ss_bench_weights, by = c("tickers" = "theme")) %>%
      dplyr::left_join(groups_theme_sb_bench_weights, by = c("tickers" = "theme")) %>%
      dplyr::relocate(exp_ret_score, is_eligible, .after = dplyr::last_col()),
    port_construction_method = "mvo",
    concentration_constraint_policy = macro_concentration_constraint_policy,
    opt_objective = "sharpe", n_resamples = 2, n_random_ports = 1000,
    covariance_matrix = group_cov,
    level = "group"
  )

  group_weights <- group_port@universe_m_d_ref@data %>% dplyr::filter(is_eligible == 1) %>% dplyr::pull(weights)
  names(group_weights) <- group_port@universe_m_d_ref@data %>% dplyr::filter(is_eligible == 1) %>% dplyr::pull(tickers)

  #Now let's recalculate micro portfolios given group weights
  # Helper to capture both value and warnings
  capture_warnings_and_value <- function(expr) {
    warnings <- character()
    value <- withCallingHandlers(
      expr,
      warning = function(w) {
        warnings <- c(warnings, conditionMessage(w))
        invokeRestart("muffleWarning")
      }
    )
    list(value = value, warnings = warnings)
  }

  micro_port_list <- capture_warnings_and_value(
    process_micro_portfolios(
      parallel = FALSE,
      universe_m_d_ref = most_recent_signal_universe_m_d_ref,
      selected_benchmark = "theme_ss",
      bench_assets_returns_m_xts_upd_ref = bench_assets_returns_m_xts_upd_ref,
      eligible_returns_m_xts_upd_ref = selected_backtest_returns_corrected_positions_m_xts_upd_ref,
      selected_benchmark_m_xts_upd_ref = selected_cov_matrix_benchmark_m_xts_upd_ref,
      active_returns = TRUE,
      cov_estimation_method = "ewma",
      groups = themes,
      group_members = themes_members,
      group_weights = group_weights,
      micro_port_construction_method = "rp",
      groups_m_d_ref = signal_themes_m_d_ref,
      exp_ret_score_tilt = "inner",
      exp_ret_score_tilt_eta = 0.05
    )
  )

  # Allocate result
  micro_result_list <- micro_port_list$value

  # Define final weights by multiplying weights by group_weight
  final_weights_m_df <- purrr::map2_dfr(micro_result_list, names(micro_result_list), function(port, group_name) {
    port@universe_m_d_ref@data %>%
      dplyr::mutate(weights = weights * group_weights[group_name])
  })

  # Join to eligible universe by id
  universe_m_d_ref_result <- most_recent_signal_universe_m_d_ref %>%
    dplyr::left_join(final_weights_m_df %>% dplyr::select(id, weights), by = "id")
  universe_m_d_ref_result$weights[which(is.na(universe_m_d_ref_result$weights))] <- 0
  rel_risk_contribution <- relative_risk_contribution(
    weights = universe_m_d_ref_result %>% dplyr::filter(is_eligible == 1L) %>% dplyr::pull(weights),
    covariance_matrix = covariance_matrix
  )
  universe_m_d_ref_result <- universe_m_d_ref_result %>%
    dplyr::left_join(rel_risk_contribution, by = "tickers") %>%
    dplyr::relocate(rel_risk_contr, .before = weights)
  universe_m_d_ref_result$rel_risk_contr[which(is.na(universe_m_d_ref_result$rel_risk_contr))] <- 0

  # Compute port stats
    ## For momentum
    momentum_stats <- calculate_port_stats(
      universe_m_d_ref = micro_result_list$momentum@universe_m_d_ref@data %>%
        dplyr::select(-act_rel_risk_contr, -act_weights),
      group_universe_m_d_ref = NULL,
      group_cov_matrix = NULL,
      selected_benchmark = "theme_ss",
      bench_universe_m_d_ref = micro_result_list$momentum@universe_m_d_ref@data %>%
        dplyr::select(-act_rel_risk_contr, -act_weights) %>%
        dplyr::mutate(weights = theme_ss_bench_weights),
      all_returns_m_xts_upd_ref = bench_assets_returns_m_xts_upd_ref,
      cov_matrix_sample_size = 9,
      cov_estimation_method = "ewma",
      groups_m_d_ref = signal_themes_m_d_ref
    )

    ## For value
    value_stats <- calculate_port_stats(
      universe_m_d_ref = micro_result_list$value@universe_m_d_ref@data %>%
        dplyr::select(-act_rel_risk_contr, -act_weights),
      group_universe_m_d_ref = NULL,
      group_cov_matrix = NULL,
      selected_benchmark = "theme_ss",
      bench_universe_m_d_ref = micro_result_list$value@universe_m_d_ref@data %>%
        dplyr::select(-act_rel_risk_contr, -act_weights) %>%
        dplyr::mutate(weights = theme_ss_bench_weights/sum(theme_ss_bench_weights),
                      is_eligible = 1),
      all_returns_m_xts_upd_ref = bench_assets_returns_m_xts_upd_ref,
      cov_matrix_sample_size = 9,
      cov_estimation_method = "ewma",
      groups_m_d_ref = signal_themes_m_d_ref
    )

    ## For port
    universe_m_d_ref_result_stats <- calculate_port_stats(
      universe_m_d_ref = universe_m_d_ref_result,
      group_universe_m_d_ref = group_port@universe_m_d_ref@data,
      group_cov_matrix = group_cov,
      selected_benchmark = "theme_ss",
      bench_universe_m_d_ref = most_recent_signal_universe_m_d_ref %>%
        dplyr::mutate(weights = theme_ss_bench_weights/sum(theme_ss_bench_weights),
                      is_eligible = ifelse(weights > 0, 1, 0)),
      all_returns_m_xts_upd_ref = bench_assets_returns_m_xts_upd_ref,
      cov_matrix_sample_size = 9,
      cov_estimation_method = "ewma",
      groups_m_d_ref = signal_themes_m_d_ref
    )

    ## Join active statistics
    universe_m_d_ref_result <- universe_m_d_ref_result %>%
      dplyr::left_join(
        universe_m_d_ref_result_stats$assets_stats %>%
          dplyr::rename(
            act_rel_risk_contr = rel_risk_contr,
            act_weights = weights
          ), by = "tickers"
      ) %>%
      dplyr::relocate(act_rel_risk_contr, .after = weights)


  #Run and compare results
  set.seed(123)
  suppressWarnings(
  results <-
    set_portfolio_weights(
      universe_m_d_ref = most_recent_signal_universe_m_d_ref,
      port_construction_method = "mmaf",
      top_down_proxy_port_method = "rp",
      mmaf_method = "top_down",
      mmaf_group_col = "theme",
      macro_port_construction_method = "mvo",
      macro_concentration_constraint_policy = macro_concentration_constraint_policy,
      macro_opt_objective = "sharpe",
      macro_n_resamples = 2,
      macro_n_random_ports = 1000,
      micro_port_construction_method = "rp",
      eligible_returns_m_xts_upd_ref = selected_backtest_returns_corrected_positions_m_xts_upd_ref,
      exp_ret_score_tilt = "inner",
      exp_ret_score_tilt_eta = 0.05,
      cov_matrix_sample_size = 9,
      cov_estimation_method = "ewma",
      active_returns = TRUE,
      selected_benchmark_m_xts_upd_ref = selected_cov_matrix_benchmark_m_xts_upd_ref,
      groups_m_d_ref = signal_themes_m_d_ref,
      selected_benchmark = "theme_ss",
      bench_assets_returns_m_xts_upd_ref = bench_assets_returns_m_xts_upd_ref
    )
  )


  #Check that portfolios match
  testthat::expect_equal(
    group_port, results@macro
  )
  testthat::expect_equal(
    group_port@port_stats, results@macro@port_stats
  )
  testthat::expect_equal(
    results@micro$value@port_stats,
    value_stats$port_stats
  )
  testthat::expect_equal(
    results@micro$momentum@port_stats,
    momentum_stats$port_stats
  )
  testthat::expect_equal(
    micro_result_list, results@micro
  )
  # Test port stats of sub ports
  testthat::expect_equal(
    micro_result_list$momentum@port_stats, results@micro$momentum@port_stats
  )
    ## Momentum has only one asset
    testthat::expect_equal(
      results@micro$momentum@port_stats$act_hhi_weights, NA_real_
    )
    testthat::expect_equal(
      results@micro$momentum@port_stats$act_risk, 0
    )

  testthat::expect_equal(
    #Unclear where names in this vector of df come frm, but they are useless
    results@universe_m_d_ref@data %>% dplyr::mutate(weights = unname(weights)),
    universe_m_d_ref_result %>% dplyr::arrange(id)
  )



})

test_that("mmaf works when one of groups has zero weights", {

  #This comes from a run_sb workflow that generated a group with zero weights in one period

  load(paste(test_path(),"/testdata/","toy_preprocessed_signal_selection_obj.RData", sep =""))
  load(paste(test_path(),"/testdata/","toy_preprocessed_port_obj.RData", sep ="")) #Overwrite all but signal_themes

  signals_m_df <- create_meta_dataframe(signals_m_df, "signals_123")
  fwd_return_m_df <- create_meta_dataframe(fwd_return_m_df, type = "target")
  liquidity_m_df <- create_meta_dataframe(liquidity_m_df)
  volatility_m_df <- create_meta_dataframe(volatility_m_df)
  benchmark_weights_m_df <- create_meta_dataframe(benchmark_weights_m_df, type = "weights")
  benchmark_returns_m_xts <- create_meta_xts(benchmark_returns_m_xts)
  port_metrics_m_df <- create_meta_dataframe(signals_m_df@data %>% dplyr::select(id, tickers, dates, roe_3m))

  #Characteristics portfolio
  characteristics_ports <- c(
    book_yield = "long",
    dy_med_36m = "long",
    eps_yield = "long",
    mom_res_12m = "long",
    roe_3m = "long",
    sharpe_6m = "long",
    vol_36m = "short"
  )

  #Create config list
  port_backtest_config_list <- purrr::imap(characteristics_ports, function(pos, metric_name) {
    create_port_backtest_config(
      eligibility_quantile_range = c(0.67, 1),
      selected_benchmark = "ibov",
      initial_buffer_period = 2,
      chosen_score_metric_and_position = stats::setNames(pos, metric_name),
      rebalancing_months = 4,
      port_construction_method = "sw",
      main_liquidity_metric = "mean_volfin_3m",
      config_name = metric_name
    ) %>%
      add_liquidity_floor_cutoffs(
        metric_name = c("mean_volfin_3m", "presence"),
        metric_cutoffs = list(
          c(micro_caps = 1, small_caps = 50000, mid_caps = 100000, large_caps = 200000, mega_caps = 500000),
          c(micro_caps = 97.5, small_caps = 100, mid_caps = 100, large_caps = 100, mega_caps = 100)
        )) %>%
      add_liquidity_constraint_policy(liquidity_floor_rule = "small_caps") %>%
      add_transaction_costs_parameters(direct_transaction_cost = 0.07, alpha = 1, lambda = "dynamic", strategy_aum = 25000)
  })

  #Run!
  future::plan("sequential")
  suppressWarnings(
    port_backtest_cohort <- purrr::map(port_backtest_config_list, function(port_config) {
      run_port_backtest(
        signals_m_df = signals_m_df,
        fwd_return_m_df = fwd_return_m_df,
        liquidity_m_df = liquidity_m_df,
        volatility_m_df = volatility_m_df,
        config = port_config,
        benchmark_weights_m_df = benchmark_weights_m_df,
        benchmark_returns_m_xts = benchmark_returns_m_xts,
        custom_stock_metrics_m_df = port_metrics_m_df,
        verbose = TRUE
      )
    }) %>% create_port_backtest_cohort(cohort_name = "sw_signals")
  )

  #SS Configuration and results
  chosen_signals_and_positions <- c(book_yield = "long", eps_yield = "long", dy_med_36m = "long",
                                    roe_3m = "long", sharpe_6m = "long", vol_36m = "short")

  frequentist_ss_config <- create_ss_backtest_config(initial_sample_size = 3, rebalancing_months = 4,
                                                     split_method = "expanding", config_name = "frequentist_ss", active_returns = TRUE,
                                                     chosen_signals_and_positions = chosen_signals_and_positions) %>%
    add_alpha_test_strategy(model_structure = "no_pooled",
                            signal_significance_threshold = 0.50, p_correction_method = "none",
                            market_factor_proxy = "ibov", enable_theme_representativeness = TRUE)

  signal_themes_m_df <- create_meta_dataframe(signal_themes_m_df %>% dplyr::filter(dates <= "2023-04-15"),
                                              "st_11", type =  "groups")



  ss_results <- suppressWarnings( #This is for NA warning of NAs at the end of run_ss_backtest
    run_ss_backtest(frequentist_ss_config,
                    signals_m_df = signals_m_df, port_backtest_cohort = port_backtest_cohort,
                    benchmark_returns_m_xts = benchmark_returns_m_xts,
                    signal_themes_m_df = signal_themes_m_df,
                    verbose = TRUE
    )
  )

  ##MMAF Config
  mmaf_config <- create_sb_backtest_config(sb_algorithm = "mmaf", rebalancing_months = 4, custom_objective = "max_info_ratio",
                                           training_sample_size = 5, target_fwd_name = "fwd_premium_3m") %>%
    add_cov_est_method(cov_estimation_method = "ewma", cov_matrix_sample_size = 2,
                       active_returns = TRUE, cov_matrix_benchmark = "ibov") %>%
    add_mmaf_parameters(mmaf_group_col = "theme", mmaf_method = "top_down", top_down_proxy_port_method = "hrp",
                        macro_port_construction_method = "rp", micro_port_construction_method = "mvo") %>%
    add_rp_parameters(rp_method = "cyclical-spinu", level = "macro", exp_ret_score_tilt = "inner", exp_ret_score_tilt_eta = 1) %>%
    add_mvo_parameters(opt_objective = "risk", n_random_ports = 1000, ridge_pen = 3, level = "micro") %>%
    add_concentration_constraint_policy(benchmark = "theme_sb",
                                        max_abs_active_group_weight = c(theme = 0.2))

  target_port_m_df <- ss_results@signal_universe_m_df@data %>%
    dplyr::select(id, tickers, dates, theme_sb_bench_weights) %>%
    dplyr::rename(target_weights = theme_sb_bench_weights) %>%
    dplyr::bind_rows(
      data.frame(
        tickers = c("book_yield", "dy_med_36m", "eps_yield",
                    "low_vol_36m", "roe_3m", "sharpe_6m"),
        dates = as.Date("2023-03-15"),
        target_weights = c(0, 0.5, 0, 0.25, 0.25, 0)
      ) %>%
        dplyr::mutate(id = paste0(tickers, "-", dates))
    ) %>%
    dplyr::arrange(id) %>%
    create_meta_dataframe()


  #Subset
  backtest_returns_m_xts <- port_backtest_cohort@port_returns_m_xts_list$net_returns_m_xts
  backtest_returns_m_xts@data <- backtest_returns_m_xts@data[,-8]
  colnames(backtest_returns_m_xts@data) <- c("book_yield","dy_med_36m", "eps_yield", "mom_res_12m", "roe_3m", "sharpe_6m", "low_vol_36m")

  most_recent_signal_universe_m_d_ref <- ss_results@signal_universe_m_df@data %>% dplyr::filter(dates == "2023-04-15")
  target_port_m_d_ref <- target_port_m_df@data %>% dplyr::filter(dates == "2023-04-15")
  selected_backtest_returns_m_xts_upd_ref <- backtest_returns_m_xts@data["2022-12-15/2023-04-15", most_recent_signal_universe_m_d_ref %>% dplyr::filter(is_eligible == 1) %>% dplyr::pull(tickers)]
  selected_cov_matrix_benchmark_m_xts_upd_ref <- benchmark_returns_m_xts@data["2022-12-15/2023-04-15", "ibov"]
  bench_assets_returns_m_xts_upd_ref <- backtest_returns_m_xts@data["2022-12-15/2023-04-15", most_recent_signal_universe_m_d_ref$tickers]

  #Features Objects
  selected_signals_m_df <- signals_m_df@data %>% dplyr::mutate(low_vol_36m = vol_36m*-1) %>% dplyr::select(-vol_36m) %>%
    dplyr::select(id, tickers, dates, most_recent_signal_universe_m_d_ref %>% dplyr::filter(is_eligible == 1) %>% dplyr::pull(tickers))

  selected_features_rebal <- selected_signals_m_df[which(selected_signals_m_df$dates %in% c("2022-10-15", "2022-11-15", "2022-12-15",
                                                                                                   "2023-01-15", "2023-01-15")),]

  #Targets
  targets_rebal_m_df <- target_m_df[which(target_m_df$dates %in% c("2022-10-15", "2022-11-15", "2022-12-15",
                                                                          "2023-01-15", "2023-01-15")),]



  #Fitting
  set.seed(123)
  sb_port <- suppressWarnings(
    fit_sb_model(sb_algorithm = "mmaf", target_fwd_name = "fwd_premium_3m",
                 selected_features_corrected_positions_m_refit = selected_features_first_rebal,
                 most_recent_signal_universe_m_d_ref = most_recent_signal_universe_m_d_ref,
                 selected_backtest_returns_corrected_positions_m_xts_upd_ref = selected_backtest_returns_m_xts_upd_ref,
                 cov_matrix_sample_size = 2, cov_estimation_method = "ewma", active_returns = TRUE,
                 groups_m_d_ref = signal_themes_m_df@data %>% dplyr::filter(dates == as.Date("2023-04-15")),
                 custom_objective_translated = "max_info_ratio", huber_delta = 1, quantile_tau = 0.5, early_stop = NULL,
                 keras_architecture_parameters = NULL, optimal_hyper = NULL, chosen_eval_metric_translated = NULL,
                 selected_cov_matrix_benchmark_m_xts_upd_ref = selected_cov_matrix_benchmark_m_xts_upd_ref,
                 macro_exp_ret_score_tilt = "inner", macro_exp_ret_score_tilt_eta = 10,
                 n_random_ports = 1000, opt_objective = "risk", ridge_pen = 3,
                 target_port_m_d_ref = target_port_m_d_ref, mmaf_method = "top_down",
                 mmaf_group_col = "theme", top_down_proxy_port_method = "hrp",
                 micro_port_construction_method = "mvo", macro_port_construction_method = "rp",
                 macro_concentration_constraint_policy = list(benchmark = "theme_sb",
                                                              max_abs_active_individual_weight = 0.2),
                 selected_benchmark = "theme_sb",
                 bench_assets_backtest_returns_corrected_positions_m_xts_upd_ref = bench_assets_returns_m_xts_upd_ref
    ))

  #Test for presence of group with zero weight
  expect_gt(
    sb_port@model@macro@universe_m_d_ref@data %>%
      dplyr::filter(weights == 0) %>%
      nrow(),
    0)


  #Test for tickers belonging to that group having zero final weight
  zero_weight_groups <- sb_port@model@macro@universe_m_d_ref@data %>%
    dplyr::filter(weights == 0) %>%
    dplyr::pull(tickers)
  expect_equal(
    sb_port@model@universe_m_d_ref@data %>%
      dplyr::filter(theme %in% zero_weight_groups) %>%
      dplyr::pull(weights) %>%
      unique(),
    0
  )

  #Test for port stats
  expect_equal(
    sb_port@model@port_stats,
    calculate_port_stats(
      universe_m_d_ref = sb_port@model@universe_m_d_ref@data %>% dplyr::select(-act_weights, -act_rel_risk_contr),
      group_universe_m_d_ref = sb_port@model@macro@universe_m_d_ref@data,
      group_cov_matrix = sb_port@model@group_cov_matrix,
      selected_benchmark = "theme_sb",
      bench_universe_m_d_ref = sb_port@model@universe_m_d_ref@data %>%
        dplyr::mutate(weights = theme_sb_bench_weights/sum(theme_sb_bench_weights),
                      is_eligible = ifelse(weights > 0, 1, 0)),
      all_returns_m_xts_upd_ref = bench_assets_returns_m_xts_upd_ref,
      cov_matrix_sample_size = 2,
      cov_estimation_method = "ewma",
      groups_m_d_ref = signal_themes_m_df@data %>% dplyr::filter(dates == as.Date("2023-04-15"))
    )$port_stats
  )


})

#Stocks (in artificial_port_obj, all tickers are eligible, differently from toy_preprocessed)
test_that("set portfolio weights works for stocks (ew) - artificial_port_obj ", {

  #Create signals_m_d_ref
  load(paste(test_path(),"/testdata/","artificial_port_obj.RData", sep =""))

  #Quantile Range
  eligibility_quantile_range <- c(0.67, 1)

  #Current date
  current_date <- "2001-06-15"

  #Initial Preps
  signals_m_d_ref <- signals_m_df %>% dplyr::filter(dates == current_date)
  liquidity_m_d_ref <- liquidity_m_df %>% dplyr::filter(dates == current_date)
  benchmark_weights_m_d_ref <- benchmark_weights_m_df %>% dplyr::filter(dates == current_date)
  stock_groups_m_d_ref <- stock_groups_m_df %>% dplyr::filter(dates == current_date)
  updated_port_weights_m_lstd_ref <- signals_m_df[which(signals_m_df$dates == "2001-05-15"), c(1:3)]
  updated_port_weights_m_lstd_ref$bop_port_weights <- c(0.20, 0.20, 0.20, 0.20, 0.20)

  #Derive Stock Universe
  stock_universe_m_d_ref <- derive_stock_universe_m_d_ref(signals_m_d_ref = signals_m_d_ref, chosen_score_metric_and_position = c(Gamma = "long"),
                                                          upper_quantile_winsorization = upper_quantile_winsorization,
                                                          lower_quantile_winsorization = lower_quantile_winsorization)

  #Classify stock universe
  stock_universe_m_d_ref <- classify_investment_universe(
    universe_m_d_ref = stock_universe_m_d_ref,
    eligibility_quantile_range = eligibility_quantile_range,
    liquidity_m_d_ref = liquidity_m_d_ref,
    liquidity_constraint_policy = liquidity_constraint_policy,
    liquidity_floor_cutoffs = liquidity_floor_cutoffs_df,
    benchmark_weights_m_d_ref = benchmark_weights_m_d_ref,
    groups_m_d_ref = stock_groups_m_d_ref,
    concentration_constraint_policy = concentration_constraint_policy,
    updated_port_weights_m_lstd_ref = updated_port_weights_m_lstd_ref,
    turnover_constraint_policy = turnover_constraint_policy
  )

  #Test EW
  expected_results <- stock_universe_m_d_ref
  expected_results$weights <- rep(0.25, 4)
  results <- set_portfolio_weights(universe_m_d_ref = stock_universe_m_d_ref, port_construction_method = "ew")

  expect_equal(results@universe_m_d_ref@data, expected_results)

  expect_equal(results@port_stats$hhi_weights, 0.25)


})

test_that("set portfolio weights works for stocks (cw) - artificial_port_obj ", {

  #Create signals_m_d_ref
  load(paste(test_path(),"/testdata/","artificial_port_obj.RData", sep =""))

  #Quantile Range
  eligibility_quantile_range <- c(0.67, 1)

  #Current date
  current_date <- "2001-06-15"

  #Initial Preps
  signals_m_d_ref <- signals_m_df %>% dplyr::filter(dates == current_date)
  liquidity_m_d_ref <- liquidity_m_df %>% dplyr::filter(dates == current_date)
  benchmark_weights_m_d_ref <- benchmark_weights_m_df %>% dplyr::filter(dates == current_date)
  stock_groups_m_d_ref <- stock_groups_m_df %>% dplyr::filter(dates == current_date)
  updated_port_weights_m_lstd_ref <- signals_m_df[which(signals_m_df$dates == "2001-05-15"), c(1:3)]
  updated_port_weights_m_lstd_ref$bop_port_weights <- c(0.20, 0.20, 0.20, 0.20, 0.20)

  #Derive Stock Universe
  stock_universe_m_d_ref <- derive_stock_universe_m_d_ref(signals_m_d_ref = signals_m_d_ref, chosen_score_metric_and_position = c(Gamma = "long"),
                                                          upper_quantile_winsorization = upper_quantile_winsorization,
                                                          lower_quantile_winsorization = lower_quantile_winsorization)

  #Classify stock universe
  stock_universe_m_d_ref <- classify_investment_universe(
    universe_m_d_ref = stock_universe_m_d_ref,
    eligibility_quantile_range = eligibility_quantile_range,
    liquidity_m_d_ref = liquidity_m_d_ref,
    liquidity_constraint_policy = liquidity_constraint_policy,
    liquidity_floor_cutoffs = liquidity_floor_cutoffs_df,
    benchmark_weights_m_d_ref = benchmark_weights_m_d_ref,
    groups_m_d_ref = stock_groups_m_d_ref,
    concentration_constraint_policy = concentration_constraint_policy,
    updated_port_weights_m_lstd_ref = updated_port_weights_m_lstd_ref,
    turnover_constraint_policy = turnover_constraint_policy
  )

  #Test CW
  expected_results <- stock_universe_m_d_ref
  expected_results$cap_score <- signal_transform(expected_results$mean_volfin_3m, lower_quantile_winsorization, upper_quantile_winsorization)
  expected_results$weights <- expected_results$cap_score/sum(expected_results$cap_score)

  results <- set_portfolio_weights(universe_m_d_ref = stock_universe_m_d_ref, port_construction_method = "cw",
                                   liquidity_m_d_ref = liquidity_m_d_ref, cap_weighting_metric = "mean_volfin_3m")

  expect_equal(results@universe_m_d_ref@data, expected_results)
  expect_equal(results@universe_m_d_ref@data$weights %>% sum(), 1)

})

test_that("set portfolio weights works for stocks (sw) - artificial_port_obj ", {

  #Create signals_m_d_ref
  load(paste(test_path(),"/testdata/","artificial_port_obj.RData", sep =""))

  #Quantile Range
  eligibility_quantile_range <- c(0.67, 1)

  #Current date
  current_date <- "2001-06-15"

  #Initial Preps
  signals_m_d_ref <- signals_m_df %>% dplyr::filter(dates == current_date)
  liquidity_m_d_ref <- liquidity_m_df %>% dplyr::filter(dates == current_date)
  benchmark_weights_m_d_ref <- benchmark_weights_m_df %>% dplyr::filter(dates == current_date)
  stock_groups_m_d_ref <- stock_groups_m_df %>% dplyr::filter(dates == current_date)
  updated_port_weights_m_lstd_ref <- signals_m_df[which(signals_m_df$dates == "2001-05-15"), c(1:3)]
  updated_port_weights_m_lstd_ref$bop_port_weights <- c(0.20, 0.20, 0.20, 0.20, 0.20)

  #Derive Stock Universe
  stock_universe_m_d_ref <- derive_stock_universe_m_d_ref(signals_m_d_ref = signals_m_d_ref, chosen_score_metric_and_position = c(Gamma = "long"),
                                                          upper_quantile_winsorization = upper_quantile_winsorization,
                                                          lower_quantile_winsorization = lower_quantile_winsorization)

  #Classify stock universe
  stock_universe_m_d_ref <- classify_investment_universe(
    universe_m_d_ref = stock_universe_m_d_ref,
    eligibility_quantile_range = eligibility_quantile_range,
    liquidity_m_d_ref = liquidity_m_d_ref,
    liquidity_constraint_policy = liquidity_constraint_policy,
    liquidity_floor_cutoffs = liquidity_floor_cutoffs_df,
    benchmark_weights_m_d_ref = benchmark_weights_m_d_ref,
    groups_m_d_ref = stock_groups_m_d_ref,
    concentration_constraint_policy = concentration_constraint_policy,
    updated_port_weights_m_lstd_ref = updated_port_weights_m_lstd_ref,
    turnover_constraint_policy = turnover_constraint_policy
  )

  #Test CS
  expected_results <- stock_universe_m_d_ref
  expected_results$cap_score <- signal_transform(expected_results$mean_volfin_3m, lower_quantile_winsorization, upper_quantile_winsorization)
  expected_results$weights <- (expected_results$cap_score * expected_results$exp_ret_score)/sum((expected_results$cap_score * expected_results$exp_ret_score))

  results <- set_portfolio_weights(universe_m_d_ref = stock_universe_m_d_ref, port_construction_method = "cs",
                                   liquidity_m_d_ref = liquidity_m_d_ref, cap_weighting_metric = "mean_volfin_3m")

  expect_equal(results@universe_m_d_ref@data, expected_results)
  expect_equal(results@universe_m_d_ref@data$weights %>% sum(), 1)

})

test_that("set portfolio weights works for stocks (cs) - artificial_port_obj ", {

  #Create signals_m_d_ref
  load(paste(test_path(),"/testdata/","artificial_port_obj.RData", sep =""))

  #Quantile Range
  eligibility_quantile_range <- c(0.67, 1)

  #Current date
  current_date <- "2001-06-15"

  #Initial Preps
  signals_m_d_ref <- signals_m_df %>% dplyr::filter(dates == current_date)
  liquidity_m_d_ref <- liquidity_m_df %>% dplyr::filter(dates == current_date)
  benchmark_weights_m_d_ref <- benchmark_weights_m_df %>% dplyr::filter(dates == current_date)
  stock_groups_m_d_ref <- stock_groups_m_df %>% dplyr::filter(dates == current_date)
  updated_port_weights_m_lstd_ref <- signals_m_df[which(signals_m_df$dates == "2001-05-15"), c(1:3)]
  updated_port_weights_m_lstd_ref$bop_port_weights <- c(0.20, 0.20, 0.20, 0.20, 0.20)

  #Derive Stock Universe
  stock_universe_m_d_ref <- derive_stock_universe_m_d_ref(signals_m_d_ref = signals_m_d_ref, chosen_score_metric_and_position = c(Gamma = "long"),
                                                          upper_quantile_winsorization = upper_quantile_winsorization,
                                                          lower_quantile_winsorization = lower_quantile_winsorization)

  #Classify stock universe
  stock_universe_m_d_ref <- classify_investment_universe(
    universe_m_d_ref = stock_universe_m_d_ref,
    eligibility_quantile_range = eligibility_quantile_range,
    liquidity_m_d_ref = liquidity_m_d_ref,
    liquidity_constraint_policy = liquidity_constraint_policy,
    liquidity_floor_cutoffs = liquidity_floor_cutoffs_df,
    benchmark_weights_m_d_ref = benchmark_weights_m_d_ref,
    groups_m_d_ref = stock_groups_m_d_ref,
    concentration_constraint_policy = concentration_constraint_policy,
    updated_port_weights_m_lstd_ref = updated_port_weights_m_lstd_ref,
    turnover_constraint_policy = turnover_constraint_policy
  )

  #Test SW
  expected_results <- stock_universe_m_d_ref
  expected_results$weights[expected_results$is_eligible == 1] <- (expected_results$exp_ret_score[expected_results$is_eligible == 1])/
    sum(expected_results$exp_ret_score[expected_results$is_eligible == 1])
  expected_results$weights[which(is.na(expected_results$weights))] <- 0

  results <- set_portfolio_weights(universe_m_d_ref = stock_universe_m_d_ref, port_construction_method = "sw",
                                   liquidity_m_d_ref = liquidity_m_d_ref)

  expect_equal(results@universe_m_d_ref@data, expected_results)
  expect_equal(results@universe_m_d_ref@data %>% dplyr::filter(is_eligible == 1) %>% dplyr::slice_max(weights, n = 50) %>% dplyr::pull(tickers),
               results@universe_m_d_ref@data %>% dplyr::filter(is_eligible == 1) %>% dplyr::slice_max(exp_ret_score, n = 50) %>% dplyr::pull(tickers))
  expect_equal(results@universe_m_d_ref@data$weights %>% sum(), 1)

})

test_that("set portfolio weights works for stocks (rp) - artificial_port_obj ", {

  #Create signals_m_d_ref
  load(paste(test_path(),"/testdata/","artificial_port_obj.RData", sep =""))

  #Quantile Range
  eligibility_quantile_range <- c(0.67, 1)

  #Current date
  current_date <- "2001-06-15"

  #Initial Preps
  signals_m_d_ref <- signals_m_df %>% dplyr::filter(dates == current_date)
  liquidity_m_d_ref <- liquidity_m_df %>% dplyr::filter(dates == current_date)
  benchmark_weights_m_d_ref <- benchmark_weights_m_df %>% dplyr::filter(dates == current_date)
  stock_groups_m_d_ref <- stock_groups_m_df %>% dplyr::filter(dates == current_date)
  updated_port_weights_m_lstd_ref <- signals_m_df[which(signals_m_df$dates == "2001-05-15"), c(1:3)]
  updated_port_weights_m_lstd_ref$bop_port_weights <- c(0.20, 0.20, 0.20, 0.20, 0.20)

  #Derive Stock Universe
  stock_universe_m_d_ref <- derive_stock_universe_m_d_ref(signals_m_d_ref = signals_m_d_ref, chosen_score_metric_and_position = c(Gamma = "long"),
                                                          upper_quantile_winsorization = upper_quantile_winsorization,
                                                          lower_quantile_winsorization = lower_quantile_winsorization)

  #Classify stock universe
  stock_universe_m_d_ref <- classify_investment_universe(
    universe_m_d_ref = stock_universe_m_d_ref,
    eligibility_quantile_range = eligibility_quantile_range,
    liquidity_m_d_ref = liquidity_m_d_ref,
    liquidity_constraint_policy = liquidity_constraint_policy,
    liquidity_floor_cutoffs = liquidity_floor_cutoffs_df,
    benchmark_weights_m_d_ref = benchmark_weights_m_d_ref,
    groups_m_d_ref = stock_groups_m_d_ref,
    concentration_constraint_policy = concentration_constraint_policy,
    updated_port_weights_m_lstd_ref = updated_port_weights_m_lstd_ref,
    turnover_constraint_policy = turnover_constraint_policy
  )

  #Test RP
  expected_results <- stock_universe_m_d_ref

  daily_stock_returns_m_xts_upd_ref <- daily_stock_returns_m_xts[which(zoo::index(daily_stock_returns_m_xts) <= current_date),]

  covariance_matrix <- estimate_covariance_matrix(tickers = c("Stock A", "Stock C", "Stock D", "Stock E"), returns_m_xts_upd_ref = daily_stock_returns_m_xts_upd_ref,
                                                  cov_matrix_sample_size = 252, cov_estimation_method = covariance_estimation_method,
                                                  active_returns = FALSE,
                                                  groups_m_d_ref = stock_groups_m_d_ref
  )

  rp_results <- riskParityPortfolio::riskParityPortfolio(Sigma = covariance_matrix)
  expected_results$rel_risk_contr <- rp_results$relative_risk_contribution
  expected_results$weights <- rp_results$w

  results <- set_portfolio_weights(universe_m_d_ref = stock_universe_m_d_ref, port_construction_method = "rp",
                                   eligible_returns_m_xts_upd_ref = daily_stock_returns_m_xts_upd_ref, groups_m_d_ref = stock_groups_m_d_ref,
                                   cov_matrix_sample_size = 252, cov_estimation_method = covariance_estimation_method
  )


  expect_equal(results@universe_m_d_ref@data, expected_results)
  expect_equal(results@universe_m_d_ref@data$weights %>% sum(), 1)
  expect_equal(results@port_stats$hhi_rrc, 0.25)


})

test_that("set_portfolio weights works for stocks (rp + exp_ret_score_tilt = 'inner')", {

  #Create signals_m_d_ref
  load(paste(test_path(),"/testdata/","artificial_port_obj.RData", sep =""))

  #Quantile Range
  eligibility_quantile_range <- c(0.67, 1)

  #Current date
  current_date <- "2001-06-15"

  #Initial Preps
  signals_m_d_ref <- signals_m_df %>% dplyr::filter(dates == current_date)
  liquidity_m_d_ref <- liquidity_m_df %>% dplyr::filter(dates == current_date)
  benchmark_weights_m_d_ref <- benchmark_weights_m_df %>% dplyr::filter(dates == current_date)
  stock_groups_m_d_ref <- stock_groups_m_df %>% dplyr::filter(dates == current_date)
  updated_port_weights_m_lstd_ref <- signals_m_df[which(signals_m_df$dates == "2001-05-15"), c(1:3)]
  updated_port_weights_m_lstd_ref$bop_port_weights <- c(0.20, 0.20, 0.20, 0.20, 0.20)
  exp_ret_score_tilt_eta <- 0.5

  #Derive Stock Universe
  stock_universe_m_d_ref <- derive_stock_universe_m_d_ref(signals_m_d_ref = signals_m_d_ref, chosen_score_metric_and_position = c(Gamma = "long"),
                                                          upper_quantile_winsorization = upper_quantile_winsorization,
                                                          lower_quantile_winsorization = lower_quantile_winsorization)

  #Classify stock universe
  stock_universe_m_d_ref <- classify_investment_universe(
    universe_m_d_ref = stock_universe_m_d_ref,
    eligibility_quantile_range = eligibility_quantile_range,
    liquidity_m_d_ref = liquidity_m_d_ref,
    liquidity_constraint_policy = liquidity_constraint_policy,
    liquidity_floor_cutoffs = liquidity_floor_cutoffs_df,
    benchmark_weights_m_d_ref = benchmark_weights_m_d_ref,
    groups_m_d_ref = stock_groups_m_d_ref,
    concentration_constraint_policy = concentration_constraint_policy,
    updated_port_weights_m_lstd_ref = updated_port_weights_m_lstd_ref,
    turnover_constraint_policy = turnover_constraint_policy
  )

  #Test RP
  expected_results <- stock_universe_m_d_ref

  daily_stock_returns_m_xts_upd_ref <- daily_stock_returns_m_xts[which(zoo::index(daily_stock_returns_m_xts) <= current_date),]

  covariance_matrix <- estimate_covariance_matrix(tickers = c("Stock A", "Stock C", "Stock D", "Stock E"), returns_m_xts_upd_ref = daily_stock_returns_m_xts_upd_ref,
                                                  cov_matrix_sample_size = 252, cov_estimation_method = covariance_estimation_method,
                                                  active_returns = FALSE,
                                                  groups_m_d_ref = stock_groups_m_d_ref
  )

  rp_results <- riskParityPortfolio::riskParityPortfolio(Sigma = covariance_matrix,
                                                         mu = expected_results$exp_ret_score,
                                                         lmd_mu = exp_ret_score_tilt_eta)
  expected_results$rel_risk_contr <- rp_results$relative_risk_contribution
  expected_results$weights <- rp_results$w

  results <- set_portfolio_weights(universe_m_d_ref = stock_universe_m_d_ref, port_construction_method = "rp",
                                   eligible_returns_m_xts_upd_ref = daily_stock_returns_m_xts_upd_ref, groups_m_d_ref = stock_groups_m_d_ref,
                                   cov_matrix_sample_size = 252, cov_estimation_method = covariance_estimation_method,
                                   exp_ret_score_tilt_eta = exp_ret_score_tilt_eta,
                                   exp_ret_score_tilt = "inner"
  )


  expect_equal(results@universe_m_d_ref@data, expected_results)
  expect_equal(results@universe_m_d_ref@data$weights %>% sum(), 1)

  # Test that relative risk contribution is biased towards the stock with highest expected return
  stock_with_highest_exp_ret <- expected_results %>% dplyr::filter(exp_ret_score == max(exp_ret_score)) %>% dplyr::pull(tickers)
  stock_with_highest_rrc <- results@universe_m_d_ref@data %>% dplyr::filter(rel_risk_contr == max(rel_risk_contr)) %>% dplyr::pull(tickers)
  expect_equal(stock_with_highest_exp_ret, stock_with_highest_rrc)



})

test_that("set portfolio weights work for stocks (rp constrained + exp_ret_score_tilt = 'inner')", {

  #Create signals_m_d_ref
  load(paste(test_path(),"/testdata/","artificial_port_obj.RData", sep =""))

  #Quantile Range
  eligibility_quantile_range <- c(0.67, 1)

  #Current date
  current_date <- "2001-06-15"

  #Initial Preps
  signals_m_d_ref <- signals_m_df %>% dplyr::filter(dates == current_date)
  liquidity_m_d_ref <- liquidity_m_df %>% dplyr::filter(dates == current_date)
  benchmark_weights_m_d_ref <- benchmark_weights_m_df %>% dplyr::filter(dates == current_date)
  stock_groups_m_d_ref <- stock_groups_m_df %>% dplyr::filter(dates == current_date)
  updated_port_weights_m_lstd_ref <- signals_m_df[which(signals_m_df$dates == "2001-05-15"), c(1:3)]
  updated_port_weights_m_lstd_ref$bop_port_weights <- c(0.20, 0.20, 0.20, 0.20, 0.20)
  exp_ret_score_tilt_eta <- 0.5

  #Derive Stock Universe
  stock_universe_m_d_ref <- derive_stock_universe_m_d_ref(signals_m_d_ref = signals_m_d_ref, chosen_score_metric_and_position = c(Gamma = "long"),
                                                          upper_quantile_winsorization = upper_quantile_winsorization,
                                                          lower_quantile_winsorization = lower_quantile_winsorization)

  #Classify stock universe
  stock_universe_m_d_ref <- classify_investment_universe(
    universe_m_d_ref = stock_universe_m_d_ref,
    eligibility_quantile_range = eligibility_quantile_range,
    liquidity_m_d_ref = liquidity_m_d_ref,
    liquidity_constraint_policy = liquidity_constraint_policy,
    liquidity_floor_cutoffs = liquidity_floor_cutoffs_df,
    benchmark_weights_m_d_ref = benchmark_weights_m_d_ref,
    groups_m_d_ref = stock_groups_m_d_ref,
    concentration_constraint_policy = concentration_constraint_policy,
    updated_port_weights_m_lstd_ref = updated_port_weights_m_lstd_ref,
    turnover_constraint_policy = turnover_constraint_policy
  )

  #Test RP
  expected_results <- stock_universe_m_d_ref

  daily_stock_returns_m_xts_upd_ref <- daily_stock_returns_m_xts[which(zoo::index(daily_stock_returns_m_xts) <= current_date),]

  covariance_matrix <- estimate_covariance_matrix(tickers = c("Stock A", "Stock C", "Stock D", "Stock E"), returns_m_xts_upd_ref = daily_stock_returns_m_xts_upd_ref,
                                                  cov_matrix_sample_size = 252, cov_estimation_method = covariance_estimation_method,
                                                  active_returns = FALSE,
                                                  groups_m_d_ref = stock_groups_m_d_ref
  )

  # Generate box constraints
  eligible_stock_universe_m_d_ref <- generate_box_constraints(universe_m_d_ref = stock_universe_m_d_ref,
                                              liquidity_constraint_policy = liquidity_constraint_policy,
                                              turnover_constraint_policy = turnover_constraint_policy,
                                              concentration_constraint_policy = concentration_constraint_policy)

  selected_daily_stock_returns_m_xts_upd_ref <-
    daily_stock_returns_m_xts[which(zoo::index(daily_stock_returns_m_xts) <= current_date), eligible_stock_universe_m_d_ref$tickers]


  #Run RP with constraints
  rp_results <- riskParityPortfolio::riskParityPortfolio(
    Sigma = covariance_matrix,
    mu = expected_results$exp_ret_score,
    lmd_mu = exp_ret_score_tilt_eta,
    w_lb = eligible_stock_universe_m_d_ref$min_weight,
    w_ub = eligible_stock_universe_m_d_ref$max_weight
  )

  #join rp weights to expected_results
  expected_results <- expected_results %>%
    dplyr::left_join(eligible_stock_universe_m_d_ref %>% dplyr::select(id, max_weight, min_weight), by = "id") %>%
    dplyr::left_join(data.frame(tickers = names(rp_results$w), weights = rp_results$w), by = "tickers")

  #Add RRC
  rrc <- relative_risk_contribution(weights = expected_results$weights[which(expected_results$is_eligible == 1)],
                                           covariance_matrix = covariance_matrix)
  expected_results <- expected_results %>% dplyr::left_join(rrc, by = "tickers") %>%
    dplyr::relocate(rel_risk_contr, .before = weights)

  #Do active calculation for groups and benchmark
  macro_objs <- compute_agg_macro_objects(
    universe_m_d_ref = expected_results,
    covariance_matrix = covariance_matrix,
    group_col = "Sector",
    liquidity_m_d_ref = liquidity_m_d_ref,
    micro_universe_m_d_ref_list = NULL
  )

  port_stats <- calculate_port_stats(
    universe_m_d_ref = expected_results,
    group_universe_m_d_ref = macro_objs$group_universe_m_d_ref,
    group_cov_matrix = macro_objs$group_covariance_matrix,
    selected_benchmark = "ibov",
    bench_universe_m_d_ref = benchmark_weights_m_d_ref %>%
      dplyr::mutate(weights = ibov,
                    is_eligible = ifelse(weights > 0, 1, 0)),
    all_returns_m_xts_upd_ref = daily_stock_returns_m_xts_upd_ref,
    cov_matrix_sample_size = 252,
    cov_estimation_method = covariance_estimation_method,
    groups_m_d_ref = stock_groups_m_d_ref
  )

  ## Add actives
  expected_results <- expected_results %>%
    dplyr::left_join(port_stats$assets_stats %>%
                       dplyr::rename(
                         act_weights = weights,
                         act_rel_risk_contr = rel_risk_contr
                       ), by = "tickers"
                     ) %>%
    dplyr::relocate(act_rel_risk_contr, .before = act_weights)


  # Run function
  results <- set_portfolio_weights(universe_m_d_ref = stock_universe_m_d_ref, port_construction_method = "rp",
                                   eligible_returns_m_xts_upd_ref = daily_stock_returns_m_xts_upd_ref,
                                   groups_m_d_ref = stock_groups_m_d_ref,
                                   cov_matrix_sample_size = 252, cov_estimation_method = covariance_estimation_method,
                                   exp_ret_score_tilt_eta = exp_ret_score_tilt_eta,
                                   exp_ret_score_tilt = "inner",
                                   liquidity_m_d_ref = liquidity_m_d_ref,
                                   liquidity_constraint_policy = liquidity_constraint_policy,
                                   turnover_constraint_policy = turnover_constraint_policy,
                                   concentration_constraint_policy = concentration_constraint_policy,
                                   selected_benchmark = "ibov", bench_assets_returns_m_xts_upd_ref = daily_stock_returns_m_xts_upd_ref
  )


  expect_equal(results@universe_m_d_ref@data, expected_results)


  # Check that constraints were followed
  expect_true(all(results@universe_m_d_ref@data$weights <= results@universe_m_d_ref@data$max_weight))
  expect_true(all(results@universe_m_d_ref@data$weights >= results@universe_m_d_ref@data$min_weight))

  # micro_caps < 0.01 and small_caps 0.02
  expect_equal(
    results@universe_m_d_ref@data %>%
      dplyr::filter(liquidity_classification == "micro_caps") %>%
      dplyr::mutate(act_w = weights - ibov_bench_weights) %>%
      dplyr::filter(act_w > liquidity_constraint_policy$liquidity_cap_rules[1] + 1e-08) %>%
      nrow(),
    0
  )
  expect_equal(
    results@universe_m_d_ref@data %>%
      dplyr::filter(liquidity_classification == "small_caps") %>%
      dplyr::mutate(act_w = weights - ibov_bench_weights) %>%
      dplyr::filter(act_w > liquidity_constraint_policy$liquidity_cap_rules[2]) %>%
      nrow(),
    0
  )


})

test_that("set_portfolio weights works for stocks (hrp + exp_ret_score_tilt = 'inner')", {

  #Create signals_m_d_ref
  load(paste(test_path(),"/testdata/","artificial_port_obj.RData", sep =""))

  #Quantile Range
  eligibility_quantile_range <- c(0.67, 1)

  #Current date
  current_date <- "2001-06-15"

  #Initial Preps
  signals_m_d_ref <- signals_m_df %>% dplyr::filter(dates == current_date)
  liquidity_m_d_ref <- liquidity_m_df %>% dplyr::filter(dates == current_date)
  benchmark_weights_m_d_ref <- benchmark_weights_m_df %>% dplyr::filter(dates == current_date)
  stock_groups_m_d_ref <- stock_groups_m_df %>% dplyr::filter(dates == current_date)
  updated_port_weights_m_lstd_ref <- signals_m_df[which(signals_m_df$dates == "2001-05-15"), c(1:3)]
  updated_port_weights_m_lstd_ref$bop_port_weights <- c(0.20, 0.20, 0.20, 0.20, 0.20)
  exp_ret_score_tilt_eta <- 0.5

  #Derive Stock Universe
  stock_universe_m_d_ref <- derive_stock_universe_m_d_ref(signals_m_d_ref = signals_m_d_ref,
                                                          chosen_score_metric_and_position = c(Gamma = "long"),
                                                          upper_quantile_winsorization = upper_quantile_winsorization,
                                                          lower_quantile_winsorization = lower_quantile_winsorization)

  #Classify stock universe
  stock_universe_m_d_ref <- classify_investment_universe(
    universe_m_d_ref = stock_universe_m_d_ref,
    eligibility_quantile_range = eligibility_quantile_range,
    liquidity_m_d_ref = liquidity_m_d_ref,
    liquidity_constraint_policy = liquidity_constraint_policy,
    liquidity_floor_cutoffs = liquidity_floor_cutoffs_df,
    benchmark_weights_m_d_ref = benchmark_weights_m_d_ref,
    groups_m_d_ref = stock_groups_m_d_ref,
    concentration_constraint_policy = concentration_constraint_policy,
    updated_port_weights_m_lstd_ref = updated_port_weights_m_lstd_ref,
    turnover_constraint_policy = turnover_constraint_policy
  )

  #Force 1 ineligible stock to test HRP with less than full universe
  stock_universe_m_d_ref$is_eligible[1] <- 0

  #Test HRP
  expected_results <- stock_universe_m_d_ref
  exp_ret_score <- stock_universe_m_d_ref %>%
    dplyr::filter(is_eligible == 1L) %>%
    dplyr::pull(exp_ret_score)

  names(exp_ret_score) <- stock_universe_m_d_ref %>%
    dplyr::filter(is_eligible == 1L) %>%
    dplyr::pull(tickers)


  daily_stock_returns_m_xts_upd_ref <- daily_stock_returns_m_xts[which(zoo::index(daily_stock_returns_m_xts) <= current_date),]

  covariance_matrix <- estimate_covariance_matrix(tickers = c("Stock C", "Stock D", "Stock E"),
                                                  returns_m_xts_upd_ref = daily_stock_returns_m_xts_upd_ref,
                                                  cov_matrix_sample_size = 252, cov_estimation_method = covariance_estimation_method,
                                                  active_returns = FALSE,
                                                  groups_m_d_ref = stock_groups_m_d_ref)
  #Helper IVP
  ivp <- function(C){
    d <- diag(C)

    w <- 1 / d
    w <- w / sum(w)
  }

  # Calculate correlation, then distnace matrix and then hc
  corr <- cov2cor(covariance_matrix)
  dist <- as.dist(sqrt(0.5 * (1 - corr)))
  hc <- hclust(dist, method = "single")
  hc_order <- hc$order
  eligible_tickers_ordered <- rownames(covariance_matrix)[hc_order]

  #weights
  w <- rep(1, nrow(covariance_matrix))

  #Order Sigma
  ordered_sigma <- covariance_matrix[hc_order, hc_order]
  ordered_exp_ret_score <- exp_ret_score[eligible_tickers_ordered]
  index_L <- 1
  index_R <- c(2,3)
  cov_L <- ordered_sigma[index_L, index_L, drop = FALSE]
  cov_R <- ordered_sigma[index_R, index_R, drop = FALSE]
  w_R <- ivp(cov_R)
  var_L <- as.numeric(cov_L)
  var_R <- as.numeric(t(w_R) %*% cov_R %*% w_R)
  mu_L <- exp_ret_score[rownames(cov_L)]
  mu_R <- sum(w_R * exp_ret_score[rownames(cov_R)])
  rk <- rank(c(mu_L, mu_R), ties.method = "average")
  gL <- rk[1]/2; gR <- rk[2]/2
  A_L <- (1/var_L) * (gL ^ exp_ret_score_tilt_eta)
  A_R <- (1/var_R) * (gR ^ exp_ret_score_tilt_eta)
  alpha <- as.numeric(A_L/(A_L + A_R))
  w[index_L] <- w[index_L] * alpha
  w[index_R] <- w[index_R] * (1 - alpha)

  #2nd split
  index_L <- 2
  index_R <- 3
  cov_L <- ordered_sigma[index_L, index_L, drop = FALSE]
  cov_R <- ordered_sigma[index_R, index_R, drop = FALSE]
  var_L <- as.numeric(cov_L)
  var_R <- as.numeric(cov_R)
  mu_L <- exp_ret_score[rownames(cov_L)]
  mu_R <- exp_ret_score[rownames(cov_R)]
  rk <- rank(c(mu_L, mu_R), ties.method = "average")
  gL <- rk[1]/2; gR <- rk[2]/2
  A_L <- (1/var_L) * (gL ^ exp_ret_score_tilt_eta)
  A_R <- (1/var_R) * (gR ^ exp_ret_score_tilt_eta)
  alpha <- A_L/(A_L + A_R)
  w[index_L] <- w[index_L] * alpha
  w[index_R] <- w[index_R] * (1 - alpha)
  names(w) <- rownames(ordered_sigma)

  #Add exp_ret_score
  rrc <- relative_risk_contribution(w[rownames(covariance_matrix)], covariance_matrix)

  expected_results$rel_risk_contr <- c(0, rrc$rel_risk_contr)
  expected_results$weights <- c(0, w[rownames(covariance_matrix)])

    results <- set_portfolio_weights(universe_m_d_ref = stock_universe_m_d_ref, port_construction_method = "hrp",
                                     eligible_returns_m_xts_upd_ref = daily_stock_returns_m_xts_upd_ref,
                                     groups_m_d_ref = stock_groups_m_d_ref,
                                     cov_matrix_sample_size = 252, cov_estimation_method = covariance_estimation_method,
                                     active_returns = FALSE,
                                     exp_ret_score_tilt_eta = exp_ret_score_tilt_eta,
                                     exp_ret_score_tilt = "inner",
                                     selected_benchmark = "ibov", bench_assets_returns_m_xts_upd_ref = daily_stock_returns_m_xts_upd_ref
    )

  ## Add active statistics
  port_stats <- calculate_port_stats(
    universe_m_d_ref = expected_results,
    group_universe_m_d_ref = results@macro@universe_m_d_ref@data,
    group_cov_matrix = results@group_cov_matrix,
    selected_benchmark = "ibov",
    bench_universe_m_d_ref = benchmark_weights_m_d_ref %>%
      dplyr::mutate(weights = ibov,
                    is_eligible = ifelse(weights > 0, 1, 0)),
    all_returns_m_xts_upd_ref = daily_stock_returns_m_xts_upd_ref,
    cov_matrix_sample_size = 252,
    cov_estimation_method = covariance_estimation_method,
    groups_m_d_ref = stock_groups_m_d_ref
  )
  expect_equal(results@port_stats, port_stats$port_stats)


  expect_equal(results@universe_m_d_ref@data,
               expected_results %>%
                 dplyr::left_join(port_stats$assets_stats %>%
                                    dplyr::rename(
                                      act_weights = weights,
                                      act_rel_risk_contr = rel_risk_contr
                                    ), by = "tickers") %>%
                 dplyr::relocate(
                   act_rel_risk_contr, .before = act_weights
                 )
               )
  expect_equal(results@universe_m_d_ref@data$weights %>% sum(), 1)

  # Test that relative risk contribution is biased towards the stock with highest expected return
  stock_with_highest_exp_ret <- expected_results %>%
    dplyr::filter(is_eligible == 1L) %>%
    dplyr::filter(exp_ret_score == max(exp_ret_score)) %>%
    dplyr::pull(tickers)

  stock_with_highest_rrc <- results@universe_m_d_ref@data %>%
    dplyr::filter(rel_risk_contr == max(rel_risk_contr)) %>%
    dplyr::pull(tickers)

  expect_true(stock_with_highest_rrc %in% stock_with_highest_exp_ret)



})

test_that("set portfolio weights works for stocks (mvo_unc) - artificial_port_obj ", {

  #Create signals_m_d_ref
  load(paste(test_path(),"/testdata/","artificial_port_obj.RData", sep =""))

  #Quantile Range
  eligibility_quantile_range <- c(0.67, 1)

  #Current date
  current_date <- "2001-06-15"

  #Initial Preps
  signals_m_d_ref <- signals_m_df %>% dplyr::filter(dates == current_date)
  liquidity_m_d_ref <- liquidity_m_df %>% dplyr::filter(dates == current_date)
  benchmark_weights_m_d_ref <- benchmark_weights_m_df %>% dplyr::filter(dates == current_date)
  stock_groups_m_d_ref <- stock_groups_m_df %>% dplyr::filter(dates == current_date)
  updated_port_weights_m_lstd_ref <- signals_m_df[which(signals_m_df$dates == "2001-05-15"), c(1:3)]
  updated_port_weights_m_lstd_ref$bop_port_weights <- c(0.20, 0.20, 0.20, 0.20, 0.20)

  #Derive Stock Universe
  stock_universe_m_d_ref <- derive_stock_universe_m_d_ref(signals_m_d_ref = signals_m_d_ref, chosen_score_metric_and_position = c(Gamma = "long"),
                                                          upper_quantile_winsorization = upper_quantile_winsorization,
                                                          lower_quantile_winsorization = lower_quantile_winsorization)

  #Classify stock universe
  stock_universe_m_d_ref <- classify_investment_universe(
    universe_m_d_ref = stock_universe_m_d_ref,
    eligibility_quantile_range = eligibility_quantile_range,
    liquidity_m_d_ref = liquidity_m_d_ref,
    liquidity_constraint_policy = liquidity_constraint_policy,
    liquidity_floor_cutoffs = liquidity_floor_cutoffs_df,
    benchmark_weights_m_d_ref = benchmark_weights_m_d_ref,
    groups_m_d_ref = stock_groups_m_d_ref,
    concentration_constraint_policy = concentration_constraint_policy,
    updated_port_weights_m_lstd_ref = updated_port_weights_m_lstd_ref,
    turnover_constraint_policy = turnover_constraint_policy
  )

  #Test MVO Unconstrained
  expected_results <- stock_universe_m_d_ref
  daily_stock_returns_m_xts_upd_ref <- daily_stock_returns_m_xts[which(zoo::index(daily_stock_returns_m_xts) <= current_date),]

  covariance_matrix <- estimate_covariance_matrix(tickers = stock_universe_m_d_ref$tickers, returns_m_xts_upd_ref = daily_stock_returns_m_xts_upd_ref,
                                                  cov_matrix_sample_size = 252, cov_estimation_method = covariance_estimation_method,
                                                  active_returns = FALSE,
                                                  groups_m_d_ref = stock_groups_m_d_ref
  )

  #Portfolio
  port_spec <- PortfolioAnalytics::portfolio.spec(assets = expected_results$tickers)
  port_spec_constrained <- PortfolioAnalytics::add.constraint(portfolio = port_spec, type = "full_investment")
  port_spec_constrained <- PortfolioAnalytics::add.constraint(portfolio = port_spec, type = "box")

  set.seed(123)
  rp_weights <- PortfolioAnalytics::random_portfolios(portfolio = port_spec_constrained,
                                                      permutations = 2000,
                                                      rp_method = "sample")

  #Best Portfolio for Sharpe
  rp_weights <- as.matrix(rp_weights)  # Portfolio weights
  exp_ret_score <- as.matrix(stock_universe_m_d_ref$exp_ret_score)  # Expected return vector
  cov_matrix <- as.matrix(covariance_matrix)  # Covariance matrix
  # Calculate Portfolio Return (Expected Return)
  portfolio_return <- rp_weights %*% exp_ret_score  # Matrix multiplication
  # Calculate Portfolio Risk (Standard Deviation)
  portfolio_risk <- sqrt(rowSums((rp_weights %*% cov_matrix) * rp_weights))
  # Optimal Sharpe
  optimal_sharpe_weights <- rp_weights[which.max(portfolio_return/portfolio_risk),]
  optimal_ret <-  portfolio_return[which.max(portfolio_return/portfolio_risk),]
  optimal_risk <- portfolio_risk[which.max(portfolio_return/portfolio_risk)]

  set.seed(123)
  results <- set_portfolio_weights(universe_m_d_ref = stock_universe_m_d_ref, port_construction_method = "mvo",
                                   eligible_returns_m_xts_upd_ref = daily_stock_returns_m_xts_upd_ref, groups_m_d_ref = stock_groups_m_d_ref,
                                   cov_matrix_sample_size = 252, cov_estimation_method = covariance_estimation_method
  )

  #Check for random weights generation
  expected_weights <- t(rp_weights) %>% as.data.frame() %>% tibble::rownames_to_column("tickers")
  expect_equal(results@random_port_weights, expected_weights)
  expect_equal(results@weights, optimal_sharpe_weights %>% unname())
  expect_equal(2.375, optimal_ret, tolerance = 1e-2)
  expect_equal(0.795, optimal_risk, tolerance = 1e-2)

  #Best Portfolio for Return
  optimal_ret_weights <-  rp_weights[which.max(portfolio_return),]

  set.seed(123)
  results <- set_portfolio_weights(universe_m_d_ref = stock_universe_m_d_ref, port_construction_method = "mvo",
                                   eligible_returns_m_xts_upd_ref = daily_stock_returns_m_xts_upd_ref, groups_m_d_ref = stock_groups_m_d_ref,
                                   cov_matrix_sample_size = 252, cov_estimation_method = covariance_estimation_method,
                                   opt_objective = "return"
  )
  expect_equal(results@weights, optimal_ret_weights %>% unname())

  #Best Portfolio for Risk
  optimal_risk_weights <-  rp_weights[which.min(portfolio_risk),]

  set.seed(123)
  results <- set_portfolio_weights(universe_m_d_ref = stock_universe_m_d_ref, port_construction_method = "mvo",
                                   eligible_returns_m_xts_upd_ref = daily_stock_returns_m_xts_upd_ref, groups_m_d_ref = stock_groups_m_d_ref,
                                   cov_matrix_sample_size = 252, cov_estimation_method = covariance_estimation_method,
                                   opt_objective = "risk"
  )
  expect_equal(results@weights, optimal_risk_weights %>% unname())
  expected_results$rel_risk_contr <- relative_risk_contribution(optimal_risk_weights %>% unname(), covariance_matrix)$rel_risk_contr
  expected_results$weights <- optimal_risk_weights

  expect_equal(results@universe_m_d_ref@data, expected_results)
  expect_equal(results@universe_m_d_ref@data$weights %>% sum(), 1)


})

test_that("set portfolio weights works for stocks (mvo_con) - artificial_port_obj ", {

  #Create signals_m_d_ref
  load(paste(test_path(),"/testdata/","artificial_port_obj.RData", sep =""))

  #Quantile Range
  eligibility_quantile_range <- c(0.67, 1)

  #Current date
  current_date <- "2001-06-15"

  #Initial Preps
  signals_m_d_ref <- signals_m_df %>% dplyr::filter(dates == current_date)
  liquidity_m_d_ref <- liquidity_m_df %>% dplyr::filter(dates == current_date)
  benchmark_weights_m_d_ref <- benchmark_weights_m_df %>% dplyr::filter(dates == current_date)
  stock_groups_m_d_ref <- stock_groups_m_df %>% dplyr::filter(dates == current_date)
  updated_port_weights_m_lstd_ref <- signals_m_df[which(signals_m_df$dates == "2001-05-15"), c(1:3)]
  updated_port_weights_m_lstd_ref$bop_port_weights <- c(0.20, 0.20, 0.20, 0.20, 0.20)

  #Derive Stock Universe
  stock_universe_m_d_ref <- derive_stock_universe_m_d_ref(signals_m_d_ref = signals_m_d_ref, chosen_score_metric_and_position = c(Gamma = "long"),
                                                          upper_quantile_winsorization = upper_quantile_winsorization,
                                                          lower_quantile_winsorization = lower_quantile_winsorization)

  #Classify stock universe
  stock_universe_m_d_ref <- classify_investment_universe(
    universe_m_d_ref = stock_universe_m_d_ref,
    eligibility_quantile_range = eligibility_quantile_range,
    liquidity_m_d_ref = liquidity_m_d_ref,
    liquidity_constraint_policy = liquidity_constraint_policy,
    liquidity_floor_cutoffs = liquidity_floor_cutoffs_df,
    benchmark_weights_m_d_ref = benchmark_weights_m_d_ref,
    selected_benchmark = "ibov",
    groups_m_d_ref = stock_groups_m_d_ref,
    concentration_constraint_policy = concentration_constraint_policy,
    updated_port_weights_m_lstd_ref = updated_port_weights_m_lstd_ref,
    turnover_constraint_policy = turnover_constraint_policy
  )

  #Test MVO Constrained
  expected_results <- stock_universe_m_d_ref
  daily_stock_returns_m_xts_upd_ref <- daily_stock_returns_m_xts[which(zoo::index(daily_stock_returns_m_xts) <= current_date),]

  covariance_matrix <-  estimate_covariance_matrix(tickers = stock_universe_m_d_ref$tickers, returns_m_xts_upd_ref = daily_stock_returns_m_xts_upd_ref,
                                                   cov_matrix_sample_size = 252, cov_estimation_method = covariance_estimation_method,
                                                   active_returns = FALSE, groups_m_d_ref = stock_groups_m_d_ref
  )


  #Portfolio
  port_spec <- PortfolioAnalytics::portfolio.spec(assets = stock_universe_m_d_ref$tickers)
  port_spec_constrained <- PortfolioAnalytics::add.constraint(portfolio = port_spec, type = "full_investment")
  #Box constraints
  eligible_universe_m_d_ref <- generate_box_constraints(universe_m_d_ref = stock_universe_m_d_ref,
                                                        liquidity_constraint_policy = liquidity_constraint_policy,
                                                        turnover_constraint_policy = turnover_constraint_policy,
                                                        concentration_constraint_policy = concentration_constraint_policy)

  port_spec_constrained <- PortfolioAnalytics::add.constraint(type = "box", portfolio = port_spec_constrained,
                                                              min = eligible_universe_m_d_ref$min_weight,
                                                              max = eligible_universe_m_d_ref$max_weight)
  #Group constraints
  group_constraints_helper <- generate_group_constraints(universe_m_d_ref = stock_universe_m_d_ref, concentration_constraint_policy = concentration_constraint_policy,
                                                         groups_m_d_ref = stock_groups_m_d_ref)

  port_spec_constrained <- PortfolioAnalytics::add.constraint(portfolio = port_spec_constrained,
                                                              type = "group",
                                                              groups = group_constraints_helper$eligible_assets_group_membership_list,
                                                              group_min = group_constraints_helper$group_constraint_min,
                                                              group_max = group_constraints_helper$group_constraint_max
  )
  expected_results$max_weight <- eligible_universe_m_d_ref$max_weight
  expected_results$min_weight <- eligible_universe_m_d_ref$min_weight

  #Generate random ports
  set.seed(123)
  rp_weights <- PortfolioAnalytics::random_portfolios(portfolio = port_spec_constrained,
                                                      permutations = 2000,
                                                      rp_method = "sample")

  #Best Portfolio for Sharpe
  rp_weights <- as.matrix(rp_weights)  # Portfolio weights
  exp_ret_score <- as.matrix(stock_universe_m_d_ref$exp_ret_score)  # Expected return vector
  cov_matrix <- as.matrix(covariance_matrix)  # Covariance matrix
  # Calculate Portfolio Return (Expected Return)
  portfolio_return <- rp_weights %*% exp_ret_score  # Matrix multiplication
  # Calculate Portfolio Risk (Standard Deviation)
  portfolio_risk <- sqrt(rowSums((rp_weights %*% cov_matrix) * rp_weights))
  # Optimal Sharpe
  optimal_sharpe_weights <- rp_weights[which.max(portfolio_return/portfolio_risk),]
  optimal_ret <-  portfolio_return[which.max(portfolio_return/portfolio_risk),]
  optimal_risk <- portfolio_risk[which.max(portfolio_return/portfolio_risk)]

  set.seed(123)
  results <- set_portfolio_weights(universe_m_d_ref = stock_universe_m_d_ref, port_construction_method = "mvo",
                                   eligible_returns_m_xts_upd_ref = daily_stock_returns_m_xts_upd_ref,
                                   selected_benchmark = "ibov", bench_assets_returns_m_xts_upd_ref = daily_stock_returns_m_xts_upd_ref,
                                   groups_m_d_ref = stock_groups_m_d_ref,
                                   cov_matrix_sample_size = 252, cov_estimation_method = covariance_estimation_method,
                                   liquidity_constraint_policy = liquidity_constraint_policy,
                                   turnover_constraint_policy = turnover_constraint_policy,
                                   concentration_constraint_policy = concentration_constraint_policy
  )

  #Check for random weights generation
  expected_weights <- t(rp_weights) %>% as.data.frame() %>% tibble::rownames_to_column("tickers")
  expect_equal(results@random_port_weights, expected_weights)
  expect_equal(results@weights, optimal_sharpe_weights %>% unname())
  expect_equal(1.485, optimal_ret, tolerance = 1e-2)
  expect_equal(0.672, optimal_risk, tolerance = 1e-2)

  #Best Portfolio for Return
  optimal_ret_weights <-  rp_weights[which.max(portfolio_return),]

  set.seed(123)
  results <- set_portfolio_weights(universe_m_d_ref = stock_universe_m_d_ref, port_construction_method = "mvo",
                                   eligible_returns_m_xts_upd_ref = daily_stock_returns_m_xts_upd_ref,
                                   groups_m_d_ref = stock_groups_m_d_ref,
                                   selected_benchmark = "ibov", bench_assets_returns_m_xts_upd_ref = daily_stock_returns_m_xts_upd_ref,
                                   cov_matrix_sample_size = 252, cov_estimation_method = covariance_estimation_method,
                                   opt_objective = "return", liquidity_constraint_policy = liquidity_constraint_policy,
                                   turnover_constraint_policy = turnover_constraint_policy,
                                   concentration_constraint_policy = concentration_constraint_policy
  )
  expect_equal(results@weights, optimal_ret_weights %>% unname())

  #Best Portfolio for Risk
  optimal_risk_weights <-  rp_weights[which.min(portfolio_risk),]

  set.seed(123)
  results <- set_portfolio_weights(universe_m_d_ref = stock_universe_m_d_ref, port_construction_method = "mvo",
                                   eligible_returns_m_xts_upd_ref = daily_stock_returns_m_xts_upd_ref, groups_m_d_ref = stock_groups_m_d_ref,
                                   cov_matrix_sample_size = 252, cov_estimation_method = covariance_estimation_method,
                                   selected_benchmark = "ibov", bench_assets_returns_m_xts_upd_ref = daily_stock_returns_m_xts_upd_ref,
                                   opt_objective = "risk", liquidity_constraint_policy = liquidity_constraint_policy,
                                   turnover_constraint_policy = turnover_constraint_policy,
                                   concentration_constraint_policy = concentration_constraint_policy
  )
  expect_equal(results@weights, optimal_risk_weights %>% unname())
  expected_results$rel_risk_contr <- relative_risk_contribution(optimal_risk_weights %>% unname(), covariance_matrix)$rel_risk_contr
  expected_results$weights <- optimal_risk_weights

  port_stats <- calculate_port_stats(
    universe_m_d_ref = expected_results,
    group_universe_m_d_ref = results@macro@universe_m_d_ref@data,
    group_cov_matrix = results@group_cov_matrix,
    selected_benchmark = "ibov",
    bench_universe_m_d_ref = benchmark_weights_m_d_ref %>%
      dplyr::mutate(weights = ibov,
                    is_eligible = ifelse(weights > 0, 1, 0)),
    all_returns_m_xts_upd_ref = daily_stock_returns_m_xts_upd_ref,
    cov_matrix_sample_size = 252,
    cov_estimation_method = covariance_estimation_method,
    groups_m_d_ref = stock_groups_m_d_ref
  )


  expect_equal(results@universe_m_d_ref@data,
               expected_results %>% dplyr::left_join(
                 port_stats$assets_stats %>%
                   dplyr::rename(act_weights = weights, act_rel_risk_contr = rel_risk_contr),
                 by = "tickers") %>%
                 dplyr::relocate(act_rel_risk_contr, .before = act_weights)
               )

  expect_equal(results@universe_m_d_ref@data$weights %>% sum(), 1)


  #Check that constraints match expectations
  #Upper box
  expect_true(all(
    all(rp_weights[,1] <= eligible_universe_m_d_ref$max_weight[1]),
    all(rp_weights[,2] <= eligible_universe_m_d_ref$max_weight[2]),
    all(rp_weights[,3] <= eligible_universe_m_d_ref$max_weight[3]),
    all(rp_weights[,4] <= eligible_universe_m_d_ref$max_weight[4])))

  #Lower box
  expect_true(all(
    all(rp_weights[,1] >= eligible_universe_m_d_ref$min_weight[1]),
    all(rp_weights[,2] >= eligible_universe_m_d_ref$min_weight[2]),
    all(rp_weights[,3] >= eligible_universe_m_d_ref$min_weight[3]),
    all(rp_weights[,4] >= eligible_universe_m_d_ref$min_weight[4])))

  #Group
  sector_cyclical <- rp_weights[,3] + rp_weights[,4]
  sector_financial <- rp_weights[,2]
  sector_oil <- rp_weights[,1]
  subsector_education <- rp_weights[,4]
  subsector_insurance <- rp_weights[,2]
  subsector_oil <- rp_weights[,1]
  subsector_retail <- rp_weights[,3]

  #Lower Group
  expect_true(all(
    all(sector_cyclical >= group_constraints_helper$group_constraint_min[1]),
    all(sector_financial >= group_constraints_helper$group_constraint_min[2]),
    all(sector_oil >= group_constraints_helper$group_constraint_min[3]),
    all(subsector_education >= group_constraints_helper$group_constraint_min[4]),
    all(subsector_insurance >= group_constraints_helper$group_constraint_min[5]),
    all(subsector_oil >= group_constraints_helper$group_constraint_min[6]),
    all(subsector_retail >= group_constraints_helper$group_constraint_min[7])
  ))

  #Upper group
  expect_true(all(
    all(sector_cyclical <= group_constraints_helper$group_constraint_max[1]),
    all(sector_financial <= group_constraints_helper$group_constraint_max[2]),
    all(sector_oil <= group_constraints_helper$group_constraint_max[3]),
    all(subsector_education <= group_constraints_helper$group_constraint_max[4]),
    all(subsector_insurance <= group_constraints_helper$group_constraint_max[5]),
    all(subsector_oil <= group_constraints_helper$group_constraint_max[6]),
    all(subsector_retail <= group_constraints_helper$group_constraint_max[7])
  ))


})

test_that("set portfolio weights works for stocks (mmaf = top_down, top_down_proxy = hrp, macro_port = sw, micro level = mvo constrained) - artificial_port_obj ", {

  #Create signals_m_d_ref
  load(paste(test_path(),"/testdata/","artificial_port_obj.RData", sep =""))

  #Quantile Range
  eligibility_quantile_range <- c(0.67, 1)

  #Current date
  current_date <- "2001-06-15"

  #Initial Preps
  signals_m_d_ref <- signals_m_df %>% dplyr::filter(dates == current_date)
  liquidity_m_d_ref <- liquidity_m_df %>% dplyr::filter(dates == current_date)
  benchmark_weights_m_d_ref <- benchmark_weights_m_df %>% dplyr::filter(dates == current_date)
  stock_groups_m_d_ref <- stock_groups_m_df %>% dplyr::filter(dates == current_date)
  updated_port_weights_m_lstd_ref <- signals_m_df[which(signals_m_df$dates == "2001-05-15"), c(1:3)]
  updated_port_weights_m_lstd_ref$bop_port_weights <- c(0.3, 0.5, 0.15, 0.05, 0)
  stock_groups_m_d_ref$Sector[2] <- "Cyclical" #To make it more interesting

  #Derive Stock Universe
  stock_universe_m_d_ref <- derive_stock_universe_m_d_ref(signals_m_d_ref = signals_m_d_ref, chosen_score_metric_and_position = c(Gamma = "short"),
                                                          upper_quantile_winsorization = upper_quantile_winsorization,
                                                          lower_quantile_winsorization = lower_quantile_winsorization)

  #Classify stock universe
  stock_universe_m_d_ref <- classify_investment_universe(
    universe_m_d_ref = stock_universe_m_d_ref,
    eligibility_quantile_range = eligibility_quantile_range,
    liquidity_m_d_ref = liquidity_m_d_ref,
    liquidity_constraint_policy = liquidity_constraint_policy,
    liquidity_floor_cutoffs = liquidity_floor_cutoffs_df,
    benchmark_weights_m_d_ref = benchmark_weights_m_d_ref,
    groups_m_d_ref = stock_groups_m_d_ref,
    selected_benchmark = "ibov",
    concentration_constraint_policy = concentration_constraint_policy,
    updated_port_weights_m_lstd_ref = updated_port_weights_m_lstd_ref,
    turnover_constraint_policy = turnover_constraint_policy
  )

  #Test MMAF
  expected_results <- stock_universe_m_d_ref
  daily_stock_returns_m_xts_upd_ref <- daily_stock_returns_m_xts[which(zoo::index(daily_stock_returns_m_xts) <= current_date),]

  cov_matrix <-  estimate_covariance_matrix(tickers = stock_universe_m_d_ref$tickers, returns_m_xts_upd_ref = daily_stock_returns_m_xts_upd_ref,
                                            cov_matrix_sample_size = 252, cov_estimation_method = covariance_estimation_method,
                                            active_returns = FALSE, groups_m_d_ref = stock_groups_m_d_ref
  )


  #Fit portfolios by sectors to define proxies
  sectors <- sort(unique(stock_groups_m_d_ref$Sector))
  sectors_members <- lapply(sectors, function(x) stock_groups_m_d_ref %>% dplyr::filter(Sector == x) %>% dplyr::pull(tickers))
  names(sectors_members) <- sectors
  eligible_universe_m_d_ref <- stock_universe_m_d_ref %>% dplyr::filter(is_eligible == 1)

  sector_port_list <- process_micro_portfolios(
    parallel = FALSE,
    universe_m_d_ref = stock_universe_m_d_ref,
    groups = sectors,
    eligible_returns_m_xts_upd_ref = daily_stock_returns_m_xts_upd_ref[,-2],
    cov_matrix_sample_size = 252,
    cov_estimation_method = covariance_estimation_method,
    group_members = sectors_members,
    groups_m_d_ref = stock_groups_m_d_ref,
    group_weights = NULL,
    micro_port_construction_method = "hrp"
  )

  # Generate macro ports
  groups_exp_ret_score <- purrr::map_vec(sector_port_list, function(x) {
    sum(dplyr::pull(x@universe_m_d_ref@data, exp_ret_score) *
          dplyr::pull(x@universe_m_d_ref@data, weights))
  })
  groups_liquidity <- purrr::map_vec(sector_port_list, function(x) {
    sum(dplyr::pull(x@universe_m_d_ref@data, mean_volfin_3m) *
          dplyr::pull(x@universe_m_d_ref@data, weights))
  })
  groups_presence <- purrr::map_vec(sector_port_list, function(x) {
    sum(dplyr::pull(x@universe_m_d_ref@data, presence) *
          dplyr::pull(x@universe_m_d_ref@data, weights))
  })
  groups_ibov_bench_weights <- stock_universe_m_d_ref %>%
    dplyr::group_by(Sector) %>%
    dplyr::summarise(ibov_bench_weights = sum(ibov_bench_weights), .groups = "drop")

  groups_liquidity_m_df <- data.frame(
    tickers = sectors,
    dates = current_date,
    mean_volfin_3m = groups_liquidity,
    presence = groups_presence
  ) %>% dplyr::mutate(
    id = paste0(tickers, "-", dates), .before = dplyr::everything()
  )
  row.names(groups_liquidity_m_df) <- NULL
  groups_liquidity_m_df$dates <- as.Date(groups_liquidity_m_df$dates)

  group_universe_m_d_ref <- data.frame(
    id = paste0(sectors, "-", current_date),
    tickers = sectors,
    dates = as.Date(current_date),
    exp_ret_score = groups_exp_ret_score,
    is_eligible = 1
  )
  row.names(group_universe_m_d_ref) <- NULL

  g1_w <- sector_port_list[[1]]@universe_m_d_ref@data %>% dplyr::pull(weights)
  g1_tickers <- sector_port_list[[1]]@universe_m_d_ref@data %>% dplyr::pull(tickers)
  g2_w <- sector_port_list[[2]]@universe_m_d_ref@data %>% dplyr::pull(weights)
  g2_tickers <- sector_port_list[[2]]@universe_m_d_ref@data %>% dplyr::pull(tickers)

  ### Calculate each cov matrix element
  groups <- list(
    list(w = g1_w, tickers = g1_tickers),
    list(w = g2_w, tickers = g2_tickers)
  )
  n_groups <- length(groups)
  group_cov <- matrix(NA, n_groups, n_groups)

  for (i in 1:n_groups) {
    for (j in 1:n_groups) {
      wi <- groups[[i]]$w
      wj <- groups[[j]]$w
      ti <- groups[[i]]$tickers
      tj <- groups[[j]]$tickers

      subcov <- cov_matrix[ti, tj, drop = FALSE]
      group_cov[i, j] <- as.numeric(t(wi) %*% subcov %*% wj)
    }
  }

  rownames(group_cov) <- colnames(group_cov) <- sectors

  ##Arranje according to order in group_universe
  group_cov <- group_cov[match(group_universe_m_d_ref$tickers, rownames(group_cov)),
                         match(group_universe_m_d_ref$tickers, colnames(group_cov))]

  group_port <- set_portfolio_weights(
    universe_m_d_ref = group_universe_m_d_ref %>%
      dplyr::left_join(groups_liquidity_m_df %>% dplyr::select(-tickers, -dates), by = "id") %>%
      dplyr::left_join(groups_ibov_bench_weights, by = c("tickers" = "Sector")) %>%
      dplyr::relocate(exp_ret_score, is_eligible, .after = dplyr::last_col()),
    port_construction_method = "sw",
    liquidity_m_d_ref = groups_liquidity_m_df,
    covariance_matrix = group_cov
  )

  group_weights <- group_port@universe_m_d_ref@data %>% dplyr::filter(is_eligible == 1) %>% dplyr::pull(weights)
  names(group_weights) <- group_port@universe_m_d_ref@data %>% dplyr::filter(is_eligible == 1) %>% dplyr::pull(tickers)


  #Now let's recalculate micro portfolios given group weights
  concentration_constraint_policy$max_abs_active_individual_weight <- 0.2
  turnover_constraint_policy$turnover_cap_rules[1] <- 0.02
  turnover_constraint_policy$turnover_cap_rules[2] <- 0.05

  set.seed(123)
  micro_port_list <- suppressWarnings(process_micro_portfolios(
      parallel = FALSE,
      universe_m_d_ref = stock_universe_m_d_ref,
      eligible_returns_m_xts_upd_ref = daily_stock_returns_m_xts_upd_ref[,-2],
      cov_matrix_sample_size = 252,
      cov_estimation_method = covariance_estimation_method,
      groups = sectors,
      group_members = sectors_members,
      group_weights = group_weights,
      micro_port_construction_method = "mvo",
      selected_benchmark = "ibov",
      groups_m_d_ref = stock_groups_m_d_ref,
      concentration_constraint_policy = concentration_constraint_policy,
      bench_assets_returns_m_xts_upd_ref = daily_stock_returns_m_xts_upd_ref,
      liquidity_constraint_policy = liquidity_constraint_policy,
      turnover_constraint_policy = turnover_constraint_policy
    ))

  # Test that constraints have been updated
  expect_equal(
    micro_port_list$Cyclical@universe_m_d_ref@data$ibov_bench_weights,
    (eligible_universe_m_d_ref %>% dplyr::filter(Sector == "Cyclical") %>% dplyr::pull(ibov_bench_weights))/group_weights[1]
  )

  expect_equal(
    micro_port_list$Cyclical@universe_m_d_ref@data$bop_port_weights,
    (eligible_universe_m_d_ref %>% dplyr::filter(Sector == "Cyclical") %>% dplyr::pull(bop_port_weights))/group_weights[1]
  )

  # Define final weights by multiplying weights by group_weight
  final_weights_m_df <- purrr::map2_dfr(micro_port_list, names(micro_port_list), function(port, group_name) {
    port@universe_m_d_ref@data %>%
      dplyr::mutate(weights = weights * group_weights[group_name])
  })

  # Join to eligible universe by id
  universe_m_d_ref_result <- stock_universe_m_d_ref %>%
    dplyr::left_join(final_weights_m_df %>% dplyr::select(id, weights), by = "id")
  universe_m_d_ref_result$weights[which(is.na(universe_m_d_ref_result$weights))] <- 0
  rel_risk_contribution <- relative_risk_contribution(
    weights = universe_m_d_ref_result %>% dplyr::filter(is_eligible == 1L) %>% dplyr::pull(weights),
    covariance_matrix = cov_matrix
  )
  universe_m_d_ref_result <- universe_m_d_ref_result %>%
    dplyr::left_join(rel_risk_contribution, by = "tickers") %>%
    dplyr::relocate(rel_risk_contr, .before = weights)
  universe_m_d_ref_result$rel_risk_contr[which(is.na(universe_m_d_ref_result$rel_risk_contr))] <- 0

  # Add relative metrics
  port_stats <- calculate_port_stats(
    universe_m_d_ref = universe_m_d_ref_result,
    group_universe_m_d_ref = group_port@universe_m_d_ref@data,
    group_cov_matrix = group_cov,
    selected_benchmark = "ibov",
    bench_universe_m_d_ref = benchmark_weights_m_d_ref %>%
      dplyr::mutate(weights = ibov,
                    is_eligible = ifelse(weights > 0, 1, 0)),
    all_returns_m_xts_upd_ref = daily_stock_returns_m_xts_upd_ref,
    cov_matrix_sample_size = 252,
    cov_estimation_method = covariance_estimation_method,
    groups_m_d_ref = stock_groups_m_d_ref
  )

  expected_results <- universe_m_d_ref_result %>%
    dplyr::left_join(
      port_stats$assets_stats %>%
        dplyr::rename(act_weights = weights, act_rel_risk_contr = rel_risk_contr),
      by = "tickers") %>%
    dplyr::relocate(act_rel_risk_contr, .before = act_weights)

  #Run and compare results
  set.seed(123)
  results <- suppressWarnings(
    set_portfolio_weights(
      universe_m_d_ref = stock_universe_m_d_ref,
      port_construction_method = "mmaf",
      top_down_proxy_port_method = "hrp",
      mmaf_method = "top_down",
      mmaf_group_col = "Sector",
      macro_port_construction_method = "sw",
      liquidity_m_d_ref = liquidity_m_d_ref,
      micro_port_construction_method = "mvo",
      eligible_returns_m_xts_upd_ref = daily_stock_returns_m_xts_upd_ref[, c(1,3,4,5)],
      selected_benchmark = "ibov",
      bench_assets_returns_m_xts_upd_ref = daily_stock_returns_m_xts_upd_ref[, c(1,3,4,5)],
      liquidity_constraint_policy = liquidity_constraint_policy,
      concentration_constraint_policy = concentration_constraint_policy,
      turnover_constraint_policy = turnover_constraint_policy,
      cov_matrix_sample_size = 252,
      cov_estimation_method = covariance_estimation_method,
      active_returns = FALSE,
      groups_m_d_ref = stock_groups_m_d_ref
    )
  )

  expect_equal(
    results@universe_m_d_ref@data,
    expected_results
  )

  #Test that weights column is between max and min ibov
  expect_true(
    stock_universe_m_d_ref %>%
      dplyr::select(tickers, ibov_bench_weights) %>%
      dplyr::mutate(max_ibov = ibov_bench_weights + concentration_constraint_policy$max_abs_active_individual_weight,
                    min_ibov = pmax(0, ibov_bench_weights - concentration_constraint_policy$max_abs_active_individual_weight)) %>%
      dplyr::left_join(results@universe_m_d_ref@data %>% dplyr::select(tickers, weights), by = "tickers") %>%
      dplyr::mutate(check = weights > min_ibov & weights < max_ibov) %>%
      dplyr::pull(check) %>% all()
  )

  # Test that weights column is between bop + constraint
  # A stock, however, will never have max weight < bench or min weight > bench
  stock_universe_m_d_ref %>%
    dplyr::filter(buffer_zone_1 == 1) %>%
    dplyr::select(tickers, ibov_bench_weights, bop_port_weights) %>%
    dplyr::mutate(max_bop = pmin(1, bop_port_weights + turnover_constraint_policy$turnover_cap_rules[1]),
                  min_bop = pmax(0, bop_port_weights - turnover_constraint_policy$turnover_cap_rules[1])) %>%
    dplyr::left_join(results@universe_m_d_ref@data %>% dplyr::select(tickers, weights), by = "tickers") %>%
    dplyr::mutate(check = weights > min_bop & weights < max_bop) %>%
    dplyr::pull(check) %>% all() %>% expect_true()


})

test_that("set portfolio weights works for stocks (ew) - toy_preprocessed", {

  #Create signals_m_d_ref
  load(paste(test_path(),"/testdata/","toy_preprocessed_port_obj.RData", sep =""))

  #Quantile Range
  eligibility_quantile_range <- c(0.67, 1)
  chosen_score_metric_and_position <- c(vol_36m = "short")

  #Check
  check_inputs_port_backtest(signals_m_df = signals_m_df, oos_predictions_m_df = NULL, chosen_score_metric_and_position = chosen_score_metric_and_position,
                             rebalancing_months = 6, initial_buffer_period = 6, port_construction_method = "ew",
                             eligibility_quantile_range = eligibility_quantile_range, selected_benchmark = "ibov",
                             min_eligible_assets_fallback = NULL, scaler_m_df = NULL, chosen_scaler = NULL, scaler_shrinkage = NULL,
                             macro_concentration_constraint_policy = NULL, macro_ridge_pen = NULL,
                             micro_port_construction_method = NULL, macro_port_construction_method = NULL,
                             use_raw_for_eligibility = NULL, exp_ret_score_tilt = NULL, exp_ret_score_tilt_eta = NULL,
                             rp_method = NULL, n_random_ports = NULL, random_ports_method = NULL, opt_objective = NULL, opt_method = NULL,
                             cov_estimation_method = NULL, cov_matrix_sample_size = NULL, active_returns = FALSE, cov_matrix_benchmark = NULL,
                             daily_stock_returns_m_xts = NULL, daily_bench_returns_m_xts = NULL, benchmark_returns_m_xts = benchmark_returns_m_xts,
                             liquidity_constraint_policy = NULL, turnover_constraint_policy = NULL, concentration_constraint_policy = NULL,
                             liquidity_m_df = liquidity_m_df, liquidity_floor_cutoffs = liquidity_floor_cutoffs_df, main_liquidity_metric = "mean_volfin_3m",
                             stock_groups_m_df = stock_groups_m_df, benchmark_weights_m_df = benchmark_weights_m_df, volatility_m_df = volatility_m_df,
                             fwd_return_m_df = fwd_return_m_df, transaction_costs_parameters = transaction_costs_list, ridge_pen = NULL,
                             custom_stock_weights_m_df = NULL, custom_stock_metrics_m_df = NULL, user_defined_OR_rules_m_df = NULL, user_defined_AND_rules_m_df = NULL,
                             upper_quantile_winsorization = 0.95, lower_quantile_winsorization = 0.05, verbose = TRUE
  )

  #Current date
  current_date <- "2023-04-15"


  #Initial Preps
  signals_m_d_ref <- signals_m_df %>% dplyr::filter(dates == current_date)
  liquidity_m_d_ref <- liquidity_m_df %>% dplyr::filter(dates == current_date)
  benchmark_weights_m_d_ref <- benchmark_weights_m_df %>% dplyr::filter(dates == current_date)
  stock_groups_m_d_ref <- stock_groups_m_df %>% dplyr::filter(dates == current_date)

  #Derive Stock Universe
  stock_universe_m_d_ref <- derive_stock_universe_m_d_ref(signals_m_d_ref = signals_m_d_ref, chosen_score_metric_and_position = c(vol_36m = "short"),
                                                          upper_quantile_winsorization = upper_quantile_winsorization,
                                                          lower_quantile_winsorization = lower_quantile_winsorization)

  #Classify stock universe
  stock_universe_m_d_ref <- classify_investment_universe(
    universe_m_d_ref = stock_universe_m_d_ref,
    eligibility_quantile_range = eligibility_quantile_range,
    liquidity_m_d_ref = liquidity_m_d_ref,
    liquidity_constraint_policy = liquidity_constraint_policy,
    liquidity_floor_cutoffs = liquidity_floor_cutoffs_df,
    benchmark_weights_m_d_ref = benchmark_weights_m_d_ref,
    groups_m_d_ref = stock_groups_m_d_ref,
    concentration_constraint_policy = concentration_constraint_policy
  )

  #Test EW
  expected_results <- stock_universe_m_d_ref
  expected_results <- expected_results %>% dplyr::mutate(weights = dplyr::if_else(is_eligible == 1, 1/sum(is_eligible), 0))
  results <- set_portfolio_weights(universe_m_d_ref = stock_universe_m_d_ref, port_construction_method = "ew")

  expect_equal(results@universe_m_d_ref@data, expected_results)
  expect_equal(results@universe_m_d_ref@data$weights %>% sum(), 1)

  #Test EW stats
  expect_equal(results@port_stats$hhi_weights, 1/(expected_results %>% dplyr::filter(is_eligible == 1) %>% nrow()))
  expect_equal(results@port_stats$n_eff_weights, expected_results %>% dplyr::filter(is_eligible == 1) %>% nrow())

})

test_that("set portfolio weights works for stocks (cw) - toy_preprocessed", {

  #Create signals_m_d_ref
  load(paste(test_path(),"/testdata/","toy_preprocessed_port_obj.RData", sep =""))

  #Quantile Range
  eligibility_quantile_range <- c(0.67, 1)
  chosen_score_metric_and_position <- c(vol_36m = "short")

  #Check
  check_inputs_port_backtest(signals_m_df = signals_m_df, oos_predictions_m_df = NULL, chosen_score_metric_and_position = chosen_score_metric_and_position,
                             rebalancing_months = 6, initial_buffer_period = 6, port_construction_method = "cw",
                             eligibility_quantile_range = eligibility_quantile_range, selected_benchmark = "ibov",
                             scaler_m_df = NULL, chosen_scaler = NULL, scaler_shrinkage = NULL,
                             macro_concentration_constraint_policy = NULL, macro_ridge_pen = NULL,
                             micro_port_construction_method = NULL, macro_port_construction_method = NULL,
                             min_eligible_assets_fallback = NULL, use_raw_for_eligibility = NULL, exp_ret_score_tilt = NULL, exp_ret_score_tilt_eta = NULL,
                             rp_method = NULL, n_random_ports = NULL, random_ports_method = NULL, opt_objective = NULL, opt_method = NULL,
                             cov_estimation_method = NULL, cov_matrix_sample_size = NULL, active_returns = FALSE, cov_matrix_benchmark = NULL,
                             daily_stock_returns_m_xts = NULL, daily_bench_returns_m_xts = NULL, benchmark_returns_m_xts = benchmark_returns_m_xts,
                             liquidity_constraint_policy = NULL, turnover_constraint_policy = NULL, concentration_constraint_policy = NULL,
                             liquidity_m_df = liquidity_m_df, liquidity_floor_cutoffs = liquidity_floor_cutoffs_df, main_liquidity_metric = "mean_volfin_3m",
                             stock_groups_m_df = stock_groups_m_df, benchmark_weights_m_df = benchmark_weights_m_df, volatility_m_df = volatility_m_df,
                             fwd_return_m_df = fwd_return_m_df, transaction_costs_parameters = transaction_costs_list, ridge_pen = NULL,
                             custom_stock_weights_m_df = NULL, custom_stock_metrics_m_df = NULL, user_defined_OR_rules_m_df = NULL, user_defined_AND_rules_m_df = NULL,
                             upper_quantile_winsorization = 0.95, lower_quantile_winsorization = 0.05, verbose = TRUE
  )

  #Current date
  current_date <- "2023-04-15"

  #Initial Preps
  signals_m_d_ref <- signals_m_df %>% dplyr::filter(dates == current_date)
  liquidity_m_d_ref <- liquidity_m_df %>% dplyr::filter(dates == current_date)
  benchmark_weights_m_d_ref <- benchmark_weights_m_df %>% dplyr::filter(dates == current_date)
  stock_groups_m_d_ref <- stock_groups_m_df %>% dplyr::filter(dates == current_date)

  #Derive Stock Universe
  stock_universe_m_d_ref <- derive_stock_universe_m_d_ref(signals_m_d_ref = signals_m_d_ref, chosen_score_metric_and_position = c(vol_36m = "short"),
                                                          upper_quantile_winsorization = upper_quantile_winsorization,
                                                          lower_quantile_winsorization = lower_quantile_winsorization)

  #Classify stock universe
  stock_universe_m_d_ref <- classify_investment_universe(
    universe_m_d_ref = stock_universe_m_d_ref,
    eligibility_quantile_range = eligibility_quantile_range,
    liquidity_m_d_ref = liquidity_m_d_ref,
    liquidity_constraint_policy = liquidity_constraint_policy,
    liquidity_floor_cutoffs = liquidity_floor_cutoffs_df,
    benchmark_weights_m_d_ref = benchmark_weights_m_d_ref,
    groups_m_d_ref = stock_groups_m_d_ref,
    concentration_constraint_policy = concentration_constraint_policy
  )

  #Test CW
  expected_results <- stock_universe_m_d_ref
  expected_results <- expected_results %>%
    dplyr::mutate(cap_score = signal_transform(mean_volfin_3m, lower_quantile_winsorization, upper_quantile_winsorization))
  expected_results$weights[expected_results$is_eligible == 1] <- expected_results$cap_score[expected_results$is_eligible == 1]/sum(expected_results$cap_score[expected_results$is_eligible == 1])
  expected_results$weights[which(is.na(expected_results$weights))] <- 0

  results <- set_portfolio_weights(universe_m_d_ref = stock_universe_m_d_ref, port_construction_method = "cw",
                                   liquidity_m_d_ref = liquidity_m_d_ref, cap_weighting_metric = "mean_volfin_3m")

  expect_equal(results@universe_m_d_ref@data, expected_results)
  expect_equal(results@universe_m_d_ref@data$weights %>% sum(), 1)

})

test_that("set portfolio weights works for stocks (sw) - toy_preprocessed", {

  #Create signals_m_d_ref
  load(paste(test_path(),"/testdata/","toy_preprocessed_port_obj.RData", sep =""))

  #Quantile Range
  eligibility_quantile_range <- c(0.67, 1)
  chosen_score_metric_and_position <- c(vol_36m = "short")

  #Check
  check_inputs_port_backtest(signals_m_df = signals_m_df, oos_predictions_m_df = NULL, chosen_score_metric_and_position = chosen_score_metric_and_position,
                             rebalancing_months = 6, initial_buffer_period = 6, port_construction_method = "sw",
                             eligibility_quantile_range = eligibility_quantile_range, selected_benchmark = "ibov",
                             min_eligible_assets_fallback = NULL, scaler_m_df = NULL, chosen_scaler = NULL, scaler_shrinkage = NULL,
                             use_raw_for_eligibility = NULL, exp_ret_score_tilt = NULL, exp_ret_score_tilt_eta = NULL,
                             rp_method = NULL, n_random_ports = NULL, random_ports_method = NULL, opt_objective = NULL, opt_method = NULL,
                             macro_concentration_constraint_policy = NULL, macro_ridge_pen = NULL,
                             micro_port_construction_method = NULL, macro_port_construction_method = NULL,
                             cov_estimation_method = NULL, cov_matrix_sample_size = NULL, active_returns = FALSE, cov_matrix_benchmark = NULL,
                             daily_stock_returns_m_xts = NULL, daily_bench_returns_m_xts = NULL, benchmark_returns_m_xts = benchmark_returns_m_xts,
                             liquidity_constraint_policy = NULL, turnover_constraint_policy = NULL, concentration_constraint_policy = NULL,
                             liquidity_m_df = liquidity_m_df, liquidity_floor_cutoffs = liquidity_floor_cutoffs_df, main_liquidity_metric = "mean_volfin_3m",
                             stock_groups_m_df = stock_groups_m_df, benchmark_weights_m_df = benchmark_weights_m_df, volatility_m_df = volatility_m_df,
                             fwd_return_m_df = fwd_return_m_df, transaction_costs_parameters = transaction_costs_list, ridge_pen = NULL,
                             custom_stock_weights_m_df = NULL, custom_stock_metrics_m_df = NULL, user_defined_OR_rules_m_df = NULL, user_defined_AND_rules_m_df = NULL,
                             upper_quantile_winsorization = 0.95, lower_quantile_winsorization = 0.05, verbose = TRUE
  )

  #Current date
  current_date <- "2023-04-15"

  #Initial Preps
  signals_m_d_ref <- signals_m_df %>% dplyr::filter(dates == current_date)
  liquidity_m_d_ref <- liquidity_m_df %>% dplyr::filter(dates == current_date)
  benchmark_weights_m_d_ref <- benchmark_weights_m_df %>% dplyr::filter(dates == current_date)
  stock_groups_m_d_ref <- stock_groups_m_df %>% dplyr::filter(dates == current_date)

  #Derive Stock Universe
  stock_universe_m_d_ref <- derive_stock_universe_m_d_ref(signals_m_d_ref = signals_m_d_ref, chosen_score_metric_and_position = c(vol_36m = "short"),
                                                          upper_quantile_winsorization = upper_quantile_winsorization,
                                                          lower_quantile_winsorization = lower_quantile_winsorization)

  #Classify stock universe
  stock_universe_m_d_ref <- classify_investment_universe(
    universe_m_d_ref = stock_universe_m_d_ref,
    eligibility_quantile_range = eligibility_quantile_range,
    liquidity_m_d_ref = liquidity_m_d_ref,
    liquidity_constraint_policy = liquidity_constraint_policy,
    liquidity_floor_cutoffs = liquidity_floor_cutoffs_df,
    benchmark_weights_m_d_ref = benchmark_weights_m_d_ref,
    groups_m_d_ref = stock_groups_m_d_ref,
    concentration_constraint_policy = concentration_constraint_policy
  )

  #Test SW
  expected_results <- stock_universe_m_d_ref
  expected_results$weights[expected_results$is_eligible == 1] <- (expected_results$exp_ret_score[expected_results$is_eligible == 1])/
    sum(expected_results$exp_ret_score[expected_results$is_eligible == 1])
  expected_results$weights[which(is.na(expected_results$weights))] <- 0

  results <- set_portfolio_weights(universe_m_d_ref = stock_universe_m_d_ref, port_construction_method = "sw",
                                   liquidity_m_d_ref = liquidity_m_d_ref)

  expect_equal(results@universe_m_d_ref@data, expected_results)
  expect_equal(results@universe_m_d_ref@data %>% dplyr::filter(is_eligible == 1) %>% dplyr::slice_max(weights, n = 50) %>% dplyr::pull(tickers),
               results@universe_m_d_ref@data %>% dplyr::filter(is_eligible == 1) %>% dplyr::slice_max(exp_ret_score, n = 50) %>% dplyr::pull(tickers))
  expect_equal(results@universe_m_d_ref@data$weights %>% sum(), 1)

})

test_that("set portfolio weights works for stocks (cs) - toy_preprocessed", {

  #Create signals_m_d_ref
  load(paste(test_path(),"/testdata/","toy_preprocessed_port_obj.RData", sep =""))

  #Quantile Range
  eligibility_quantile_range <- c(0.67, 1)
  chosen_score_metric_and_position <- c(vol_36m = "short")

  #Check
  check_inputs_port_backtest(signals_m_df = signals_m_df, oos_predictions_m_df = NULL, chosen_score_metric_and_position = chosen_score_metric_and_position,
                             rebalancing_months = 6, initial_buffer_period = 6, port_construction_method = "cw",
                             eligibility_quantile_range = eligibility_quantile_range, selected_benchmark = "ibov",
                             min_eligible_assets_fallback = NULL, scaler_m_df = NULL, chosen_scaler = NULL, scaler_shrinkage = NULL,
                             macro_concentration_constraint_policy = NULL, macro_ridge_pen = NULL,
                             micro_port_construction_method = NULL, macro_port_construction_method = NULL,
                             use_raw_for_eligibility = NULL, exp_ret_score_tilt = NULL, exp_ret_score_tilt_eta = NULL,
                             rp_method = NULL, n_random_ports = NULL, random_ports_method = NULL, opt_objective = NULL, opt_method = NULL,
                             cov_estimation_method = NULL, cov_matrix_sample_size = NULL, active_returns = FALSE, cov_matrix_benchmark = NULL,
                             daily_stock_returns_m_xts = NULL, daily_bench_returns_m_xts = NULL, benchmark_returns_m_xts = benchmark_returns_m_xts,
                             liquidity_constraint_policy = NULL, turnover_constraint_policy = NULL, concentration_constraint_policy = NULL,
                             liquidity_m_df = liquidity_m_df, liquidity_floor_cutoffs = liquidity_floor_cutoffs_df, main_liquidity_metric = "mean_volfin_3m",
                             stock_groups_m_df = stock_groups_m_df, benchmark_weights_m_df = benchmark_weights_m_df, volatility_m_df = volatility_m_df,
                             fwd_return_m_df = fwd_return_m_df, transaction_costs_parameters = transaction_costs_list, ridge_pen = NULL,
                             custom_stock_weights_m_df = NULL, custom_stock_metrics_m_df = NULL, user_defined_OR_rules_m_df = NULL, user_defined_AND_rules_m_df = NULL,
                             upper_quantile_winsorization = 0.95, lower_quantile_winsorization = 0.05, verbose = TRUE
  )

  #Current date
  current_date <- "2023-04-15"

  #Initial Preps
  signals_m_d_ref <- signals_m_df %>% dplyr::filter(dates == current_date)
  liquidity_m_d_ref <- liquidity_m_df %>% dplyr::filter(dates == current_date)
  benchmark_weights_m_d_ref <- benchmark_weights_m_df %>% dplyr::filter(dates == current_date)
  stock_groups_m_d_ref <- stock_groups_m_df %>% dplyr::filter(dates == current_date)

  #Derive Stock Universe
  stock_universe_m_d_ref <- derive_stock_universe_m_d_ref(signals_m_d_ref = signals_m_d_ref, chosen_score_metric_and_position = c(vol_36m = "short"),
                                                          upper_quantile_winsorization = upper_quantile_winsorization,
                                                          lower_quantile_winsorization = lower_quantile_winsorization)

  #Classify stock universe
  stock_universe_m_d_ref <- classify_investment_universe(
    universe_m_d_ref = stock_universe_m_d_ref,
    eligibility_quantile_range = eligibility_quantile_range,
    liquidity_m_d_ref = liquidity_m_d_ref,
    liquidity_constraint_policy = liquidity_constraint_policy,
    liquidity_floor_cutoffs = liquidity_floor_cutoffs_df,
    benchmark_weights_m_d_ref = benchmark_weights_m_d_ref,
    groups_m_d_ref = stock_groups_m_d_ref,
    concentration_constraint_policy = concentration_constraint_policy
  )

  #Test CS
  expected_results <- stock_universe_m_d_ref
  expected_results$cap_score <- signal_transform(expected_results$mean_volfin_3m, lower_quantile_winsorization, upper_quantile_winsorization)
  expected_results$weights[expected_results$is_eligible == 1] <- (expected_results$cap_score[expected_results$is_eligible == 1] * expected_results$exp_ret_score[expected_results$is_eligible == 1])/
    sum((expected_results$cap_score[expected_results$is_eligible == 1] * expected_results$exp_ret_score[expected_results$is_eligible == 1]))
  expected_results$weights[which(is.na(expected_results$weights))] <- 0

  results <- set_portfolio_weights(universe_m_d_ref = stock_universe_m_d_ref, port_construction_method = "cs",
                                   liquidity_m_d_ref = liquidity_m_d_ref, cap_weighting_metric = "mean_volfin_3m")

  expect_equal(results@universe_m_d_ref@data, expected_results)
  expect_equal(results@universe_m_d_ref@data$weights %>% sum(), 1)

})

test_that("set portfolio weights works for stocks (rp) - toy_preprocessed", {

  #Create signals_m_d_ref
  load(paste(test_path(),"/testdata/","toy_preprocessed_port_obj.RData", sep =""))

  #Quantile Range and others
  eligibility_quantile_range <- c(0.67, 1)
  chosen_score_metric_and_position <- c(vol_36m = "short")
  cov_matrix_sample_size <- 60
  cov_estimation_method <- "cc"

  #Check
  check_inputs_port_backtest(signals_m_df = signals_m_df, oos_predictions_m_df = NULL, chosen_score_metric_and_position = chosen_score_metric_and_position,
                             rebalancing_months = 6, initial_buffer_period = 6, port_construction_method = "rp",
                             eligibility_quantile_range = eligibility_quantile_range, selected_benchmark = "ibov",
                             min_eligible_assets_fallback = NULL, scaler_m_df = NULL, chosen_scaler = NULL, scaler_shrinkage = NULL,
                             use_raw_for_eligibility = NULL, exp_ret_score_tilt = NULL, exp_ret_score_tilt_eta = NULL,
                             rp_method = NULL, n_random_ports = NULL, random_ports_method = NULL, opt_objective = NULL, opt_method = NULL,
                             macro_concentration_constraint_policy = NULL, macro_ridge_pen = NULL,
                             micro_port_construction_method = NULL, macro_port_construction_method = NULL,
                             cov_estimation_method = cov_estimation_method, cov_matrix_sample_size = cov_matrix_sample_size, active_returns = FALSE, cov_matrix_benchmark = NULL,
                             daily_stock_returns_m_xts = daily_stock_returns_m_xts, daily_bench_returns_m_xts = NULL, benchmark_returns_m_xts = benchmark_returns_m_xts,
                             liquidity_constraint_policy = NULL, turnover_constraint_policy = NULL, concentration_constraint_policy = NULL,
                             liquidity_m_df = liquidity_m_df, liquidity_floor_cutoffs = liquidity_floor_cutoffs_df, main_liquidity_metric = "mean_volfin_3m",
                             stock_groups_m_df = stock_groups_m_df, benchmark_weights_m_df = benchmark_weights_m_df, volatility_m_df = volatility_m_df,
                             fwd_return_m_df = fwd_return_m_df, transaction_costs_parameters = transaction_costs_list, ridge_pen = NULL,
                             custom_stock_weights_m_df = NULL, custom_stock_metrics_m_df = NULL, user_defined_OR_rules_m_df = NULL, user_defined_AND_rules_m_df = NULL,
                             upper_quantile_winsorization = 0.95, lower_quantile_winsorization = 0.05, verbose = TRUE
  )

  #Current date
  current_date <- "2023-04-15"

  #Initial Preps
  signals_m_d_ref <- signals_m_df %>% dplyr::filter(dates == current_date)
  liquidity_m_d_ref <- liquidity_m_df %>% dplyr::filter(dates == current_date)
  benchmark_weights_m_d_ref <- benchmark_weights_m_df %>% dplyr::filter(dates == current_date)
  stock_groups_m_d_ref <- stock_groups_m_df %>% dplyr::filter(dates == current_date)

  #Derive Stock Universe
  stock_universe_m_d_ref <- derive_stock_universe_m_d_ref(signals_m_d_ref = signals_m_d_ref, chosen_score_metric_and_position = c(vol_36m = "short"),
                                                          upper_quantile_winsorization = upper_quantile_winsorization,
                                                          lower_quantile_winsorization = lower_quantile_winsorization)

  #Classify stock universe
  stock_universe_m_d_ref <- classify_investment_universe(
    universe_m_d_ref = stock_universe_m_d_ref,
    eligibility_quantile_range = eligibility_quantile_range,
    liquidity_m_d_ref = liquidity_m_d_ref,
    liquidity_constraint_policy = liquidity_constraint_policy,
    liquidity_floor_cutoffs = liquidity_floor_cutoffs_df,
    benchmark_weights_m_d_ref = benchmark_weights_m_d_ref,
    groups_m_d_ref = stock_groups_m_d_ref,
    concentration_constraint_policy = concentration_constraint_policy
  )

  #Test RP
  expected_results <- stock_universe_m_d_ref
  daily_stock_returns_m_xts_upd_ref <- daily_stock_returns_m_xts[which(zoo::index(daily_stock_returns_m_xts) <= current_date),]
  eligible_tickers <- expected_results %>% dplyr::filter(is_eligible == 1) %>% dplyr::pull(tickers)

  covariance_matrix <- estimate_covariance_matrix(tickers = eligible_tickers, returns_m_xts_upd_ref = daily_stock_returns_m_xts_upd_ref,
                                                  cov_matrix_sample_size = cov_matrix_sample_size, cov_estimation_method = cov_estimation_method,
                                                  active_returns = FALSE,
                                                  groups_m_d_ref = stock_groups_m_d_ref
  )

  rp_results <- riskParityPortfolio::riskParityPortfolio(Sigma = covariance_matrix)

  expected_results[which(expected_results$is_eligible == 1), "rel_risk_contr"] <-
    rp_results$relative_risk_contribution[expected_results[which(expected_results$is_eligible == 1), "tickers"]] #Fill only eligibles

  expected_results[which(expected_results$is_eligible == 1), "weights"] <-
    rp_results$w[expected_results[which(expected_results$is_eligible == 1), "tickers"]] #Fill only eligibles

  expected_results$rel_risk_contr[which(is.na(expected_results$rel_risk_contr))] <- 0
  expected_results$weights[which(is.na(expected_results$weights))] <- 0


  results <- set_portfolio_weights(universe_m_d_ref = stock_universe_m_d_ref, port_construction_method = "rp",
                                   eligible_returns_m_xts_upd_ref = daily_stock_returns_m_xts_upd_ref, groups_m_d_ref = stock_groups_m_d_ref,
                                   cov_matrix_sample_size = cov_matrix_sample_size, cov_estimation_method = cov_estimation_method,
                                   active_returns = FALSE
  )


  expect_equal(results@universe_m_d_ref@data, expected_results)


})

test_that("set portfolio weights works for stocks (rp + exp_ret_score_tilt = 'inner') - toy_preprocessed", {

  #Create signals_m_d_ref
  load(paste(test_path(),"/testdata/","toy_preprocessed_port_obj.RData", sep =""))

  #Quantile Range and others
  eligibility_quantile_range <- c(0.67, 1)
  chosen_score_metric_and_position <- c(vol_36m = "short")
  cov_matrix_sample_size <- 60
  cov_estimation_method <- "cc"
  exp_ret_score_tilt <- "inner"
  exp_ret_score_tilt_eta <- 0.5

  #Check
  check_inputs_port_backtest(signals_m_df = signals_m_df, oos_predictions_m_df = NULL, chosen_score_metric_and_position = chosen_score_metric_and_position,
                             rebalancing_months = 6, initial_buffer_period = 6, port_construction_method = "rp",
                             eligibility_quantile_range = eligibility_quantile_range, selected_benchmark = "ibov",
                             min_eligible_assets_fallback = NULL, scaler_m_df = NULL, chosen_scaler = NULL, scaler_shrinkage = NULL,
                             use_raw_for_eligibility = NULL, exp_ret_score_tilt = exp_ret_score_tilt,
                             exp_ret_score_tilt_eta = exp_ret_score_tilt_eta,
                             macro_concentration_constraint_policy = NULL, macro_ridge_pen = NULL,
                             micro_port_construction_method = NULL, macro_port_construction_method = NULL,
                             rp_method = NULL, n_random_ports = NULL, random_ports_method = NULL, opt_objective = NULL, opt_method = NULL,
                             cov_estimation_method = cov_estimation_method, cov_matrix_sample_size = cov_matrix_sample_size, active_returns = FALSE, cov_matrix_benchmark = NULL,
                             daily_stock_returns_m_xts = daily_stock_returns_m_xts, daily_bench_returns_m_xts = NULL, benchmark_returns_m_xts = benchmark_returns_m_xts,
                             liquidity_constraint_policy = NULL, turnover_constraint_policy = NULL, concentration_constraint_policy = NULL,
                             liquidity_m_df = liquidity_m_df, liquidity_floor_cutoffs = liquidity_floor_cutoffs_df, main_liquidity_metric = "mean_volfin_3m",
                             stock_groups_m_df = stock_groups_m_df, benchmark_weights_m_df = benchmark_weights_m_df, volatility_m_df = volatility_m_df,
                             fwd_return_m_df = fwd_return_m_df, transaction_costs_parameters = transaction_costs_list, ridge_pen = NULL,
                             custom_stock_weights_m_df = NULL, custom_stock_metrics_m_df = NULL, user_defined_OR_rules_m_df = NULL, user_defined_AND_rules_m_df = NULL,
                             upper_quantile_winsorization = 0.95, lower_quantile_winsorization = 0.05, verbose = TRUE
  )

  #Current date
  current_date <- "2023-04-15"

  #Initial Preps
  signals_m_d_ref <- signals_m_df %>% dplyr::filter(dates == current_date)
  liquidity_m_d_ref <- liquidity_m_df %>% dplyr::filter(dates == current_date)
  benchmark_weights_m_d_ref <- benchmark_weights_m_df %>% dplyr::filter(dates == current_date)
  stock_groups_m_d_ref <- stock_groups_m_df %>% dplyr::filter(dates == current_date)

  #Derive Stock Universe
  stock_universe_m_d_ref <- derive_stock_universe_m_d_ref(signals_m_d_ref = signals_m_d_ref,
                                                          chosen_score_metric_and_position = c(vol_36m = "short"),
                                                          upper_quantile_winsorization = upper_quantile_winsorization,
                                                          lower_quantile_winsorization = lower_quantile_winsorization)

  #Classify stock universe
  stock_universe_m_d_ref <- classify_investment_universe(
    universe_m_d_ref = stock_universe_m_d_ref,
    eligibility_quantile_range = eligibility_quantile_range,
    liquidity_m_d_ref = liquidity_m_d_ref,
    liquidity_constraint_policy = liquidity_constraint_policy,
    liquidity_floor_cutoffs = liquidity_floor_cutoffs_df,
    benchmark_weights_m_d_ref = benchmark_weights_m_d_ref,
    groups_m_d_ref = stock_groups_m_d_ref,
    concentration_constraint_policy = concentration_constraint_policy
  )

  #Test RP
  expected_results <- stock_universe_m_d_ref
  daily_stock_returns_m_xts_upd_ref <- daily_stock_returns_m_xts[which(zoo::index(daily_stock_returns_m_xts) <= current_date),]
  eligible_tickers <- expected_results %>% dplyr::filter(is_eligible == 1) %>% dplyr::pull(tickers)

  covariance_matrix <- estimate_covariance_matrix(tickers = eligible_tickers, returns_m_xts_upd_ref = daily_stock_returns_m_xts_upd_ref,
                                                  cov_matrix_sample_size = cov_matrix_sample_size, cov_estimation_method = cov_estimation_method,
                                                  active_returns = FALSE,
                                                  groups_m_d_ref = stock_groups_m_d_ref
  )

  rp_results <- riskParityPortfolio::riskParityPortfolio(
    Sigma = covariance_matrix,
    mu = stock_universe_m_d_ref %>% dplyr::filter(is_eligible == 1L) %>% dplyr::pull(exp_ret_score),
    lmd_mu = exp_ret_score_tilt_eta
  )

  expected_results[which(expected_results$is_eligible == 1), "rel_risk_contr"] <-
    rp_results$relative_risk_contribution[expected_results[which(expected_results$is_eligible == 1), "tickers"]] #Fill only eligibles

  expected_results[which(expected_results$is_eligible == 1), "weights"] <-
    rp_results$w[expected_results[which(expected_results$is_eligible == 1), "tickers"]] #Fill only eligibles

  expected_results$rel_risk_contr[which(is.na(expected_results$rel_risk_contr))] <- 0
  expected_results$weights[which(is.na(expected_results$weights))] <- 0

  results <- set_portfolio_weights(universe_m_d_ref = stock_universe_m_d_ref, port_construction_method = "rp",
                                     eligible_returns_m_xts_upd_ref = daily_stock_returns_m_xts_upd_ref, groups_m_d_ref = stock_groups_m_d_ref,
                                     cov_matrix_sample_size = cov_matrix_sample_size, cov_estimation_method = cov_estimation_method,
                                     exp_ret_score_tilt = exp_ret_score_tilt, exp_ret_score_tilt_eta = exp_ret_score_tilt_eta,
                                     active_returns = FALSE
    )


  expect_equal(results@universe_m_d_ref@data, expected_results)

  #Test that tilt worked (weights should not be equal to pure RP)
  vanilla_rp <- set_portfolio_weights(universe_m_d_ref = stock_universe_m_d_ref, port_construction_method = "rp",
                                      eligible_returns_m_xts_upd_ref = daily_stock_returns_m_xts_upd_ref, groups_m_d_ref = stock_groups_m_d_ref,
                                      cov_matrix_sample_size = cov_matrix_sample_size, cov_estimation_method = cov_estimation_method,
                                      active_returns = FALSE)@universe_m_d_ref@data
  expect_false(
    identical(results@universe_m_d_ref@data$weights,
              vanilla_rp$weights
              )
    )

  #Test that in relation to vanilla RP, high expected return stocks have a higher weight
  combined <- results@universe_m_d_ref@data %>%
    dplyr::select(tickers, weights) %>%
    dplyr::rename(weights_tilted = weights) %>%
    dplyr::left_join(
      vanilla_rp %>%
        dplyr::select(tickers, weights) %>%
        dplyr::rename(weights_vanilla = weights),
      by = "tickers"
    ) %>%
    dplyr::left_join(
      stock_universe_m_d_ref %>%
        dplyr::select(tickers, exp_ret_score),
      by = "tickers"
    ) %>%
    dplyr::mutate(weight_diff = weights_tilted - weights_vanilla)

  # In the top 10 exp_ret_score stocks, at least 8 should have a positive weight difference
  top_10 <- combined %>%
    dplyr::filter(weights_tilted > 0) %>%
    dplyr::filter(weights_vanilla > 0) %>%
    dplyr::slice_max(order_by = exp_ret_score, n = 10)

  expect_gte(sum(top_10$weight_diff > 0), 8)

  # Test that relative risk contribution is not equal across tilted version
  expect_true(
    sd(results@universe_m_d_ref@data$rel_risk_contr[results@universe_m_d_ref@data$is_eligible == 1]) >
    sd(vanilla_rp$rel_risk_contr[vanilla_rp$is_eligible == 1])
  )


})

test_that("set portfolio weights works for stocks (rp + exp_ret_score_tilt = 'final') - toy_preprocessed", {

  #Create signals_m_d_ref
  load(paste(test_path(),"/testdata/","toy_preprocessed_port_obj.RData", sep =""))

  #Quantile Range and others
  eligibility_quantile_range <- c(0.67, 1)
  chosen_score_metric_and_position <- c(vol_36m = "short")
  cov_matrix_sample_size <- 60
  cov_estimation_method <- "cc"
  exp_ret_score_tilt <- "final"
  exp_ret_score_tilt_eta <- 0.5

  #Check
  check_inputs_port_backtest(signals_m_df = signals_m_df, oos_predictions_m_df = NULL, chosen_score_metric_and_position = chosen_score_metric_and_position,
                             rebalancing_months = 6, initial_buffer_period = 6, port_construction_method = "rp",
                             eligibility_quantile_range = eligibility_quantile_range, selected_benchmark = "ibov",
                             min_eligible_assets_fallback = NULL, scaler_m_df = NULL, chosen_scaler = NULL, scaler_shrinkage = NULL,
                             use_raw_for_eligibility = NULL, exp_ret_score_tilt = exp_ret_score_tilt,
                             exp_ret_score_tilt_eta = exp_ret_score_tilt_eta,
                             macro_concentration_constraint_policy = NULL, macro_ridge_pen = NULL,
                             micro_port_construction_method = NULL, macro_port_construction_method = NULL,
                             rp_method = NULL, n_random_ports = NULL, random_ports_method = NULL, opt_objective = NULL, opt_method = NULL,
                             cov_estimation_method = cov_estimation_method, cov_matrix_sample_size = cov_matrix_sample_size, active_returns = FALSE, cov_matrix_benchmark = NULL,
                             daily_stock_returns_m_xts = daily_stock_returns_m_xts, daily_bench_returns_m_xts = NULL, benchmark_returns_m_xts = benchmark_returns_m_xts,
                             liquidity_constraint_policy = NULL, turnover_constraint_policy = NULL, concentration_constraint_policy = NULL,
                             liquidity_m_df = liquidity_m_df, liquidity_floor_cutoffs = liquidity_floor_cutoffs_df, main_liquidity_metric = "mean_volfin_3m",
                             stock_groups_m_df = stock_groups_m_df, benchmark_weights_m_df = benchmark_weights_m_df, volatility_m_df = volatility_m_df,
                             fwd_return_m_df = fwd_return_m_df, transaction_costs_parameters = transaction_costs_list, ridge_pen = NULL,
                             custom_stock_weights_m_df = NULL, custom_stock_metrics_m_df = NULL, user_defined_OR_rules_m_df = NULL, user_defined_AND_rules_m_df = NULL,
                             upper_quantile_winsorization = 0.95, lower_quantile_winsorization = 0.05, verbose = TRUE
  )

  #Current date
  current_date <- "2023-04-15"

  #Initial Preps
  signals_m_d_ref <- signals_m_df %>% dplyr::filter(dates == current_date)
  liquidity_m_d_ref <- liquidity_m_df %>% dplyr::filter(dates == current_date)
  benchmark_weights_m_d_ref <- benchmark_weights_m_df %>% dplyr::filter(dates == current_date)
  stock_groups_m_d_ref <- stock_groups_m_df %>% dplyr::filter(dates == current_date)

  #Derive Stock Universe
  stock_universe_m_d_ref <- derive_stock_universe_m_d_ref(signals_m_d_ref = signals_m_d_ref,
                                                          chosen_score_metric_and_position = c(vol_36m = "short"),
                                                          upper_quantile_winsorization = upper_quantile_winsorization,
                                                          lower_quantile_winsorization = lower_quantile_winsorization)

  #Classify stock universe
  stock_universe_m_d_ref <- classify_investment_universe(
    universe_m_d_ref = stock_universe_m_d_ref,
    eligibility_quantile_range = eligibility_quantile_range,
    liquidity_m_d_ref = liquidity_m_d_ref,
    liquidity_constraint_policy = liquidity_constraint_policy,
    liquidity_floor_cutoffs = liquidity_floor_cutoffs_df,
    benchmark_weights_m_d_ref = benchmark_weights_m_d_ref,
    groups_m_d_ref = stock_groups_m_d_ref,
    concentration_constraint_policy = concentration_constraint_policy
  )

  #Test RP
  expected_results <- stock_universe_m_d_ref
  daily_stock_returns_m_xts_upd_ref <- daily_stock_returns_m_xts[which(zoo::index(daily_stock_returns_m_xts) <= current_date),]
  eligible_tickers <- expected_results %>% dplyr::filter(is_eligible == 1) %>% dplyr::pull(tickers)

  covariance_matrix <- estimate_covariance_matrix(tickers = eligible_tickers, returns_m_xts_upd_ref = daily_stock_returns_m_xts_upd_ref,
                                                  cov_matrix_sample_size = cov_matrix_sample_size, cov_estimation_method = cov_estimation_method,
                                                  active_returns = FALSE,
                                                  groups_m_d_ref = stock_groups_m_d_ref
  )

  rp_results <- riskParityPortfolio::riskParityPortfolio(Sigma = covariance_matrix)

  expected_results[which(expected_results$is_eligible == 1), "rel_risk_contr"] <-
    rp_results$relative_risk_contribution[expected_results[which(expected_results$is_eligible == 1), "tickers"]] #Fill only eligibles

  expected_results[which(expected_results$is_eligible == 1), "weights"] <-
    rp_results$w[expected_results[which(expected_results$is_eligible == 1), "tickers"]] #Fill only eligibles

  expected_results$rel_risk_contr[which(is.na(expected_results$rel_risk_contr))] <- 0
  expected_results$weights[which(is.na(expected_results$weights))] <- 0

  ## Apply final tilt
  expected_results$weights <- expected_results$weights * (expected_results$exp_ret_score ^ exp_ret_score_tilt_eta)
  expected_results$weights <- expected_results$weights / sum(expected_results$weights)

  ##Recalculate rel risk contribution
  rel_risk_contr <-  relative_risk_contribution(
    weights = expected_results %>% dplyr::filter(is_eligible == 1L) %>% dplyr::pull(weights),
    covariance_matrix
  )
  expected_results$rel_risk_contr <- NULL
  expected_results <- expected_results %>% dplyr::left_join(rel_risk_contr, by = "tickers")
  expected_results$rel_risk_contr[which(is.na(expected_results$rel_risk_contr))] <- 0
  expected_results <- expected_results %>% dplyr::relocate(rel_risk_contr, .before = weights)


  results <- set_portfolio_weights(universe_m_d_ref = stock_universe_m_d_ref, port_construction_method = "rp",
                                   eligible_returns_m_xts_upd_ref = daily_stock_returns_m_xts_upd_ref, groups_m_d_ref = stock_groups_m_d_ref,
                                   cov_matrix_sample_size = cov_matrix_sample_size, cov_estimation_method = cov_estimation_method,
                                   exp_ret_score_tilt = exp_ret_score_tilt, exp_ret_score_tilt_eta = exp_ret_score_tilt_eta,
                                   active_returns = FALSE
  )


  expect_equal(results@universe_m_d_ref@data, expected_results)

  #Test that tilt worked (weights should not be equal to pure RP)
  vanilla_rp <- set_portfolio_weights(universe_m_d_ref = stock_universe_m_d_ref, port_construction_method = "rp",
                                      eligible_returns_m_xts_upd_ref = daily_stock_returns_m_xts_upd_ref, groups_m_d_ref = stock_groups_m_d_ref,
                                      cov_matrix_sample_size = cov_matrix_sample_size, cov_estimation_method = cov_estimation_method,
                                      active_returns = FALSE)@universe_m_d_ref@data
  expect_false(
    identical(results@universe_m_d_ref@data$weights,
              vanilla_rp$weights
    )
  )

  #Test that in relation to vanilla RP, high expected return stocks have a higher weight
  combined <- results@universe_m_d_ref@data %>%
    dplyr::select(tickers, weights) %>%
    dplyr::rename(weights_tilted = weights) %>%
    dplyr::left_join(
      vanilla_rp %>%
        dplyr::select(tickers, weights) %>%
        dplyr::rename(weights_vanilla = weights),
      by = "tickers"
    ) %>%
    dplyr::left_join(
      stock_universe_m_d_ref %>%
        dplyr::select(tickers, exp_ret_score),
      by = "tickers"
    ) %>%
    dplyr::mutate(weight_diff = weights_tilted - weights_vanilla)

  # In the top 10 exp_ret_score stocks, at least 8 should have a positive weight difference
  top_10 <- combined %>%
    dplyr::filter(weights_tilted > 0) %>%
    dplyr::filter(weights_vanilla > 0) %>%
    dplyr::slice_max(order_by = exp_ret_score, n = 10)

  expect_gte(sum(top_10$weight_diff > 0), 8)

  # Test that relative risk contribution is not equal across tilted version
  expect_true(
    sd(results@universe_m_d_ref@data$rel_risk_contr[results@universe_m_d_ref@data$is_eligible == 1]) >
      sd(vanilla_rp$rel_risk_contr[vanilla_rp$is_eligible == 1])
  )



})

test_that("set portfolio weights works for stocks (hrp and hrp + exp_ret_score_tilt = 'final') - toy_preprocessed", {

  #Create signals_m_d_ref
  load(paste(test_path(),"/testdata/","toy_preprocessed_port_obj.RData", sep =""))

  #Quantile Range and others
  eligibility_quantile_range <- c(0.67, 1)
  chosen_score_metric_and_position <- c(vol_36m = "short")
  cov_matrix_sample_size <- 60
  cov_estimation_method <- "cc"
  exp_ret_score_tilt <- "final"
  exp_ret_score_tilt_eta <- 0.5

  #Check
  check_inputs_port_backtest(signals_m_df = signals_m_df, oos_predictions_m_df = NULL, chosen_score_metric_and_position = chosen_score_metric_and_position,
                             rebalancing_months = 6, initial_buffer_period = 6, port_construction_method = "rp",
                             eligibility_quantile_range = eligibility_quantile_range, selected_benchmark = "ibov",
                             min_eligible_assets_fallback = NULL, scaler_m_df = NULL, chosen_scaler = NULL, scaler_shrinkage = NULL,
                             use_raw_for_eligibility = NULL, exp_ret_score_tilt = exp_ret_score_tilt,
                             exp_ret_score_tilt_eta = exp_ret_score_tilt_eta,
                             macro_concentration_constraint_policy = NULL, macro_ridge_pen = NULL,
                             micro_port_construction_method = NULL, macro_port_construction_method = NULL,
                             rp_method = NULL, n_random_ports = NULL, random_ports_method = NULL, opt_objective = NULL, opt_method = NULL,
                             cov_estimation_method = cov_estimation_method, cov_matrix_sample_size = cov_matrix_sample_size, active_returns = FALSE, cov_matrix_benchmark = NULL,
                             daily_stock_returns_m_xts = daily_stock_returns_m_xts, daily_bench_returns_m_xts = NULL, benchmark_returns_m_xts = benchmark_returns_m_xts,
                             liquidity_constraint_policy = NULL, turnover_constraint_policy = NULL, concentration_constraint_policy = NULL,
                             liquidity_m_df = liquidity_m_df, liquidity_floor_cutoffs = liquidity_floor_cutoffs_df, main_liquidity_metric = "mean_volfin_3m",
                             stock_groups_m_df = stock_groups_m_df, benchmark_weights_m_df = benchmark_weights_m_df, volatility_m_df = volatility_m_df,
                             fwd_return_m_df = fwd_return_m_df, transaction_costs_parameters = transaction_costs_list, ridge_pen = NULL,
                             custom_stock_weights_m_df = NULL, custom_stock_metrics_m_df = NULL, user_defined_OR_rules_m_df = NULL, user_defined_AND_rules_m_df = NULL,
                             upper_quantile_winsorization = 0.95, lower_quantile_winsorization = 0.05, verbose = TRUE
  )

  #Current date
  current_date <- "2023-04-15"

  #Initial Preps
  signals_m_d_ref <- signals_m_df %>% dplyr::filter(dates == current_date)
  liquidity_m_d_ref <- liquidity_m_df %>% dplyr::filter(dates == current_date)
  benchmark_weights_m_d_ref <- benchmark_weights_m_df %>% dplyr::filter(dates == current_date)
  stock_groups_m_d_ref <- stock_groups_m_df %>% dplyr::filter(dates == current_date)

  #Derive Stock Universe
  stock_universe_m_d_ref <- derive_stock_universe_m_d_ref(signals_m_d_ref = signals_m_d_ref,
                                                          chosen_score_metric_and_position = c(vol_36m = "short"),
                                                          upper_quantile_winsorization = upper_quantile_winsorization,
                                                          lower_quantile_winsorization = lower_quantile_winsorization)

  #Classify stock universe
  stock_universe_m_d_ref <- classify_investment_universe(
    universe_m_d_ref = stock_universe_m_d_ref,
    eligibility_quantile_range = eligibility_quantile_range,
    liquidity_m_d_ref = liquidity_m_d_ref,
    liquidity_constraint_policy = liquidity_constraint_policy,
    liquidity_floor_cutoffs = liquidity_floor_cutoffs_df,
    benchmark_weights_m_d_ref = benchmark_weights_m_d_ref,
    groups_m_d_ref = stock_groups_m_d_ref,
    concentration_constraint_policy = concentration_constraint_policy
  )

  #Test HRP
  expected_results <- stock_universe_m_d_ref
  daily_stock_returns_m_xts_upd_ref <- daily_stock_returns_m_xts[which(zoo::index(daily_stock_returns_m_xts) <= current_date),]
  eligible_tickers <- expected_results %>% dplyr::filter(is_eligible == 1) %>% dplyr::pull(tickers)

  covariance_matrix <- estimate_covariance_matrix(tickers = eligible_tickers, returns_m_xts_upd_ref = daily_stock_returns_m_xts_upd_ref,
                                                  cov_matrix_sample_size = cov_matrix_sample_size, cov_estimation_method = cov_estimation_method,
                                                  active_returns = FALSE,
                                                  groups_m_d_ref = stock_groups_m_d_ref
  )


  correlation <- stats::cov2cor(covariance_matrix)
  distance <- stats::dist(sqrt(0.5 * (1 - correlation)), method = "euclidean", diag = TRUE, upper = TRUE, p = 2)
  clusters <- stats::hclust(distance , method = "complete", members = NULL)
  clusters_order <- clusters$order

  weights <- rep(1,ncol(covariance_matrix))
  index <- list(clusters_order)

  while (length(index) > 0) {
    index_recreated <- list()
    for (i in index) {
      ### Bisection
      middle <- floor(length(i)/2)
      indexL <- i[1:middle]
      indexR <- i[-c(1:middle)]
      covL <- as.matrix(covariance_matrix[indexL, indexL])
      covR <- as.matrix(covariance_matrix[indexR, indexR])

      ### Calculate weights
      w_L <- 1/diag(covL) / sum(1/diag(covL))
      w_R <- 1/diag(covR) / sum(1/diag(covR))

      ### Variance
      v_L <- as.numeric(t(w_L) %*% covL %*% w_L)
      v_R <- as.numeric(t(w_R) %*% covR %*% w_R)

      ### Alpha
      alpha <- as.numeric(1 - v_L/(v_L + v_R))

      ### Update weights
      weights[indexL] <- weights[indexL] * alpha
      weights[indexR] <- weights[indexR] * (1 - alpha)

      ### Recreate index
      if (length(indexL) > 1) index_recreated <- c(index_recreated, list(indexL))
      if (length(indexR) > 1) index_recreated <- c(index_recreated, list(indexR))
      index = index_recreated
    }
  }

  # Pass pass weights
  names(weights) <- colnames(covariance_matrix)

  expected_results <- expected_results %>%
    dplyr::left_join(
      data.frame(
        tickers = names(weights),
        weights = weights
      ),
      by = "tickers"
    )
  expected_results[which(is.na(expected_results$weights)), "weights"] <- 0

  ## Apply final tilt
  expected_results$weights <- expected_results$weights * (expected_results$exp_ret_score ^ exp_ret_score_tilt_eta)
  expected_results$weights <- expected_results$weights / sum(expected_results$weights)

  ## Recalculare RRC
  rel_risk_contr <-  relative_risk_contribution(
    weights = expected_results %>% dplyr::filter(is_eligible == 1L) %>% dplyr::pull(weights),
    covariance_matrix
  )

  expected_results <- expected_results %>%
    dplyr::left_join(rel_risk_contr, by = "tickers")
  expected_results[which(is.na(expected_results$rel_risk_contr)), "rel_risk_contr"] <- 0

  ## Relocate
  expected_results <- expected_results %>% dplyr::relocate(rel_risk_contr, .before = weights)


  results <- set_portfolio_weights(universe_m_d_ref = stock_universe_m_d_ref, port_construction_method = "hrp",
                                   eligible_returns_m_xts_upd_ref = daily_stock_returns_m_xts_upd_ref, groups_m_d_ref = stock_groups_m_d_ref,
                                   cov_matrix_sample_size = cov_matrix_sample_size, cov_estimation_method = cov_estimation_method,
                                   exp_ret_score_tilt = "final", exp_ret_score_tilt_eta = exp_ret_score_tilt_eta,
                                   active_returns = FALSE
  )
  expect_equal(results@universe_m_d_ref@data, expected_results)

  #Test that tilt worked (weights should not be equal to pure HRP)
  vanilla_hrp <- set_portfolio_weights(universe_m_d_ref = stock_universe_m_d_ref, port_construction_method = "hrp",
                                      eligible_returns_m_xts_upd_ref = daily_stock_returns_m_xts_upd_ref, groups_m_d_ref = stock_groups_m_d_ref,
                                      cov_matrix_sample_size = cov_matrix_sample_size, cov_estimation_method = cov_estimation_method,
                                      active_returns = FALSE)@universe_m_d_ref@data
  expect_false(
    identical(results@universe_m_d_ref@data$weights,
              vanilla_hrp$weights
    )
  )

  expect_equal(
    weights,
    vanilla_hrp$weights[match(names(weights), vanilla_hrp$tickers)] %>%
      setNames(names(weights))
  )

  #Test that in relation to vanilla HRP, high expected return stocks have a higher weight
  combined <- results@universe_m_d_ref@data %>%
    dplyr::select(tickers, weights) %>%
    dplyr::rename(weights_tilted = weights) %>%
    dplyr::left_join(
      vanilla_hrp %>%
        dplyr::select(tickers, weights) %>%
        dplyr::rename(weights_vanilla = weights),
      by = "tickers"
    ) %>%
    dplyr::left_join(
      stock_universe_m_d_ref %>%
        dplyr::select(tickers, exp_ret_score),
      by = "tickers"
    ) %>%
    dplyr::mutate(weight_diff = weights_tilted - weights_vanilla)

  # In the top 10 exp_ret_score stocks, at least 8 should have a positive weight difference
  top_10 <- combined %>%
    dplyr::filter(weights_tilted > 0) %>%
    dplyr::filter(weights_vanilla > 0) %>%
    dplyr::slice_max(order_by = exp_ret_score, n = 10)

  expect_gte(sum(top_10$weight_diff > 0), 8)

  # In the bottom 10 exp_ret_score stocks, at least 8 should have a negative weight difference
  bottom_10 <- combined %>%
    dplyr::filter(weights_tilted > 0) %>%
    dplyr::filter(weights_vanilla > 0) %>%
    dplyr::slice_min(order_by = exp_ret_score, n = 10)

  expect_gte(sum(bottom_10$weight_diff < 0), 8)


})

test_that("set portfolio weights works for stocks (hrp + exp_ret_score_tilt = 'inner') - toy_preprocessed", {

  #Create signals_m_d_ref
  load(paste(test_path(),"/testdata/","toy_preprocessed_port_obj.RData", sep =""))

  #Quantile Range and others
  eligibility_quantile_range <- c(0.67, 1)
  chosen_score_metric_and_position <- c(vol_36m = "short")
  cov_matrix_sample_size <- 60
  cov_estimation_method <- "cc"
  exp_ret_score_tilt <- "final"
  exp_ret_score_tilt_eta <- 0.5

  #Check
  check_inputs_port_backtest(signals_m_df = signals_m_df, oos_predictions_m_df = NULL, chosen_score_metric_and_position = chosen_score_metric_and_position,
                             rebalancing_months = 6, initial_buffer_period = 6, port_construction_method = "rp",
                             eligibility_quantile_range = eligibility_quantile_range, selected_benchmark = "ibov",
                             min_eligible_assets_fallback = NULL, scaler_m_df = NULL, chosen_scaler = NULL, scaler_shrinkage = NULL,
                             use_raw_for_eligibility = NULL, exp_ret_score_tilt = exp_ret_score_tilt,
                             exp_ret_score_tilt_eta = exp_ret_score_tilt_eta,
                             macro_concentration_constraint_policy = NULL, macro_ridge_pen = NULL,
                             micro_port_construction_method = NULL, macro_port_construction_method = NULL,
                             rp_method = NULL, n_random_ports = NULL, random_ports_method = NULL, opt_objective = NULL, opt_method = NULL,
                             cov_estimation_method = cov_estimation_method, cov_matrix_sample_size = cov_matrix_sample_size, active_returns = FALSE, cov_matrix_benchmark = NULL,
                             daily_stock_returns_m_xts = daily_stock_returns_m_xts, daily_bench_returns_m_xts = NULL, benchmark_returns_m_xts = benchmark_returns_m_xts,
                             liquidity_constraint_policy = NULL, turnover_constraint_policy = NULL, concentration_constraint_policy = NULL,
                             liquidity_m_df = liquidity_m_df, liquidity_floor_cutoffs = liquidity_floor_cutoffs_df, main_liquidity_metric = "mean_volfin_3m",
                             stock_groups_m_df = stock_groups_m_df, benchmark_weights_m_df = benchmark_weights_m_df, volatility_m_df = volatility_m_df,
                             fwd_return_m_df = fwd_return_m_df, transaction_costs_parameters = transaction_costs_list, ridge_pen = NULL,
                             custom_stock_weights_m_df = NULL, custom_stock_metrics_m_df = NULL, user_defined_OR_rules_m_df = NULL, user_defined_AND_rules_m_df = NULL,
                             upper_quantile_winsorization = 0.95, lower_quantile_winsorization = 0.05, verbose = TRUE
  )

  #Current date
  current_date <- "2023-04-15"

  #Initial Preps
  signals_m_d_ref <- signals_m_df %>% dplyr::filter(dates == current_date)
  liquidity_m_d_ref <- liquidity_m_df %>% dplyr::filter(dates == current_date)
  benchmark_weights_m_d_ref <- benchmark_weights_m_df %>% dplyr::filter(dates == current_date)
  stock_groups_m_d_ref <- stock_groups_m_df %>% dplyr::filter(dates == current_date)

  #Derive Stock Universe
  stock_universe_m_d_ref <- derive_stock_universe_m_d_ref(signals_m_d_ref = signals_m_d_ref,
                                                          chosen_score_metric_and_position = c(vol_36m = "short"),
                                                          upper_quantile_winsorization = upper_quantile_winsorization,
                                                          lower_quantile_winsorization = lower_quantile_winsorization)

  #Classify stock universe
  stock_universe_m_d_ref <- classify_investment_universe(
    universe_m_d_ref = stock_universe_m_d_ref,
    eligibility_quantile_range = eligibility_quantile_range,
    liquidity_m_d_ref = liquidity_m_d_ref,
    liquidity_constraint_policy = liquidity_constraint_policy,
    liquidity_floor_cutoffs = liquidity_floor_cutoffs_df,
    benchmark_weights_m_d_ref = benchmark_weights_m_d_ref,
    groups_m_d_ref = stock_groups_m_d_ref,
    concentration_constraint_policy = concentration_constraint_policy
  )

  #Test HRP
  expected_results <- stock_universe_m_d_ref
  daily_stock_returns_m_xts_upd_ref <- daily_stock_returns_m_xts[which(zoo::index(daily_stock_returns_m_xts) <= current_date),]
  eligible_tickers <- expected_results %>% dplyr::filter(is_eligible == 1) %>% dplyr::pull(tickers)

  covariance_matrix <- estimate_covariance_matrix(tickers = eligible_tickers, returns_m_xts_upd_ref = daily_stock_returns_m_xts_upd_ref,
                                                  cov_matrix_sample_size = cov_matrix_sample_size, cov_estimation_method = cov_estimation_method,
                                                  active_returns = FALSE,
                                                  groups_m_d_ref = stock_groups_m_d_ref
  )


  correlation <- stats::cov2cor(covariance_matrix)
  distance <- stats::as.dist(sqrt(0.5 * (1 - correlation)))
  clusters <- stats::hclust(distance , method = "complete")
  clusters_order <- clusters$order

  weights <- rep(1,ncol(covariance_matrix))
  index <- list(clusters_order)

  while (length(index) > 0) {
    index_recreated <- list()
    for (i in index) {
      if (length(i) <= 1L) next
      ### Bisection
      middle <- floor(length(i)/2)
      indexL <- i[1:middle]
      indexR <- i[-c(1:middle)]
      covL <- as.matrix(covariance_matrix[indexL, indexL, drop = FALSE])
      covR <- as.matrix(covariance_matrix[indexR, indexR, drop = FALSE])

      ### Calculate weights
      w_L <- 1 / diag(covL); w_L <- w_L / sum(w_L)
      w_R <- 1 / diag(covR); w_R <- w_R / sum(w_R)

      ### Variance
      v_L <- as.numeric(t(w_L) %*% covL %*% w_L)
      v_R <- as.numeric(t(w_R) %*% covR %*% w_R)

      ### Mu
      mu_L <- as.numeric(sum(w_L * expected_results$exp_ret_score[
        match(rownames(covL), expected_results$tickers)
      ]))
      mu_R <- as.numeric(sum(w_R * expected_results$exp_ret_score[
        match(rownames(covR), expected_results$tickers)
      ]))

      ### Rank
      r <- rank(c(mu_L, mu_R), ties.method = "average")
      gL <- r[1]/2
      gR <- r[2]/2

      ### Allocated
      A_L <- (1/v_L)*(gL^exp_ret_score_tilt_eta)
      A_R <- (1/v_R)*(gR^exp_ret_score_tilt_eta)

      ### Alpha
      alpha <- A_L / (A_L + A_R)

      ### Update weights
      weights[indexL] <- weights[indexL] * alpha
      weights[indexR] <- weights[indexR] * (1 - alpha)

      ### Recreate index
      if (length(indexL) > 1) index_recreated <- c(index_recreated, list(indexL))
      if (length(indexR) > 1) index_recreated <- c(index_recreated, list(indexR))

    }
    index <- index_recreated
  }

  # Pass pass weights
  names(weights) <- colnames(covariance_matrix)

  expected_results <- expected_results %>%
    dplyr::left_join(
      data.frame(
        tickers = names(weights),
        weights = weights
      ),
      by = "tickers"
    )
  expected_results[which(is.na(expected_results$weights)), "weights"] <- 0


  ## Recalculare RRC
  rel_risk_contr <-  relative_risk_contribution(
    weights = expected_results %>% dplyr::filter(is_eligible == 1L) %>% dplyr::pull(weights),
    covariance_matrix
  )

  expected_results <- expected_results %>%
    dplyr::left_join(rel_risk_contr, by = "tickers")
  expected_results[which(is.na(expected_results$rel_risk_contr)), "rel_risk_contr"] <- 0


  ## Relocate
  expected_results <- expected_results %>% dplyr::relocate(rel_risk_contr, .before = weights)


  results <- set_portfolio_weights(universe_m_d_ref = stock_universe_m_d_ref, port_construction_method = "hrp",
                                   eligible_returns_m_xts_upd_ref = daily_stock_returns_m_xts_upd_ref, groups_m_d_ref = stock_groups_m_d_ref,
                                   cov_matrix_sample_size = cov_matrix_sample_size, cov_estimation_method = cov_estimation_method,
                                   exp_ret_score_tilt = "inner", exp_ret_score_tilt_eta = exp_ret_score_tilt_eta,
                                   linkage = "complete",
                                   active_returns = FALSE
  )
  expect_equal(results@universe_m_d_ref@data, expected_results)

  #Test that tilt worked (weights should not be equal to pure HRP)
  vanilla_hrp <- set_portfolio_weights(universe_m_d_ref = stock_universe_m_d_ref, port_construction_method = "hrp",
                                       eligible_returns_m_xts_upd_ref = daily_stock_returns_m_xts_upd_ref, groups_m_d_ref = stock_groups_m_d_ref,
                                       cov_matrix_sample_size = cov_matrix_sample_size, cov_estimation_method = cov_estimation_method,
                                       active_returns = FALSE)@universe_m_d_ref@data
  expect_false(
    identical(results@universe_m_d_ref@data$weights,
              vanilla_hrp$weights
    )
  )


  #Test that in relation to vanilla HRP, high expected return stocks have a higher weight
  combined <- results@universe_m_d_ref@data %>%
    dplyr::select(tickers, weights) %>%
    dplyr::rename(weights_tilted = weights) %>%
    dplyr::left_join(
      vanilla_hrp %>%
        dplyr::select(tickers, weights) %>%
        dplyr::rename(weights_vanilla = weights),
      by = "tickers"
    ) %>%
    dplyr::left_join(
      stock_universe_m_d_ref %>%
        dplyr::select(tickers, exp_ret_score),
      by = "tickers"
    ) %>%
    dplyr::mutate(weight_diff = weights_tilted - weights_vanilla)

  # In the top 10 exp_ret_score stocks, at least 8 should have a positive weight difference
  top_10 <- combined %>%
    dplyr::filter(weights_tilted > 0) %>%
    dplyr::filter(weights_vanilla > 0) %>%
    dplyr::slice_max(order_by = exp_ret_score, n = 10)

  expect_gte(sum(top_10$weight_diff > 0), 8)

  # In the bottom 10 exp_ret_score stocks, at least 8 should have a negative weight difference
  bottom_10 <- combined %>%
    dplyr::filter(weights_tilted > 0) %>%
    dplyr::filter(weights_vanilla > 0) %>%
    dplyr::slice_min(order_by = exp_ret_score, n = 10)

  expect_gte(sum(bottom_10$weight_diff < 0), 8)


})

test_that("set portfolio weights works for stocks (mvo_unc) - toy_preprocessed", {

  #Create signals_m_d_ref
  load(paste(test_path(),"/testdata/","toy_preprocessed_port_obj.RData", sep =""))

  #Quantile Range and others
  eligibility_quantile_range <- c(0.67, 1)
  chosen_score_metric_and_position <- c(vol_36m = "short")
  cov_matrix_sample_size <- 60
  cov_estimation_method <- "cc"

  #Check
  check_inputs_port_backtest(signals_m_df = signals_m_df, oos_predictions_m_df = NULL, chosen_score_metric_and_position = chosen_score_metric_and_position,
                             rebalancing_months = 6, initial_buffer_period = 6, port_construction_method = "mvo",
                             eligibility_quantile_range = eligibility_quantile_range, selected_benchmark = "ibov",
                             min_eligible_assets_fallback = NULL, scaler_m_df = NULL, chosen_scaler = NULL, scaler_shrinkage = NULL,
                             use_raw_for_eligibility = NULL, exp_ret_score_tilt = NULL, exp_ret_score_tilt_eta = NULL,
                             rp_method = NULL, n_random_ports = 2000, random_ports_method = "sample", opt_objective = "return", opt_method = NULL,
                             n_resamples = 0, exp_ret_score_jitter = 0, cov_eigval_jitter = 0,
                             macro_concentration_constraint_policy = NULL, macro_ridge_pen = NULL,
                             micro_port_construction_method = NULL, macro_port_construction_method = NULL,
                             cov_estimation_method = cov_estimation_method, cov_matrix_sample_size = cov_matrix_sample_size, active_returns = FALSE, cov_matrix_benchmark = NULL,
                             daily_stock_returns_m_xts = daily_stock_returns_m_xts, daily_bench_returns_m_xts = NULL, benchmark_returns_m_xts = benchmark_returns_m_xts,
                             liquidity_constraint_policy = NULL, turnover_constraint_policy = NULL, concentration_constraint_policy = NULL,
                             liquidity_m_df = liquidity_m_df, liquidity_floor_cutoffs = liquidity_floor_cutoffs_df, main_liquidity_metric = "mean_volfin_3m",
                             stock_groups_m_df = stock_groups_m_df, benchmark_weights_m_df = benchmark_weights_m_df, volatility_m_df = volatility_m_df,
                             fwd_return_m_df = fwd_return_m_df, transaction_costs_parameters = transaction_costs_list, ridge_pen = NULL,
                             custom_stock_weights_m_df = NULL, custom_stock_metrics_m_df = NULL, user_defined_OR_rules_m_df = NULL, user_defined_AND_rules_m_df = NULL,
                             upper_quantile_winsorization = 0.95, lower_quantile_winsorization = 0.05, verbose = TRUE
  )


  #Current date
  current_date <- "2023-04-15"

  #Initial Preps
  signals_m_d_ref <- signals_m_df %>% dplyr::filter(dates == current_date)
  liquidity_m_d_ref <- liquidity_m_df %>% dplyr::filter(dates == current_date)
  benchmark_weights_m_d_ref <- benchmark_weights_m_df %>% dplyr::filter(dates == current_date)
  stock_groups_m_d_ref <- stock_groups_m_df %>% dplyr::filter(dates == current_date)

  #Derive Stock Universe
  stock_universe_m_d_ref <- derive_stock_universe_m_d_ref(signals_m_d_ref = signals_m_d_ref, chosen_score_metric_and_position = c(vol_36m = "short"),
                                                          upper_quantile_winsorization = upper_quantile_winsorization,
                                                          lower_quantile_winsorization = lower_quantile_winsorization)

  #Classify stock universe
  stock_universe_m_d_ref <- classify_investment_universe(
    universe_m_d_ref = stock_universe_m_d_ref,
    eligibility_quantile_range = eligibility_quantile_range,
    liquidity_m_d_ref = liquidity_m_d_ref,
    liquidity_constraint_policy = liquidity_constraint_policy,
    liquidity_floor_cutoffs = liquidity_floor_cutoffs_df,
    benchmark_weights_m_d_ref = benchmark_weights_m_d_ref,
    groups_m_d_ref = stock_groups_m_d_ref,
    concentration_constraint_policy = concentration_constraint_policy
  )

  #Test MVO Unconstrained
  expected_results <- stock_universe_m_d_ref
  daily_stock_returns_m_xts_upd_ref <- daily_stock_returns_m_xts[which(zoo::index(daily_stock_returns_m_xts) <= current_date),]
  eligible_tickers <- expected_results %>% dplyr::filter(is_eligible == 1) %>% dplyr::pull(tickers)

  covariance_matrix <- estimate_covariance_matrix(tickers = eligible_tickers, returns_m_xts_upd_ref = daily_stock_returns_m_xts_upd_ref,
                                                  cov_matrix_sample_size = cov_matrix_sample_size, cov_estimation_method = cov_estimation_method,
                                                  active_returns = FALSE,
                                                  groups_m_d_ref = stock_groups_m_d_ref
  )


  #Portfolio
  port_spec <- PortfolioAnalytics::portfolio.spec(assets = eligible_tickers)
  port_spec_constrained <- PortfolioAnalytics::add.constraint(portfolio = port_spec, type = "full_investment")
  port_spec_constrained <- PortfolioAnalytics::add.constraint(portfolio = port_spec, type = "box")

  set.seed(123)
  rp_weights <- PortfolioAnalytics::random_portfolios(portfolio = port_spec_constrained,
                                                      permutations = 2000,
                                                      rp_method = "sample")

  #Best Portfolio for Sharpe
  rp_weights <- as.matrix(rp_weights)  # Portfolio weights
  exp_ret_score <- as.matrix(stock_universe_m_d_ref %>% dplyr::filter(is_eligible == 1) %>% dplyr::pull(exp_ret_score))  # Expected return vector
  cov_matrix <- as.matrix(covariance_matrix)  # Covariance matrix
  # Calculate Portfolio Return (Expected Return)
  portfolio_return <- rp_weights %*% exp_ret_score  # Matrix multiplication
  # Calculate Portfolio Risk (Standard Deviation)
  portfolio_risk <- sqrt(rowSums((rp_weights %*% cov_matrix) * rp_weights))
  # Optimal Sharpe
  optimal_sharpe_weights <- rp_weights[which.max(portfolio_return/portfolio_risk),]
  optimal_ret <-  portfolio_return[which.max(portfolio_return/portfolio_risk),]
  optimal_risk <- portfolio_risk[which.max(portfolio_return/portfolio_risk)]

  set.seed(123)
  results <- set_portfolio_weights(universe_m_d_ref = stock_universe_m_d_ref, port_construction_method = "mvo",
                                   eligible_returns_m_xts_upd_ref = daily_stock_returns_m_xts_upd_ref, groups_m_d_ref = stock_groups_m_d_ref,
                                   cov_matrix_sample_size = cov_matrix_sample_size, cov_estimation_method = cov_estimation_method
  )

  #Check for random weights generation
  expected_weights <- t(rp_weights) %>% as.data.frame() %>% tibble::rownames_to_column("tickers")
  expect_equal(results@random_port_weights, expected_weights)
  expect_equal(results@weights, optimal_sharpe_weights %>% unname())
  expect_equal(1.907, optimal_ret, tolerance = 1e-2)
  expect_equal(0.547, optimal_risk, tolerance = 1e-2)

  #Best Portfolio for Return
  optimal_ret_weights <-  rp_weights[which.max(portfolio_return),]

  set.seed(123)
  expect_warning(
    results <- set_portfolio_weights(universe_m_d_ref = stock_universe_m_d_ref, port_construction_method = "mvo",
                                     eligible_returns_m_xts_upd_ref = daily_stock_returns_m_xts_upd_ref,
                                     groups_m_d_ref = stock_groups_m_d_ref,
                                     cov_matrix_sample_size = cov_matrix_sample_size,
                                     cov_estimation_method = cov_estimation_method,
                                     opt_objective = "return"
    ),"Weights for group 'Consumo Não-Cíclico' sum to zero. Fallback to equal weights."
  )

  expect_equal(results@weights, optimal_ret_weights %>% unname())

  #Best Portfolio for Risk
  optimal_risk_weights <-  rp_weights[which.min(portfolio_risk),]

  set.seed(123)
  results <- set_portfolio_weights(universe_m_d_ref = stock_universe_m_d_ref, port_construction_method = "mvo",
                                   eligible_returns_m_xts_upd_ref = daily_stock_returns_m_xts_upd_ref, groups_m_d_ref = stock_groups_m_d_ref,
                                   cov_matrix_sample_size = cov_matrix_sample_size, cov_estimation_method = cov_estimation_method,
                                   opt_objective = "risk"
  )
  expect_equal(results@weights, optimal_risk_weights %>% unname())
  expected_results[which(expected_results$is_eligible == 1), "rel_risk_contr"] <- relative_risk_contribution(optimal_risk_weights %>% unname(), covariance_matrix)$rel_risk_contr
  expected_results[which(expected_results$is_eligible == 0), "rel_risk_contr"] <- 0

  expected_results[which(expected_results$is_eligible == 1), "weights"] <- optimal_risk_weights
  expected_results[which(expected_results$is_eligible == 0), "weights"] <- 0


  expect_equal(results@universe_m_d_ref@data, expected_results)
  expect_equal(results@universe_m_d_ref@data$weights %>% sum(), 1)


})

test_that("set portfolio weights works for stocks (mvo_con) - toy_preprocessed", {

  #Create signals_m_d_ref
  load(paste(test_path(),"/testdata/","toy_preprocessed_port_obj.RData", sep =""))

  #Quantile Range
  eligibility_quantile_range <- c(0.67, 1)

  #Current date
  current_date <- "2023-04-15"

  #Initial Preps
  signals_m_d_ref <- signals_m_df %>% dplyr::filter(dates == current_date)
  liquidity_m_d_ref <- liquidity_m_df %>% dplyr::filter(dates == current_date)
  benchmark_weights_m_d_ref <- benchmark_weights_m_df %>% dplyr::filter(dates == current_date)
  stock_groups_m_d_ref <- stock_groups_m_df %>% dplyr::filter(dates == current_date)

  #Derive Stock Universe
  stock_universe_m_d_ref <- derive_stock_universe_m_d_ref(signals_m_d_ref = signals_m_d_ref, chosen_score_metric_and_position = c(vol_36m = "short"),
                                                          upper_quantile_winsorization = upper_quantile_winsorization,
                                                          lower_quantile_winsorization = lower_quantile_winsorization)

  #Classify stock universe
  stock_universe_m_d_ref <- classify_investment_universe(
    universe_m_d_ref = stock_universe_m_d_ref,
    eligibility_quantile_range = eligibility_quantile_range,
    liquidity_m_d_ref = liquidity_m_d_ref,
    liquidity_constraint_policy = liquidity_constraint_policy,
    liquidity_floor_cutoffs = liquidity_floor_cutoffs_df,
    benchmark_weights_m_d_ref = benchmark_weights_m_d_ref,
    groups_m_d_ref = stock_groups_m_d_ref,
    concentration_constraint_policy = concentration_constraint_policy
  )

  #Test MVO Constrained
  expected_results <- stock_universe_m_d_ref
  daily_stock_returns_m_xts_upd_ref <- daily_stock_returns_m_xts[which(zoo::index(daily_stock_returns_m_xts) <= current_date),]
  eligible_tickers <- expected_results %>% dplyr::filter(is_eligible == 1) %>% dplyr::pull(tickers)

  covariance_matrix <- estimate_covariance_matrix(tickers = eligible_tickers, returns_m_xts_upd_ref = daily_stock_returns_m_xts_upd_ref,
                                                  cov_matrix_sample_size = 60, cov_estimation_method = "cc",
                                                  active_returns = FALSE,
                                                  groups_m_d_ref = stock_groups_m_d_ref
  )


  #Portfolio
  port_spec <- PortfolioAnalytics::portfolio.spec(assets = eligible_tickers)
  port_spec_constrained <- PortfolioAnalytics::add.constraint(portfolio = port_spec, type = "full_investment")
  port_spec_constrained <- PortfolioAnalytics::add.constraint(portfolio = port_spec, type = "box")

  #Box constraints
  eligible_universe_m_d_ref <- generate_box_constraints(universe_m_d_ref = stock_universe_m_d_ref,
                                                        liquidity_constraint_policy = liquidity_constraint_policy,
                                                        concentration_constraint_policy = concentration_constraint_policy)

  port_spec_constrained <- PortfolioAnalytics::add.constraint(type = "box", portfolio = port_spec_constrained,
                                                              min = eligible_universe_m_d_ref$min_weight,
                                                              max = eligible_universe_m_d_ref$max_weight)

  expected_results[which(expected_results$is_eligible == 1), "max_weight"] <- eligible_universe_m_d_ref$max_weight
  expected_results[which(expected_results$is_eligible == 0), "max_weight"] <- 0

  expected_results[which(expected_results$is_eligible == 1), "min_weight"] <- eligible_universe_m_d_ref$min_weight
  expected_results[which(expected_results$is_eligible == 0), "min_weight"] <- 0


  #Group constraints
  group_constraints_helper <- generate_group_constraints(universe_m_d_ref = stock_universe_m_d_ref, concentration_constraint_policy = concentration_constraint_policy,
                                                         groups_m_d_ref = stock_groups_m_d_ref)

  port_spec_constrained <- PortfolioAnalytics::add.constraint(portfolio = port_spec_constrained,
                                                              type = "group",
                                                              groups = group_constraints_helper$eligible_assets_group_membership_list,
                                                              group_min = group_constraints_helper$group_constraint_min,
                                                              group_max = group_constraints_helper$group_constraint_max
  )

  set.seed(123)
  rp_weights <- PortfolioAnalytics::random_portfolios(portfolio = port_spec_constrained,
                                                      permutations = 2000,
                                                      rp_method = "sample")

  #Best Portfolio for Sharpe
  rp_weights <- as.matrix(rp_weights)  # Portfolio weights
  exp_ret_score <- as.matrix(stock_universe_m_d_ref %>% dplyr::filter(is_eligible == 1) %>% dplyr::pull(exp_ret_score))  # Expected return vector
  cov_matrix <- as.matrix(covariance_matrix)  # Covariance matrix
  # Calculate Portfolio Return (Expected Return)
  portfolio_return <- rp_weights %*% exp_ret_score  # Matrix multiplication
  # Calculate Portfolio Risk (Standard Deviation)
  portfolio_risk <- sqrt(rowSums((rp_weights %*% cov_matrix) * rp_weights))
  # Optimal Sharpe
  optimal_sharpe_weights <- rp_weights[which.max(portfolio_return/portfolio_risk),]
  optimal_ret <-  portfolio_return[which.max(portfolio_return/portfolio_risk),]
  optimal_risk <- portfolio_risk[which.max(portfolio_return/portfolio_risk)]

  set.seed(123)
  results <- set_portfolio_weights(universe_m_d_ref = stock_universe_m_d_ref, port_construction_method = "mvo",
                                   eligible_returns_m_xts_upd_ref = daily_stock_returns_m_xts_upd_ref, groups_m_d_ref = stock_groups_m_d_ref,
                                   cov_matrix_sample_size = 60, cov_estimation_method = "cc",
                                   liquidity_constraint_policy = liquidity_constraint_policy,
                                   concentration_constraint_policy = concentration_constraint_policy
  )

  #Check for random weights generation
  expected_weights <- t(rp_weights) %>% as.data.frame() %>% tibble::rownames_to_column("tickers")
  expect_equal(results@random_port_weights, expected_weights)
  expect_equal(results@weights, optimal_sharpe_weights %>% unname())
  expect_equal(1.911, optimal_ret, tolerance = 1e-2)
  expect_equal(0.574, optimal_risk, tolerance = 1e-2)

  #Best Portfolio for Return
  optimal_ret_weights <-  rp_weights[which.max(portfolio_return),]

  set.seed(123)
  results <- set_portfolio_weights(universe_m_d_ref = stock_universe_m_d_ref, port_construction_method = "mvo",
                                   eligible_returns_m_xts_upd_ref = daily_stock_returns_m_xts_upd_ref, groups_m_d_ref = stock_groups_m_d_ref,
                                   cov_matrix_sample_size = 60, cov_estimation_method = "cc",
                                   opt_objective = "return",
                                   liquidity_constraint_policy = liquidity_constraint_policy,
                                   concentration_constraint_policy = concentration_constraint_policy

  )
  expect_equal(results@weights, optimal_ret_weights %>% unname())

  #Best Portfolio for Risk
  optimal_risk_weights <-  rp_weights[which.min(portfolio_risk),]

  set.seed(123)
  results <- set_portfolio_weights(universe_m_d_ref = stock_universe_m_d_ref, port_construction_method = "mvo",
                                   eligible_returns_m_xts_upd_ref = daily_stock_returns_m_xts_upd_ref, groups_m_d_ref = stock_groups_m_d_ref,
                                   cov_matrix_sample_size = 60, cov_estimation_method = "cc",
                                   opt_objective = "risk",
                                   liquidity_constraint_policy = liquidity_constraint_policy,
                                   concentration_constraint_policy = concentration_constraint_policy

  )

  expect_equal(results@weights, optimal_risk_weights %>% unname())
  expected_results[which(expected_results$is_eligible == 1), "rel_risk_contr"] <- relative_risk_contribution(optimal_risk_weights %>% unname(), covariance_matrix)$rel_risk_contr
  expected_results[which(expected_results$is_eligible == 0), "rel_risk_contr"] <- 0

  expected_results[which(expected_results$is_eligible == 1), "weights"] <- optimal_risk_weights
  expected_results[which(expected_results$is_eligible == 0), "weights"] <- 0

  expect_equal(results@universe_m_d_ref@data, expected_results)
  expect_equal(results@universe_m_d_ref@data$weights %>% sum(), 1)


  #Check that constraints match expectations
  #Upper box
  expect_true(
    all(
      sapply(seq_len(ncol(rp_weights)), function(j) {
        all(rp_weights[, j] <= eligible_universe_m_d_ref$max_weight[j])
      })
    )
  )

  #Lower box
  expect_true(
    all(
      sapply(seq_len(ncol(rp_weights)), function(j) {
        all(rp_weights[, j] >= eligible_universe_m_d_ref$min_weight[j])
      })
    )
  )

  #Group constraints
  groups <- c("Agro", "Bancos e Serviços Financeiros", "Consumo Cíclico", "Consumo Não-Cíclico", "Indústria", "Materiais Básicos",
              "Petróleo gás e biocombustíveis", "Utilidade Pública")
  #Check if all group weights match
  for(i in 1:length(groups)){
    sector_tickers <- eligible_universe_m_d_ref %>% dplyr::filter(sectors == groups[i]) %>% dplyr::pull(tickers)
    sector_weights <- rp_weights[, sector_tickers] %>% rowSums()
    expect_true(all(sector_weights <= group_constraints_helper$group_constraint_max[i]))
    expect_true(all(sector_weights >= group_constraints_helper$group_constraint_min[i]))
  }

  #Group constraints
  groups <- c("Doméstico Cíclico", "Doméstico Defensivo", "Exportador", "Indústria")
  #Check if all group weights match
  for(i in 9:(9 + length(groups) - 1)){
    sector_tickers <- eligible_universe_m_d_ref %>% dplyr::filter(macro_sector == groups[i - 8]) %>% dplyr::pull(tickers)
    sector_weights <- rp_weights[, sector_tickers] %>% rowSums()
    expect_true(all(sector_weights <= group_constraints_helper$group_constraint_max[i]))
    expect_true(all(sector_weights >= group_constraints_helper$group_constraint_min[i]))
  }

})

test_that("set portfolio weights works for stocks (mvo_con + resampling + ridge_pen) - toy_preprocessed", {

  #Create signals_m_d_ref
  load(paste(test_path(),"/testdata/","toy_preprocessed_port_obj.RData", sep =""))

  #Quantile Range
  eligibility_quantile_range <- c(0.67, 1)

  #Current date
  current_date <- "2023-04-15"

  #Initial Preps
  signals_m_d_ref <- signals_m_df %>% dplyr::filter(dates == current_date)
  liquidity_m_d_ref <- liquidity_m_df %>% dplyr::filter(dates == current_date)
  benchmark_weights_m_d_ref <- benchmark_weights_m_df %>% dplyr::filter(dates == current_date)
  stock_groups_m_d_ref <- stock_groups_m_df %>% dplyr::filter(dates == current_date)
  ridge_pen <- 1
  n_resamples <- 3
  exp_ret_score_jitter <- 0.02
  cov_jitter <- 0.01
  concentration_constraint_policy$max_abs_active_group_weight <- NULL

  #Derive Stock Universe
  stock_universe_m_d_ref <- derive_stock_universe_m_d_ref(signals_m_d_ref = signals_m_d_ref,
                                                          chosen_score_metric_and_position = c(vol_36m = "short"),
                                                          upper_quantile_winsorization = upper_quantile_winsorization,
                                                          lower_quantile_winsorization = lower_quantile_winsorization)

  #Set ibov_bench_weights as target_port_m_d_ref
  target_port_m_d_ref <- stock_universe_m_d_ref %>%
    dplyr::select(id, tickers, dates) %>%
    dplyr::left_join(benchmark_weights_m_d_ref %>%
                       dplyr::select(id, ibov), by = "id") %>%
    dplyr::rename(target_weights = ibov)

  #Classify stock universe
  stock_universe_m_d_ref <- classify_investment_universe(
    universe_m_d_ref = stock_universe_m_d_ref,
    eligibility_quantile_range = eligibility_quantile_range,
    liquidity_m_d_ref = liquidity_m_d_ref,
    target_port_m_d_ref = target_port_m_d_ref,
    ridge_pen = ridge_pen,
    liquidity_constraint_policy = liquidity_constraint_policy,
    liquidity_floor_cutoffs = liquidity_floor_cutoffs_df,
    benchmark_weights_m_d_ref = benchmark_weights_m_d_ref,
    groups_m_d_ref = stock_groups_m_d_ref,
    concentration_constraint_policy = concentration_constraint_policy
  )

  #Test MVO Constrained
  expected_results <- stock_universe_m_d_ref
  daily_stock_returns_m_xts_upd_ref <- daily_stock_returns_m_xts[which(zoo::index(daily_stock_returns_m_xts) <= current_date),]
  eligible_tickers <- expected_results %>% dplyr::filter(is_eligible == 1) %>% dplyr::pull(tickers)

  covariance_matrix <- estimate_covariance_matrix(tickers = eligible_tickers, returns_m_xts_upd_ref = daily_stock_returns_m_xts_upd_ref,
                                                  cov_matrix_sample_size = 60, cov_estimation_method = "cc",
                                                  active_returns = FALSE,
                                                  groups_m_d_ref = stock_groups_m_d_ref
  )

  set.seed(123)
  optimal_weights_list <- list()
  jittered_exp_ret_score_list <- list()
  jittered_cov_matrix_list <- list()
  rp_weights_list <- list()
  for(i in seq_len(n_resamples + 1)){
    #Portfolio
    port_spec <- PortfolioAnalytics::portfolio.spec(assets = eligible_tickers)
    port_spec_constr <- PortfolioAnalytics::add.constraint(portfolio = port_spec, type = "full_investment")
    port_spec_constr <- PortfolioAnalytics::add.constraint(portfolio = port_spec, type = "box")

    #Box constraints
    eligible_universe_m_d_ref <- generate_box_constraints(universe_m_d_ref = stock_universe_m_d_ref,
                                                          liquidity_constraint_policy = liquidity_constraint_policy,
                                                          concentration_constraint_policy = concentration_constraint_policy)

    port_spec_constr <- PortfolioAnalytics::add.constraint(type = "box", portfolio = port_spec_constr,
                                                                min = eligible_universe_m_d_ref$min_weight,
                                                                max = eligible_universe_m_d_ref$max_weight)

    expected_results[which(expected_results$is_eligible == 1), "max_weight"] <- eligible_universe_m_d_ref$max_weight
    expected_results[which(expected_results$is_eligible == 0), "max_weight"] <- 0

    expected_results[which(expected_results$is_eligible == 1), "min_weight"] <- eligible_universe_m_d_ref$min_weight
    expected_results[which(expected_results$is_eligible == 0), "min_weight"] <- 0

    #Metrics
    exp_ret_score <- as.matrix(stock_universe_m_d_ref %>% dplyr::filter(is_eligible == 1) %>% dplyr::pull(exp_ret_score))  # Expected return vector
    #Jitter exp_ret_score
    if (i == 1){
      jittered_exp_ret_score <- exp_ret_score  #No jitter for first iteration
    } else {
      jittered_exp_ret_score <- exp_ret_score + stats::rnorm(length(exp_ret_score), mean = 0,
                                                             sd = exp_ret_score_jitter * sd(exp_ret_score))
    }

    jittered_exp_ret_score_list[[i]] <- jittered_exp_ret_score

    cov_matrix <- as.matrix(covariance_matrix)  # Covariance matrix

    #Jitter cov matrix
    if (i == 1){
      jittered_cov_matrix <- cov_matrix  #No jitter for first iteration
    } else {
      ev <- eigen(cov_matrix, symmetric = TRUE)
      mult <- exp(stats::rnorm(n = length(ev$values), mean = 0, sd = cov_jitter))
      jittered_cov_matrix <- ev$vectors %*% diag(ev$values * mult) %*% t(ev$vectors)
      dimnames(jittered_cov_matrix) <- dimnames(cov_matrix)
    }
    jittered_cov_matrix_list[[i]] <- jittered_cov_matrix

    rp_weights <- PortfolioAnalytics::random_portfolios(portfolio = port_spec_constr,
                                                        permutations = 2000,
                                                        rp_method = "sample")

    rp_weights_list[[i]] <- rp_weights

    #Best Portfolio for Risk
    rp_weights <- as.matrix(rp_weights)  # Portfolio weights

    # Calculate Portfolio Return (Expected Return)
    portfolio_return <- rp_weights %*% jittered_exp_ret_score  # Matrix multiplication
    # Calculate Portfolio Risk (Standard Deviation)
    portfolio_risk <- sqrt(rowSums((rp_weights %*% jittered_cov_matrix) * rp_weights))
    # Difference to target_port
    portfolio_diff <- data.frame(t(rp_weights)) %>%
      tibble::rownames_to_column("tickers") %>%
      dplyr::left_join(target_port_m_d_ref %>% dplyr::select(tickers, target_weights), by = "tickers")

    target_port <- portfolio_diff %>% dplyr::select(tickers, target_weights)
    portfolio_diff <- dplyr::select(portfolio_diff, -tickers, -target_weights) - target_port$target_weights
    ## Sum squared difference
    sum_squared_diff <- colSums(portfolio_diff^2)

    # Combine with risk
    combined_metric <- (portfolio_risk) + (ridge_pen * sum_squared_diff)

    # Optimal
    optimal_risk <- combined_metric[which.min(combined_metric)]
    optimal_weights <- rp_weights[which.min(combined_metric),]

    optimal_weights_list[[i]] <- optimal_weights

  }

  #Take the average of weights
  avg_weights <- Reduce("+", optimal_weights_list) / length(optimal_weights_list)

  #Join with expected results
  base_weights_df <- data.frame(
    tickers = names(optimal_weights_list[[1]]),
    base_weights = optimal_weights_list[[1]] %>% unname()
  )
  expected_results <- expected_results %>%
    dplyr::left_join(base_weights_df, by = "tickers")
  expected_results$base_weights[which(is.na(expected_results$base_weights))] <- 0

  avg_weights_df <- data.frame(
    tickers = names(avg_weights),
    weights = avg_weights %>% unname()
  )
  expected_results <- expected_results %>%
    dplyr::left_join(avg_weights_df, by = "tickers")
  expected_results$weights[which(is.na(expected_results$weights))] <- 0

  #Rel risk contribution
  rrc <- relative_risk_contribution(
    weights = expected_results %>% dplyr::filter(is_eligible == 1L) %>% dplyr::pull(weights),
    covariance_matrix = covariance_matrix
  )

  expected_results <- expected_results %>%
    dplyr::left_join(rrc, by = "tickers")
  expected_results$rel_risk_contr[which(is.na(expected_results$rel_risk_contr))] <- 0
  expected_results <- expected_results %>%
    dplyr::relocate(rel_risk_contr, .before = weights)



  set.seed(123)
  results <- set_portfolio_weights(universe_m_d_ref = stock_universe_m_d_ref, port_construction_method = "mvo",
                                   eligible_returns_m_xts_upd_ref = daily_stock_returns_m_xts_upd_ref, groups_m_d_ref = stock_groups_m_d_ref,
                                   cov_matrix_sample_size = 60, cov_estimation_method = "cc",
                                   opt_objective = "risk", ridge_pen = ridge_pen,
                                   n_resamples = n_resamples,
                                   liquidity_constraint_policy = liquidity_constraint_policy,
                                   concentration_constraint_policy = concentration_constraint_policy
  )


  # Test that base weights match
  expect_equal(expected_results, results@universe_m_d_ref@data)

  # Test that base and optimal do not match
  expect_false(all(results@universe_m_d_ref@data$base_weights == results@universe_m_d_ref@data$weights))

  # Test that base solution is not the one that minimizes risk
  risk_vec <- vector(length = ncol(results@random_port_weights) - 1)
  for(i in seq_len(ncol(results@random_port_weights))){
    if (i == 1) next
    weights_i <- results@random_port_weights[, i] %>% unname()
    risk_i <- sqrt(t(weights_i) %*% covariance_matrix %*% weights_i)
    risk_vec[i] <- risk_i
  }
  base_port_risk <- sqrt(
    t(results@universe_m_d_ref@data %>% dplyr::filter(is_eligible == 1L) %>% dplyr::pull(base_weights))
    %*% covariance_matrix %*%
      (results@universe_m_d_ref@data %>% dplyr::filter(is_eligible == 1L) %>% dplyr::pull(base_weights))
  )

  expect_gte(base_port_risk, min(risk_vec[-1]))


  #Check that constraints match expectations
  #Upper box
  expect_true(all(results@universe_m_d_ref@data$base_weights <= results@universe_m_d_ref@data$max_weight))

  #Lower box
  expect_true(all(results@universe_m_d_ref@data$base_weights >= results@universe_m_d_ref@data$min_weight))


})

test_that("set portfolio weights works for stocks (custom_weights) - toy_preprocessed", {

  #Create signals_m_d_ref
  load(paste(test_path(),"/testdata/","toy_preprocessed_port_obj.RData", sep =""))

  #Quantile Range and other preps
  eligibility_quantile_range <- c(0.67, 1)
  chosen_score_metric_and_position <- c(vol_36m = "short")
  custom_stock_weights_m_df <- benchmark_weights_m_df %>% dplyr::rename(weights = ibov)


  #Check
  check_inputs_port_backtest(signals_m_df = signals_m_df, oos_predictions_m_df = NULL, chosen_score_metric_and_position = chosen_score_metric_and_position,
                             rebalancing_months = 6, initial_buffer_period = 6, port_construction_method = "custom_weights",
                             eligibility_quantile_range = eligibility_quantile_range, selected_benchmark = "ibov",
                             macro_concentration_constraint_policy = NULL, macro_ridge_pen = NULL,
                             micro_port_construction_method = NULL, macro_port_construction_method = NULL,
                             min_eligible_assets_fallback = NULL,
                             scaler_m_df = NULL, chosen_scaler = NULL, scaler_shrinkage = NULL,
                             use_raw_for_eligibility = NULL, exp_ret_score_tilt = NULL, exp_ret_score_tilt_eta = NULL,
                             rp_method = NULL, n_random_ports = NULL, random_ports_method = NULL, opt_objective = NULL, opt_method = NULL,
                             cov_estimation_method = NULL, cov_matrix_sample_size = NULL, active_returns = FALSE, cov_matrix_benchmark = NULL,
                             daily_stock_returns_m_xts = NULL, daily_bench_returns_m_xts = NULL, benchmark_returns_m_xts = benchmark_returns_m_xts,
                             liquidity_constraint_policy = NULL, turnover_constraint_policy = NULL, concentration_constraint_policy = NULL,
                             liquidity_m_df = liquidity_m_df, liquidity_floor_cutoffs = liquidity_floor_cutoffs_df, main_liquidity_metric = "mean_volfin_3m",
                             stock_groups_m_df = stock_groups_m_df, benchmark_weights_m_df = benchmark_weights_m_df, volatility_m_df = volatility_m_df,
                             fwd_return_m_df = fwd_return_m_df, transaction_costs_parameters = transaction_costs_list, ridge_pen = NULL,
                             custom_stock_weights_m_df = custom_stock_weights_m_df, custom_stock_metrics_m_df = NULL, user_defined_OR_rules_m_df = NULL, user_defined_AND_rules_m_df = NULL,
                             upper_quantile_winsorization = 0.95, lower_quantile_winsorization = 0.05, verbose = TRUE
  )

  #Current date
  current_date <- "2023-04-15"

  #Initial Preps
  signals_m_d_ref <- signals_m_df %>% dplyr::filter(dates == current_date)
  liquidity_m_d_ref <- liquidity_m_df %>% dplyr::filter(dates == current_date)
  benchmark_weights_m_d_ref <- benchmark_weights_m_df %>% dplyr::filter(dates == current_date)
  stock_groups_m_d_ref <- stock_groups_m_df %>% dplyr::filter(dates == current_date)
  custom_stock_weights_m_d_ref <- custom_stock_weights_m_df %>% dplyr::filter(dates == current_date)

  #Derive Stock Universe
  stock_universe_m_d_ref <- derive_stock_universe_m_d_ref(signals_m_d_ref = signals_m_d_ref, chosen_score_metric_and_position = c(vol_36m = "short"),
                                                          upper_quantile_winsorization = upper_quantile_winsorization,
                                                          lower_quantile_winsorization = lower_quantile_winsorization)

  #Classify stock universe
  stock_universe_m_d_ref <- classify_investment_universe(
    universe_m_d_ref = stock_universe_m_d_ref,
    eligibility_quantile_range = eligibility_quantile_range,
    liquidity_m_d_ref = liquidity_m_d_ref,
    liquidity_constraint_policy = liquidity_constraint_policy,
    liquidity_floor_cutoffs = liquidity_floor_cutoffs_df,
    benchmark_weights_m_d_ref = benchmark_weights_m_d_ref,
    groups_m_d_ref = stock_groups_m_d_ref,
    concentration_constraint_policy = concentration_constraint_policy
  )

  #Test custom weights
  expected_results <- stock_universe_m_d_ref
  expected_results <- expected_results %>% dplyr::left_join(custom_stock_weights_m_d_ref %>% dplyr::select(-tickers, -dates), by = "id")

  results <- set_portfolio_weights(universe_m_d_ref = stock_universe_m_d_ref, port_construction_method = "custom_weights",
                                   custom_weights_m_d_ref = custom_stock_weights_m_d_ref)

  expect_equal(results@universe_m_d_ref@data, expected_results)
  expect_equal(results@universe_m_d_ref@data$weights %>% sum(), 1)
  expect_equal(results@universe_m_d_ref@data$weights, results@universe_m_d_ref@data$ibov_bench_weights)

})

test_that("set portfolio weights work for stocks (mmaf = top_down, top_down_proxy = rp, macro_port = hrp, micro level = rp) - toy_preprocessed", {


  ## First let's apply the model to each group
  #Create signals_m_d_ref
  load(paste(test_path(),"/testdata/","toy_preprocessed_port_obj.RData", sep =""))
  concentration_constraint_policy$max_abs_active_group_weight <- NULL

  #Quantile Range and other preps
  eligibility_quantile_range <- c(0.67, 1)
  chosen_score_metric_and_position <- c(vol_36m = "short")

  #Current date
  current_date <- "2023-04-15"

  #Initial Preps
  signals_m_d_ref <- signals_m_df %>% dplyr::filter(dates == current_date)
  liquidity_m_d_ref <- liquidity_m_df %>% dplyr::filter(dates == current_date)
  benchmark_weights_m_d_ref <- benchmark_weights_m_df %>% dplyr::filter(dates == current_date)
  stock_groups_m_d_ref <- stock_groups_m_df %>% dplyr::filter(dates == current_date)

  #Derive Stock Universe
  stock_universe_m_d_ref <- derive_stock_universe_m_d_ref(signals_m_d_ref = signals_m_d_ref, chosen_score_metric_and_position = c(vol_36m = "short"),
                                                          upper_quantile_winsorization = upper_quantile_winsorization,
                                                          lower_quantile_winsorization = lower_quantile_winsorization)

  #Classify stock universe
  stock_universe_m_d_ref <- classify_investment_universe(
    universe_m_d_ref = stock_universe_m_d_ref,
    eligibility_quantile_range = eligibility_quantile_range,
    liquidity_m_d_ref = liquidity_m_d_ref,
    liquidity_constraint_policy = liquidity_constraint_policy,
    liquidity_floor_cutoffs = liquidity_floor_cutoffs_df,
    benchmark_weights_m_d_ref = benchmark_weights_m_d_ref,
    groups_m_d_ref = stock_groups_m_d_ref,
    concentration_constraint_policy = concentration_constraint_policy
  )

  set.seed(123)

  #Estimate covariance matrix
  cov_matrix <- estimate_covariance_matrix(
    tickers = stock_universe_m_d_ref %>% dplyr::filter(is_eligible == 1) %>% dplyr::pull(tickers),
    returns_m_xts_upd_ref = daily_stock_returns_m_xts[which(zoo::index(daily_stock_returns_m_xts) <= current_date),],
    cov_matrix_sample_size = 60,
    cov_estimation_method = "cc",
    active_returns = FALSE,
    groups_m_d_ref = stock_groups_m_d_ref
  )


  #Fit portfolios by sectors to define proxies
  sectors <- sort(unique(stock_groups_m_d_ref$sectors))
  sectors_members <- purrr::map(sectors, function(x) {
    stock_groups_m_d_ref %>% dplyr::filter(sectors == x) %>% dplyr::pull(tickers)
  })
  names(sectors_members) <- sectors
  eligible_universe_m_d_ref <- stock_universe_m_d_ref %>% dplyr::filter(is_eligible == 1)

  sector_port_list <- process_micro_portfolios(
    parallel = TRUE,
    universe_m_d_ref = stock_universe_m_d_ref,
    groups = sectors,
    group_members = sectors_members,
    group_weights = NULL,
    groups_m_d_ref = stock_groups_m_d_ref,
    eligible_returns_m_xts_upd_ref = daily_stock_returns_m_xts[which(zoo::index(daily_stock_returns_m_xts) <= current_date),],
    cov_matrix_sample_size = 60,
    cov_estimation_method = "cc",
    micro_port_construction_method = "hrp",
    rp_method = "ward.D"
  )

  #Generate macro portfolios
  groups_exp_ret_score <- purrr::map_vec(sector_port_list, function(x) {
    sum(dplyr::pull(x@universe_m_d_ref@data, exp_ret_score) *
        dplyr::pull(x@universe_m_d_ref@data, weights))
  })
  groups_liquidity <- purrr::map_vec(sector_port_list, function(x) {
    sum(dplyr::pull(x@universe_m_d_ref@data, mean_volfin_3m) *
        dplyr::pull(x@universe_m_d_ref@data, weights))
  })
  groups_presence <- purrr::map_vec(sector_port_list, function(x) {
    sum(dplyr::pull(x@universe_m_d_ref@data, presence) *
        dplyr::pull(x@universe_m_d_ref@data, weights))
  })
  groups_ibov_bench_weights <- stock_universe_m_d_ref %>%
    dplyr::group_by(sectors) %>%
    dplyr::summarise(ibov_bench_weights = sum(ibov_bench_weights), .groups = "drop")

  groups_liquidity_m_df <- data.frame(
    tickers = sectors,
    dates = current_date,
    mean_volfin_3m = groups_liquidity,
    presence = groups_presence
  ) %>% dplyr::mutate(
    id = paste0(tickers, "-", dates), .before = dplyr::everything()
  )
  row.names(groups_liquidity_m_df) <- NULL
  groups_liquidity_m_df$dates <- as.Date(groups_liquidity_m_df$dates)

  group_universe_m_d_ref <- data.frame(
    id = paste0(sectors, "-", current_date),
    tickers = sectors,
    dates = as.Date(current_date),
    exp_ret_score = groups_exp_ret_score,
    is_eligible = 1
  )
  row.names(group_universe_m_d_ref) <- NULL

  g1_w <- sector_port_list[[1]]@universe_m_d_ref@data %>% dplyr::filter(is_eligible == 1) %>% dplyr::pull(weights)
  g1_tickers <- sector_port_list[[1]]@universe_m_d_ref@data %>% dplyr::filter(is_eligible == 1) %>% dplyr::pull(tickers)
  g2_w <- sector_port_list[[2]]@universe_m_d_ref@data %>% dplyr::filter(is_eligible == 1) %>% dplyr::pull(weights)
  g2_tickers <- sector_port_list[[2]]@universe_m_d_ref@data %>% dplyr::filter(is_eligible == 1) %>%dplyr::pull(tickers)
  g3_w <- sector_port_list[[3]]@universe_m_d_ref@data %>% dplyr::filter(is_eligible == 1) %>%dplyr::pull(weights)
  g3_tickers <- sector_port_list[[3]]@universe_m_d_ref@data %>% dplyr::filter(is_eligible == 1) %>%dplyr::pull(tickers)
  g4_w <- sector_port_list[[4]]@universe_m_d_ref@data %>% dplyr::filter(is_eligible == 1) %>%dplyr::pull(weights)
  g4_tickers <- sector_port_list[[4]]@universe_m_d_ref@data %>% dplyr::filter(is_eligible == 1) %>% dplyr::pull(tickers)
  g5_w <- sector_port_list[[5]]@universe_m_d_ref@data %>% dplyr::filter(is_eligible == 1) %>% dplyr::pull(weights)
  g5_tickers <- sector_port_list[[5]]@universe_m_d_ref@data %>% dplyr::filter(is_eligible == 1) %>% dplyr::pull(tickers)
  g6_w <- sector_port_list[[6]]@universe_m_d_ref@data %>% dplyr::filter(is_eligible == 1) %>% dplyr::pull(weights)
  g6_tickers <- sector_port_list[[6]]@universe_m_d_ref@data %>% dplyr::filter(is_eligible == 1) %>% dplyr::pull(tickers)
  g7_w <- sector_port_list[[7]]@universe_m_d_ref@data %>% dplyr::filter(is_eligible == 1) %>% dplyr::pull(weights)
  g7_tickers <- sector_port_list[[7]]@universe_m_d_ref@data %>% dplyr::filter(is_eligible == 1) %>% dplyr::pull(tickers)
  g8_w <- sector_port_list[[8]]@universe_m_d_ref@data %>% dplyr::filter(is_eligible == 1) %>% dplyr::pull(weights)
  g8_tickers <- sector_port_list[[8]]@universe_m_d_ref@data %>% dplyr::filter(is_eligible == 1) %>% dplyr::pull(tickers)

  ### Calculate each cov matrix element
  groups <- list(
    list(w = g1_w, tickers = g1_tickers),
    list(w = g2_w, tickers = g2_tickers),
    list(w = g3_w, tickers = g3_tickers),
    list(w = g4_w, tickers = g4_tickers),
    list(w = g5_w, tickers = g5_tickers),
    list(w = g6_w, tickers = g6_tickers),
    list(w = g7_w, tickers = g7_tickers),
    list(w = g8_w, tickers = g8_tickers)
  )
  n_groups <- length(groups)
  group_cov <- matrix(NA, n_groups, n_groups)

  for (i in 1:n_groups) {
    for (j in 1:n_groups) {
      wi <- groups[[i]]$w
      wj <- groups[[j]]$w
      ti <- groups[[i]]$tickers
      tj <- groups[[j]]$tickers

      subcov <- cov_matrix[ti, tj, drop = FALSE]
      group_cov[i, j] <- as.numeric(t(wi) %*% subcov %*% wj)
    }
  }

  rownames(group_cov) <- colnames(group_cov) <- sectors
  ##Arranje according to order in group_universe
  group_cov <- group_cov[match(group_universe_m_d_ref$tickers, rownames(group_cov)),
                         match(group_universe_m_d_ref$tickers, colnames(group_cov))]

  group_port <- set_portfolio_weights(
    universe_m_d_ref = group_universe_m_d_ref %>%
      dplyr::left_join(groups_liquidity_m_df %>% dplyr::select(-tickers, -dates), by = "id") %>%
      dplyr::left_join(groups_ibov_bench_weights, by = c("tickers" = "sectors")) %>%
      dplyr::relocate(exp_ret_score, is_eligible, .after = dplyr::last_col()),
    port_construction_method = "hrp",
    linkage = "complete",
    liquidity_m_d_ref = groups_liquidity_m_df,
    covariance_matrix = group_cov,
    exp_ret_score_tilt = "inner",
    exp_ret_score_tilt_eta = 0.05,
    level = "group"
  )

  group_weights <- group_port@universe_m_d_ref@data %>% dplyr::filter(is_eligible == 1) %>% dplyr::pull(weights)
  names(group_weights) <- group_port@universe_m_d_ref@data %>% dplyr::filter(is_eligible == 1) %>% dplyr::pull(tickers)

  #Now let's recalculate micro portfolios given group weights
  # Helper to capture both value and warnings
  capture_warnings_and_value <- function(expr) {
    warnings <- character()
    value <- withCallingHandlers(
      expr,
      warning = function(w) {
        warnings <- c(warnings, conditionMessage(w))
        invokeRestart("muffleWarning")
      }
    )
    list(value = value, warnings = warnings)
  }

  micro_port_list <- capture_warnings_and_value(
    process_micro_portfolios(
    selected_benchmark = "ibov",
    bench_assets_returns_m_xts_upd_ref = daily_stock_returns_m_xts[which(zoo::index(daily_stock_returns_m_xts) <= current_date),
                                                              stock_universe_m_d_ref %>% dplyr::filter(ibov_bench_weights > 0) %>% dplyr::pull(tickers)
    ],
    parallel = FALSE,
    universe_m_d_ref = stock_universe_m_d_ref,
    eligible_returns_m_xts_upd_ref = daily_stock_returns_m_xts[which(zoo::index(daily_stock_returns_m_xts) <= current_date),
                                                               stock_universe_m_d_ref %>% dplyr::filter(is_eligible == 1) %>% dplyr::pull(tickers)
    ],
    cov_matrix_sample_size = 60,
    cov_estimation_method = "cc",
    active_returns = FALSE,
    groups_m_d_ref = stock_groups_m_d_ref,
    groups = sectors,
    group_members = sectors_members,
    group_weights = group_weights,
    micro_port_construction_method = "rp",
    liquidity_constraint_policy = liquidity_constraint_policy,
    concentration_constraint_policy = concentration_constraint_policy
    )
  )

  # Allocate result
  micro_result_list <- micro_port_list$value

  # Define final weights by multiplying weights by group_weight
  final_weights_m_df <- purrr::map2_dfr(micro_result_list, names(micro_result_list), function(port, group_name) {
    port@universe_m_d_ref@data %>%
      dplyr::mutate(weights = weights * group_weights[group_name])
  })

  # Join to eligible universe by id
  universe_m_d_ref_result <- stock_universe_m_d_ref %>%
    dplyr::left_join(final_weights_m_df %>% dplyr::select(id, weights), by = "id")
  universe_m_d_ref_result$weights[which(is.na(universe_m_d_ref_result$weights))] <- 0
  rel_risk_contribution <- relative_risk_contribution(
    weights = universe_m_d_ref_result %>% dplyr::filter(is_eligible == 1L) %>% dplyr::pull(weights),
    covariance_matrix = cov_matrix
  )
  universe_m_d_ref_result <- universe_m_d_ref_result %>%
    dplyr::left_join(rel_risk_contribution, by = "tickers") %>%
    dplyr::relocate(rel_risk_contr, .before = weights)
  universe_m_d_ref_result$rel_risk_contr[which(is.na(universe_m_d_ref_result$rel_risk_contr))] <- 0

  ## Generate active columns
  port_stats <- calculate_port_stats(
    universe_m_d_ref = universe_m_d_ref_result,
    group_universe_m_d_ref = group_port@universe_m_d_ref@data,
    group_cov_matrix = group_cov,
    selected_benchmark = "ibov",
    bench_universe_m_d_ref = stock_universe_m_d_ref %>%
      dplyr::mutate(is_eligible = ifelse(ibov_bench_weights > 0, 1, 0)) %>%
      dplyr::rename(weights = ibov_bench_weights),
    all_returns_m_xts_upd_ref = daily_stock_returns_m_xts[which(zoo::index(daily_stock_returns_m_xts) <= current_date),],
    cov_matrix_sample_size = 60,
    groups_m_d_ref = stock_groups_m_d_ref,
    cov_estimation_method = "cc"
  )

  #Join to universe_m_d_ref
  expected_results <- universe_m_d_ref_result %>%
    dplyr::left_join(port_stats$assets_stats %>%
                       dplyr::rename(
                         act_weights = weights,
                         act_rel_risk_contr = rel_risk_contr
                       ), by = "tickers") %>%
    dplyr::relocate(act_rel_risk_contr, .before = act_weights)
  #Replace NAs with 0
  expected_results$act_weights[which(is.na(expected_results$act_weights))] <- 0
  expected_results$act_rel_risk_contr[which(is.na(expected_results$act_rel_risk_contr))] <- 0

  #Run and compare results
  set.seed(123)
  suppressWarnings(
    results <-
      set_portfolio_weights(
        universe_m_d_ref = stock_universe_m_d_ref,
        port_construction_method = "mmaf",
        top_down_proxy_port_method = "hrp",
        mmaf_method = "top_down",
        mmaf_group_col = "sectors",
        macro_port_construction_method = "hrp",
        macro_linkage = "complete",
        linkage = "ward.D",
        liquidity_m_d_ref = liquidity_m_d_ref,
        selected_benchmark = "ibov",
        bench_assets_returns_m_xts_upd_ref =
          daily_stock_returns_m_xts[which(zoo::index(daily_stock_returns_m_xts) <= current_date),
                                    stock_universe_m_d_ref %>% dplyr::filter(ibov_bench_weights > 0) %>% dplyr::pull(tickers)
          ],
        macro_exp_ret_score_tilt = "inner",
        macro_exp_ret_score_tilt_eta = 0.05,
        micro_port_construction_method = "rp",
        eligible_returns_m_xts_upd_ref =
          daily_stock_returns_m_xts[which(zoo::index(daily_stock_returns_m_xts) <= current_date),
                                    stock_universe_m_d_ref %>% dplyr::filter(is_eligible == 1) %>% dplyr::pull(tickers)
          ],
        liquidity_constraint_policy = liquidity_constraint_policy,
        concentration_constraint_policy = concentration_constraint_policy,
        cov_matrix_sample_size = 60,
        cov_estimation_method = "cc",
        active_returns = FALSE,
        groups_m_d_ref = stock_groups_m_d_ref
      )
  )

  #Check that portfolios match
  testthat::expect_equal(
    group_port, results@macro
  )
  testthat::expect_equal(
    results@macro@port_stats %>% dplyr::select(dplyr::contains("act")) %>% ncol(),
    0
  )

  testthat::expect_equal(
    micro_result_list,
    results@micro
  )
  testthat::expect_equal(
    results@universe_m_d_ref@data,
    expected_results
  )


})

test_that("set portfolio weights work for stocks (mmaf = bottom_up, macro_port = sw, micro level = cs - toy_preprocessed", {

  ## First let's apply the model to each group
  #Create signals_m_d_ref
  load(paste(test_path(),"/testdata/","toy_preprocessed_port_obj.RData", sep =""))

  #Quantile Range and other preps
  eligibility_quantile_range <- c(0.67, 1)
  chosen_score_metric_and_position <- c(vol_36m = "short")

  #Current date
  current_date <- "2023-04-15"

  #Initial Preps
  signals_m_d_ref <- signals_m_df %>% dplyr::filter(dates == current_date)
  liquidity_m_d_ref <- liquidity_m_df %>% dplyr::filter(dates == current_date)
  benchmark_weights_m_d_ref <- benchmark_weights_m_df %>% dplyr::filter(dates == current_date)
  stock_groups_m_d_ref <- stock_groups_m_df %>% dplyr::filter(dates == current_date)

  #Derive Stock Universe
  stock_universe_m_d_ref <- derive_stock_universe_m_d_ref(signals_m_d_ref = signals_m_d_ref, chosen_score_metric_and_position = c(vol_36m = "short"),
                                                          upper_quantile_winsorization = upper_quantile_winsorization,
                                                          lower_quantile_winsorization = lower_quantile_winsorization)

  #Classify stock universe
  stock_universe_m_d_ref <- classify_investment_universe(
    universe_m_d_ref = stock_universe_m_d_ref,
    eligibility_quantile_range = eligibility_quantile_range,
    liquidity_m_d_ref = liquidity_m_d_ref,
    liquidity_constraint_policy = liquidity_constraint_policy,
    liquidity_floor_cutoffs = liquidity_floor_cutoffs_df,
    benchmark_weights_m_d_ref = benchmark_weights_m_d_ref,
    groups_m_d_ref = stock_groups_m_d_ref,
    concentration_constraint_policy = concentration_constraint_policy
  )

  set.seed(123)

  #Estimate covariance matrix
  cov_matrix <- estimate_covariance_matrix(
    tickers = stock_universe_m_d_ref %>% dplyr::filter(is_eligible == 1) %>% dplyr::pull(tickers),
    returns_m_xts_upd_ref = daily_stock_returns_m_xts[which(zoo::index(daily_stock_returns_m_xts) <= current_date),],
    cov_matrix_sample_size = 60,
    cov_estimation_method = "cc",
    active_returns = FALSE,
    groups_m_d_ref = stock_groups_m_d_ref
  )

  #Fit fit bottom up portfolio
  eligible_universe_m_d_ref <- stock_universe_m_d_ref %>% dplyr::filter(is_eligible == 1)

  bottom_up_port <- set_portfolio_weights(
    universe_m_d_ref = stock_universe_m_d_ref,
    cap_weighting_metric = "mean_volfin_3m",
    liquidity_m_d_ref = liquidity_m_d_ref,
    port_construction_method = "cs"
  )
    ## Add rel risk contr
    rrc <- relative_risk_contribution(
      weights = bottom_up_port@universe_m_d_ref@data %>% dplyr::filter(is_eligible == 1L) %>% dplyr::pull(weights),
      covariance_matrix = cov_matrix
    )
    bottom_up_port@universe_m_d_ref@data <- bottom_up_port@universe_m_d_ref@data %>%
      dplyr::left_join(rrc, by = "tickers") %>%
      dplyr::relocate(rel_risk_contr, .before = weights)
    bottom_up_port@universe_m_d_ref@data$rel_risk_contr[which(is.na(bottom_up_port@universe_m_d_ref@data$rel_risk_contr))] <- 0

   ## Set subportfolios by sectors
  sectors <- sort(unique(stock_groups_m_d_ref$macro_sector))

  sectors_universe_m_d_ref_list <- purrr::map(sectors, function(sector){
    bottom_up_port@universe_m_d_ref@data %>%
      dplyr::filter(macro_sector == sector) %>%
      dplyr::mutate(weights = weights / sum(weights)) #Re-normalize weights
  })
  names(sectors_universe_m_d_ref_list) <- sectors

  #Generate macro portfolios
  groups_exp_ret_score <- purrr::map_vec(sectors_universe_m_d_ref_list, function(x) {
    sum(dplyr::pull(x, exp_ret_score) *
          dplyr::pull(x, weights))
  })
  groups_liquidity <- purrr::map_vec(sectors_universe_m_d_ref_list, function(x) {
    sum(dplyr::pull(x, mean_volfin_3m) *
          dplyr::pull(x, weights))
  })
  groups_presence <- purrr::map_vec(sectors_universe_m_d_ref_list, function(x) {
    sum(dplyr::pull(x, presence) *
          dplyr::pull(x, weights))
  })
  groups_ibov_bench_weights <- stock_universe_m_d_ref %>%
    dplyr::group_by(macro_sector) %>%
    dplyr::summarise(ibov_bench_weights = sum(ibov_bench_weights), .groups = "drop")


  groups_liquidity_m_df <- data.frame(
    tickers = sectors,
    dates = current_date,
    mean_volfin_3m = groups_liquidity,
    presence = groups_presence
  ) %>% dplyr::mutate(
    id = paste0(tickers, "-", dates), .before = dplyr::everything()
  )
  row.names(groups_liquidity_m_df) <- NULL
  groups_liquidity_m_df$dates <- as.Date(groups_liquidity_m_df$dates)

  group_universe_m_d_ref <- data.frame(
    id = paste0(sectors, "-", current_date),
    tickers = sectors,
    dates = as.Date(current_date),
    exp_ret_score = groups_exp_ret_score,
    is_eligible = 1
  )
  row.names(group_universe_m_d_ref) <- NULL

  g1_w <- sectors_universe_m_d_ref_list[[1]] %>% dplyr::filter(is_eligible == 1) %>% dplyr::pull(weights)
  g1_tickers <- sectors_universe_m_d_ref_list[[1]] %>% dplyr::filter(is_eligible == 1) %>% dplyr::pull(tickers)
  g2_w <- sectors_universe_m_d_ref_list[[2]] %>% dplyr::filter(is_eligible == 1) %>% dplyr::pull(weights)
  g2_tickers <- sectors_universe_m_d_ref_list[[2]] %>% dplyr::filter(is_eligible == 1) %>% dplyr::pull(tickers)
  g3_w <- sectors_universe_m_d_ref_list[[3]] %>% dplyr::filter(is_eligible == 1) %>% dplyr::pull(weights)
  g3_tickers <- sectors_universe_m_d_ref_list[[3]] %>% dplyr::filter(is_eligible == 1) %>% dplyr::pull(tickers)
  g4_w <- sectors_universe_m_d_ref_list[[4]] %>% dplyr::filter(is_eligible == 1) %>% dplyr::pull(weights)
  g4_tickers <- sectors_universe_m_d_ref_list[[4]] %>% dplyr::filter(is_eligible == 1) %>% dplyr::pull(tickers)

  ### Calculate each cov matrix element
  groups <- list(
    list(w = g1_w, tickers = g1_tickers),
    list(w = g2_w, tickers = g2_tickers),
    list(w = g3_w, tickers = g3_tickers),
    list(w = g4_w, tickers = g4_tickers)
  )
  n_groups <- length(groups)
  group_cov <- matrix(NA, n_groups, n_groups)

  for (i in 1:n_groups) {
    for (j in 1:n_groups) {
      wi <- groups[[i]]$w
      wj <- groups[[j]]$w
      ti <- groups[[i]]$tickers
      tj <- groups[[j]]$tickers

      subcov <- cov_matrix[ti, tj, drop = FALSE]
      group_cov[i, j] <- as.numeric(t(wi) %*% subcov %*% wj)
    }
  }

  rownames(group_cov) <- colnames(group_cov) <- sectors
  ##Arranje according to order in group_universe
  group_cov <- group_cov[match(group_universe_m_d_ref$tickers, rownames(group_cov)),
                         match(group_universe_m_d_ref$tickers, colnames(group_cov))]

  group_port <- set_portfolio_weights(
    universe_m_d_ref = group_universe_m_d_ref %>%
      dplyr::left_join(groups_liquidity_m_df %>% dplyr::select(-tickers, -dates), by = "id") %>%
      dplyr::left_join(groups_ibov_bench_weights, by = c("tickers" = "macro_sector")) %>%
      dplyr::relocate(exp_ret_score, is_eligible, .after = dplyr::last_col()),
    covariance_matrix = group_cov,
    port_construction_method = "sw"
  )

  group_weights <- group_port@universe_m_d_ref@data %>% dplyr::filter(is_eligible == 1) %>% dplyr::pull(weights)
  names(group_weights) <- group_port@universe_m_d_ref@data %>% dplyr::filter(is_eligible == 1) %>% dplyr::pull(tickers)

  #Now let's recalculate micro portfolios given group weights
  # Helper to capture both value and warnings
  capture_warnings_and_value <- function(expr) {
    warnings <- character()
    value <- withCallingHandlers(
      expr,
      warning = function(w) {
        warnings <- c(warnings, conditionMessage(w))
        invokeRestart("muffleWarning")
      }
    )
    list(value = value, warnings = warnings)
  }

  micro_result_list <- NULL

  # Define final weights by multiplying weights by group_weight
  final_weights_m_df <- purrr::map2_dfr(sectors_universe_m_d_ref_list,
                                        names(sectors_universe_m_d_ref_list), function(port, group_name) {
    port %>% dplyr::mutate(weights = weights * group_weights[group_name])
  })

  # Join to eligible universe by id
  universe_m_d_ref_result <- stock_universe_m_d_ref %>%
    dplyr::left_join(final_weights_m_df %>% dplyr::select(id, weights), by = "id")
  universe_m_d_ref_result$weights[which(is.na(universe_m_d_ref_result$weights))] <- 0
  rel_risk_contribution <- relative_risk_contribution(
    weights = universe_m_d_ref_result %>% dplyr::filter(is_eligible == 1L) %>% dplyr::pull(weights),
    covariance_matrix = cov_matrix
  )
  universe_m_d_ref_result <- universe_m_d_ref_result %>%
    dplyr::left_join(rel_risk_contribution, by = "tickers") %>%
    dplyr::relocate(rel_risk_contr, .before = weights)
  universe_m_d_ref_result$rel_risk_contr[which(is.na(universe_m_d_ref_result$rel_risk_contr))] <- 0


  #Run and compare results
  set.seed(123)
  results <-
    set_portfolio_weights(
      universe_m_d_ref = stock_universe_m_d_ref,
      port_construction_method = "mmaf",
      mmaf_method = "bottom_up",
      mmaf_group_col = "macro_sector",
      macro_port_construction_method = "sw",
      micro_port_construction_method = "cs",
      cap_weighting_metric = "mean_volfin_3m",
      groups_m_d_ref = stock_groups_m_d_ref,
      eligible_returns_m_xts_upd_ref = daily_stock_returns_m_xts[which(zoo::index(daily_stock_returns_m_xts) <= current_date),],
      cov_estimation_method = "cc",
      cov_matrix_sample_size = 60,
      liquidity_m_d_ref = liquidity_m_d_ref,
      active_returns = FALSE
    )

  #Check that portfolios match
  testthat::expect_equal(
    group_port@universe_m_d_ref@data, results@macro@universe_m_d_ref@data
  )
  testthat::expect_equal(
    bottom_up_port@universe_m_d_ref@data, results@micro$bottom_up@universe_m_d_ref@data
  )
  testthat::expect_equal(
    results@universe_m_d_ref@data,
    universe_m_d_ref_result
  )


  })

test_that("set portfolio weights work for only one eligible stock - artificial_port_obj", {

  #Create signals_m_d_ref
  load(paste(test_path(),"/testdata/","artificial_port_obj.RData", sep =""))

  #Quantile Range
  eligibility_quantile_range <- c(0.67, 1)

  #Current date
  current_date <- "2001-06-15"

  #Initial Preps
  signals_m_d_ref <- signals_m_df %>% dplyr::filter(dates == current_date)
  liquidity_m_d_ref <- liquidity_m_df %>% dplyr::filter(dates == current_date)
  benchmark_weights_m_d_ref <- benchmark_weights_m_df %>% dplyr::filter(dates == current_date)
  stock_groups_m_d_ref <- stock_groups_m_df %>% dplyr::filter(dates == current_date)
  updated_port_weights_m_lstd_ref <- signals_m_df[which(signals_m_df$dates == "2001-05-15"), c(1:3)]
  updated_port_weights_m_lstd_ref$bop_port_weights <- c(0.20, 0.20, 0.20, 0.20, 0.20)

  #Derive Stock Universe
  stock_universe_m_d_ref <- derive_stock_universe_m_d_ref(signals_m_d_ref = signals_m_d_ref, chosen_score_metric_and_position = c(Gamma = "long"),
                                                          upper_quantile_winsorization = upper_quantile_winsorization,
                                                          lower_quantile_winsorization = lower_quantile_winsorization)

  #Classify stock universe
  stock_universe_m_d_ref <- classify_investment_universe(
    universe_m_d_ref = stock_universe_m_d_ref,
    eligibility_quantile_range = eligibility_quantile_range,
    liquidity_m_d_ref = liquidity_m_d_ref,
    liquidity_constraint_policy = liquidity_constraint_policy,
    liquidity_floor_cutoffs = liquidity_floor_cutoffs_df,
    benchmark_weights_m_d_ref = benchmark_weights_m_d_ref,
    groups_m_d_ref = stock_groups_m_d_ref,
    concentration_constraint_policy = concentration_constraint_policy,
    updated_port_weights_m_lstd_ref = updated_port_weights_m_lstd_ref,
    turnover_constraint_policy = turnover_constraint_policy
  )

  #Test MVO Constrained
  expected_results <- stock_universe_m_d_ref
  daily_stock_returns_m_xts_upd_ref <- daily_stock_returns_m_xts[which(zoo::index(daily_stock_returns_m_xts) <= current_date),]

  covariance_matrix <-  estimate_covariance_matrix(tickers = stock_universe_m_d_ref$tickers, returns_m_xts_upd_ref = daily_stock_returns_m_xts_upd_ref,
                                                   cov_matrix_sample_size = 252, cov_estimation_method = covariance_estimation_method,
                                                   active_returns = FALSE, groups_m_d_ref = stock_groups_m_d_ref
  )


  #Change eligiblity
  stock_universe_m_d_ref$is_eligible <- c(1,0,0,0)

  #EW
  results <- set_portfolio_weights(universe_m_d_ref = stock_universe_m_d_ref, port_construction_method = "ew")
  expect_equal(results@universe_m_d_ref@data$weights, c(1,0,0,0))

  #SW
  results <- set_portfolio_weights(universe_m_d_ref = stock_universe_m_d_ref, port_construction_method = "sw")
  expect_equal(results@universe_m_d_ref@data$weights, c(1,0,0,0))

  #CW
  results <- set_portfolio_weights(universe_m_d_ref = stock_universe_m_d_ref, port_construction_method = "cw",
                                   liquidity_m_d_ref = liquidity_m_d_ref, cap_weighting_metric = "mean_volfin_3m")
  expect_equal(results@universe_m_d_ref@data$weights, c(1,0,0,0))

  #CS
  results <- set_portfolio_weights(universe_m_d_ref = stock_universe_m_d_ref, port_construction_method = "cs",
                                   liquidity_m_d_ref = liquidity_m_d_ref, cap_weighting_metric = "mean_volfin_3m")
  expect_equal(results@universe_m_d_ref@data$weights, c(1,0,0,0))

  #RP
  results <- set_portfolio_weights(universe_m_d_ref = stock_universe_m_d_ref, port_construction_method = "rp",
                                   eligible_returns_m_xts_upd_ref = daily_stock_returns_m_xts_upd_ref,
                                   groups_m_d_ref = stock_groups_m_d_ref,
                                   cov_matrix_sample_size = 252, cov_estimation_method = "sample",
                                   active_returns = FALSE
  )

  expect_equal(results@universe_m_d_ref@data$weights, c(1,0,0,0))
  #HRP
  results <- set_portfolio_weights(universe_m_d_ref = stock_universe_m_d_ref, port_construction_method = "hrp",
                                   eligible_returns_m_xts_upd_ref = daily_stock_returns_m_xts_upd_ref, groups_m_d_ref = stock_groups_m_d_ref,
                                   cov_matrix_sample_size = 252, cov_estimation_method = "sample",
                                   active_returns = FALSE
  )

  expect_equal(results@universe_m_d_ref@data$weights, c(1,0,0,0))
  #MVO
  results <- set_portfolio_weights(universe_m_d_ref = stock_universe_m_d_ref, port_construction_method = "mvo",
                                   eligible_returns_m_xts_upd_ref = daily_stock_returns_m_xts_upd_ref, groups_m_d_ref = stock_groups_m_d_ref,
                                   cov_matrix_sample_size = 252, cov_estimation_method = "sample",
                                   opt_objective = "risk", liquidity_constraint_policy = liquidity_constraint_policy,
                                   turnover_constraint_policy = turnover_constraint_policy,
                                   concentration_constraint_policy = concentration_constraint_policy
    )

  expect_equal(results@universe_m_d_ref@data$weights, c(1,0,0,0))




})







